# -*- coding: utf-8 -*-

import os
from pathlib import Path
from flask import Flask
from extensions import init_extensions, db
from sqlalchemy import inspect, text
import sqlite3
import traceback
from flask import Flask
from extensions import init_extensions, db
from models.user import User
from models.config import BotConfig
from models.order import Order
from models.product import Product
from models.category import Category
from models.withdrawal import Withdrawal
from models.advertisement import Advertisement
from models.balance_log import BalanceLog
from logging import getLogger
logger = getLogger(__name__)

def create_app():
    """创建Flask应用"""
    app = Flask(__name__)
    
    # 配置
    app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'migration-only')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mall.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # 初始化扩展
    init_extensions(app)
    
    return app

def update_database():
    """更新数据库"""
    try:
        logger.info("开始更新数据库...")
        
        # 创建所有表
        db.create_all()
        logger.info("创建表完成")
        
        # 检查余额记录表是否存在
        inspector = db.inspect(db.engine)
        if 'balance_log' not in inspector.get_table_names():
            # 创建余额记录表
            with open('migrations/add_balance_log_table.sql', 'r', encoding='utf-8') as f:
                sql = f.read()
                db.session.execute(text(sql))
                db.session.commit()
                logger.info("创建余额记录表完成")

        # 检查USDT比例字段是否存在
        bot_config_columns = inspector.get_columns('bot_config')
        has_usdt_rate = any(col['name'] == 'usdt_rate' for col in bot_config_columns)
        if not has_usdt_rate:
            # 添加USDT比例字段
            with open('migrations/add_usdt_rate_field.sql', 'r', encoding='utf-8') as f:
                sql = f.read()
                db.session.execute(text(sql))
                db.session.commit()
                logger.info("添加USDT比例字段完成")
        
        # 检查backend_url字段是否存在
        has_backend_url = any(col['name'] == 'backend_url' for col in bot_config_columns)
        if not has_backend_url:
            # 添加backend_url字段
            with open('migrations/add_backend_url_field.sql', 'r', encoding='utf-8') as f:
                sql = f.read()
                db.session.execute(text(sql))
                db.session.commit()
                logger.info("添加易支付后端地址字段完成")

        # 检查product表中is_same_key字段是否存在
        product_columns = inspector.get_columns('product')
        has_is_same_key = any(col['name'] == 'is_same_key' for col in product_columns)
        if not has_is_same_key:
            # 添加is_same_key字段
            sql = "ALTER TABLE product ADD COLUMN is_same_key BOOLEAN DEFAULT 0"
            db.session.execute(text(sql))
            db.session.commit()
            logger.info("添加商品is_same_key字段完成")
        
        logger.info("数据库更新完成")
        
    except Exception as e:
        logger.info(f"更新数据库出错: {str(e)}")
        if hasattr(e, '__traceback__'):
            import traceback
            logger.info(traceback.format_exc())
        db.session.rollback()

if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        update_database() 
