from flask import Flask, render_template, jsonify, request, redirect, url_for
from flask_login import LoginManager, login_required
from extensions import init_extensions, db, login_manager
from models.user import User
from routes.auth import bp as auth_bp
from routes.dashboard import bp as dashboard_bp
from routes.config import bp as config_bp
from routes.category import bp as category_bp
from routes.product import bp as product_bp
from routes.user import bp as user_bp
from routes.advertisement import bp as advertisement_bp
from routes.order import bp as order_bp
from routes.withdrawal import bp as withdrawal_bp
from routes.broadcast import bp as broadcast_bp
from routes.balance_log import bp as balance_log_bp
import atexit
import os
import sys
import subprocess
import threading
import time
import psutil
import logging
import logging.handlers
import secrets
from datetime import datetime
from dotenv import load_dotenv
from werkzeug.middleware.proxy_fix import ProxyFix

load_dotenv()

# 创建logs目录（如果不存在）
log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# 配置日志格式
log_format = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# 配置文件日志处理器
file_handler = logging.handlers.RotatingFileHandler(
    os.path.join(log_dir, 'app.log'),
    maxBytes=10*1024*1024,  # 10MB
    backupCount=5,
    encoding='utf-8'
)
file_handler.setFormatter(log_format)
file_handler.setLevel(logging.DEBUG)

# 配置控制台处理器（INFO级别）
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(log_format)
console_handler.setLevel(logging.INFO)

# 配置根日志记录器
root_logger = logging.getLogger()
root_logger.setLevel(logging.DEBUG)  # 设置全局最低级别
root_logger.handlers.clear()  # 清除默认处理器
root_logger.addHandler(file_handler)
root_logger.addHandler(console_handler)

# 应用专用日志记录器
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)  # 可选：单独设置应用日志级别

# ===== 第三方库日志控制 =====
# 完全禁用werkzeug
logging.getLogger('werkzeug').disabled = True

# 限制其他库的日志级别
logging.getLogger('urllib3').setLevel(logging.WARNING)
logging.getLogger('TeleBot').setLevel(logging.INFO)  # 或WARNING
logging.getLogger('telebot').setLevel(logging.INFO)  # 某些版本用这个名称

# 可选：禁用asyncio的调试日志（如果有大量异步日志）
logging.getLogger('asyncio').setLevel(logging.WARNING)

# 全局变量
bot_process = None
bot_started = False

def monitor_output(process):
    """监控机器人进程的输出"""
    while True:
        try:
            # 读取输出
            line = process.stdout.readline()
            if not line and process.poll() is not None:
                break
            if line:
                # 直接打印输出
                sys.stdout.write(line)
                sys.stdout.flush()
        except Exception as e:
            logger.info(f"监控输出时出错: {str(e)}")
            break

def check_and_kill_existing_bot():
    """检查并清理已存在的机器人进程"""
    current_pid = os.getpid()
    bot_processes = []
    root_dir = os.path.dirname(os.path.abspath(__file__))
    expected_script = os.path.normcase(
        os.path.abspath(os.path.join(root_dir, 'bot', 'gouka_main.py'))
    )
    
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            # 跳过当前进程
            if proc.pid == current_pid:
                continue
            
            # 检查命令行参数
            cmdline = proc.cmdline()
            if len(cmdline) >= 2 and 'python' in cmdline[0].lower():
                candidate = os.path.normcase(os.path.abspath(cmdline[1]))
                if candidate == expected_script:
                    bot_processes.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    
    if bot_processes:
        logger.info("\n=== 发现已存在的机器人进程 ===")
        for proc in bot_processes:
            try:
                logger.info(f"正在终止进程 PID: {proc.pid}")
                proc.terminate()
                proc.wait(timeout=5)
            except psutil.TimeoutExpired:
                logger.info(f"强制终止进程 PID: {proc.pid}")
                proc.kill()
            except Exception as e:
                logger.info(f"终止进程 {proc.pid} 时出错: {str(e)}")
        logger.info("已清理所有已存在的机器人进程")

def start_bot_system():
    """启动机器人系统"""
    global bot_process
    if bot_process is not None:
        return
    
    try:
        # 检查并清理已存在的进程
        check_and_kill_existing_bot()
        
        # 获取当前Python解释器路径
        python_executable = sys.executable
        logger.info(f"使用Python解释器: {python_executable}")
        
        # 获取项目根目录
        root_dir = os.path.dirname(os.path.abspath(__file__))
        main_path = os.path.join(root_dir, 'bot', 'gouka_main.py')
        logger.info(f"项目根目录: {root_dir}")
        logger.info(f"主程序路径: {main_path}")
        
        # 检查gouka_main是否存在
        if not os.path.exists(main_path):
            raise FileNotFoundError(f"找不到主程序文件: {main_path}")
        
        # 获取当前环境变量
        env = os.environ.copy()
        
        # 设置环境变量以处理编码问题
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUNBUFFERED'] = '1'  # 禁用输出缓冲
        
        # 如果是虚拟环境，确保PYTHONPATH包含项目根目录
        if 'VIRTUAL_ENV' in env:
            logger.info(f"检测到虚拟环境: {env['VIRTUAL_ENV']}")
            python_path = env.get('PYTHONPATH', '')
            if root_dir not in python_path:
                env['PYTHONPATH'] = f"{root_dir}{os.pathsep}{python_path}" if python_path else root_dir
                logger.info(f"设置PYTHONPATH: {env['PYTHONPATH']}")
        
        logger.info("\n=== 正在启动机器人系统 ===")
        
        # 使用subprocess.Popen启动gouka_main
        startupinfo = None
        if os.name == 'nt':  # Windows系统
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
        
        bot_process = subprocess.Popen(
            [python_executable, main_path],
            env=env,
            cwd=root_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # 将错误输出重定向到标准输出
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
            encoding='utf-8',
            errors='replace',
            bufsize=1  # 行缓冲
        )
        
        logger.info(f"机器人进程已启动 (PID: {bot_process.pid})")
        
        # 启动输出监控线程
        output_thread = threading.Thread(target=monitor_output, args=(bot_process,))
        output_thread.daemon = True
        output_thread.start()
        
        logger.info("机器人系统已启动")
        
    except Exception as e:
        logger.info(f"启动机器人系统失败: {str(e)}")
        if hasattr(e, '__traceback__'):
            import traceback
            logger.info(traceback.format_exc())
        # 如果启动失败，确保清理进程
        if bot_process is not None:
            try:
                bot_process.kill()
            except:
                pass
            bot_process = None

def stop_bot_system():
    """停止机器人系统"""
    global bot_process
    if bot_process is not None:
        try:
            bot_process.terminate()
            bot_process.wait(timeout=5)  # 等待最多5秒
        except subprocess.TimeoutExpired:
            bot_process.kill()  # 如果无法正常终止，强制结束
        except Exception as e:
            logger.info(f"停止机器人系统时出错: {str(e)}")
        finally:
            bot_process = None
            logger.info("机器人系统已停止")
            

def create_app():
    """创建Flask应用"""
    app = Flask(__name__)
    
    # 配置
    app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY') or secrets.token_hex(32)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
        'DATABASE_URL', 'sqlite:///mall.db'
    )
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['SESSION_COOKIE_SECURE'] = (
        os.environ.get('SESSION_COOKIE_SECURE', '0') == '1'
    )

    if os.environ.get('TRUST_PROXY_HEADERS', '0') == '1':
        app.wsgi_app = ProxyFix(
            app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1
        )
    
    # 初始化扩展
    init_extensions(app)
    
    # 初始化登录管理器
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    
    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, user_id)
    
    # 注册蓝图
    from routes import (
        auth, dashboard, product, category, user, config,
        withdrawal, advertisement, broadcast, balance_log, order, logs
    )
    app.register_blueprint(auth.bp)
    app.register_blueprint(dashboard.bp)
    app.register_blueprint(product.bp)
    app.register_blueprint(category.bp)
    app.register_blueprint(user.bp)
    app.register_blueprint(config.bp)
    app.register_blueprint(withdrawal.bp)
    app.register_blueprint(advertisement.bp)
    app.register_blueprint(broadcast.bp)
    app.register_blueprint(balance_log.bp)
    app.register_blueprint(order.bp)
    app.register_blueprint(logs.bp)

    @app.route('/okpay', methods=['GET', 'POST'])
    def okpay():
        """处理支付回调"""
        if os.environ.get('ENABLE_PAYMENT_CALLBACKS', '1') != '1':
            return 'payment callbacks disabled', 503
        try:
            # 记录回调数据
            logger.info(f"收到支付回调: args={request.args}")
            logger.info(f"收到支付回调: form={request.form}")
            logger.info(f"收到支付回调: data={request.data}")
            logger.info(f"收到支付回调: json={request.get_json(silent=True)}")
            logger.info(f"请求方法: {request.method}")
            logger.info(f"请求headers: {dict(request.headers)}")

            # 获取回调参数（福利来POST JSON）
            data = request.get_json(silent=True)
            if not data:
                logger.error("未收到有效的JSON数据")
                return 'fail'

            # 解析订单号
            # data结构: {'code': 200, 'data': {...}, 'id': ..., 'status': ..., 'sign': ...}
            pay_data = data.get('data', {})
            trade_no = pay_data.get('order_id')  # 支付平台订单号
            out_trade_no = pay_data.get('unique_id')  # 商户订单号
            trade_status = data.get('status')  # 'success'/'fail'

            logger.info(f"trade_no: {trade_no}")
            logger.info(f"out_trade_no: {out_trade_no}")
            logger.info(f"trade_status: {trade_status}")

            # 查找订单
            order = Order.query.filter_by(payment_no=trade_no).first()
            if not order:
                logger.error(f"未找到对应订单: {trade_no}")
                return 'fail'

            # 更新订单状态
            if order.status == 'pending' and trade_status == 'success':
                order.status = 'paid'
                order.payment_time = datetime.utcnow()
                db.session.commit()
                logger.info(f"订单支付成功: {order.id}")
            
            return 'success'
            
        except Exception as e:
            logger.error(f"处理支付回调失败: {str(e)}")
            return 'fail'

    @app.route('/fll', methods=['GET', 'POST'])
    def fll():
        """处理福利来支付回调"""
        if os.environ.get('ENABLE_PAYMENT_CALLBACKS', '1') != '1':
            return 'payment callbacks disabled', 503
        try:
            logger.info(f"收到福利来支付回调: args={request.args}")
            logger.info(f"收到福利来支付回调: form={request.form}")
            logger.info(f"收到福利来支付回调: data={request.data}")
            logger.info(f"收到福利来支付回调: json={request.get_json(silent=True)}")
            logger.info(f"请求方法: {request.method}")
            logger.info(f"请求headers: {dict(request.headers)}")

            # 只处理GET请求，且biz_order_id和sign必须存在
            if request.method == 'GET':
                biz_order_id = request.args.get('biz_order_id')
                sign = request.args.get('sign')
                if not biz_order_id or not sign:
                    logger.error("缺少biz_order_id或sign参数")
                    return 'fail'

                # 查找id
                order = Order.query.filter_by(id=biz_order_id).first()
                if not order:
                    logger.error(f"未找到对应订单: {biz_order_id}")
                    return 'fail'

                # 只在订单为pending时更新
                if order.status == 'pending':
                    order.status = 'paid'
                    order.payment_time = datetime.utcnow()
                    db.session.commit()
                    logger.info(f"订单支付成功: {order.id}")

                return 'success'
            else:
                logger.error("不支持的请求方法")
                return 'fail'
        except Exception as e:
            logger.error(f"处理福利来支付回调失败: {str(e)}")
            return 'fail'

    @app.route('/notify', methods=['GET'])
    def notify():
        """处理支付回调"""
        if os.environ.get('ENABLE_PAYMENT_CALLBACKS', '1') != '1':
            return 'payment callbacks disabled', 503
        try:
            # 记录回调数据
            logger.info(f"收到支付回调: {request.args}")
            
            # 获取回调参数
            trade_no = request.args.get('out_trade_no')  # 商户订单号
            trade_status = request.args.get('trade_status')  # 交易状态

            logger.info(f"trade_no: {trade_no}")
            logger.info(f"trade_status: {trade_status}")
            
            # 查找订单
            order = Order.query.filter_by(payment_no=trade_no).first()
            if not order:
                logger.error(f"未找到对应订单: {trade_no}")
                return 'fail'
            
            # 更新订单状态
            if order.status == 'pending':
                order.status = 'paid'
                order.payment_time = datetime.utcnow()
                db.session.commit()
                logger.info(f"订单支付成功: {order.id}")
            return 'success'
            
        except Exception as e:
            logger.error(f"处理支付回调失败: {str(e)}")
            return 'fail'
    
    with app.app_context():
        # 导入所有模型以确保创建所有表
        from models.user import User
        from models.config import BotConfig
        from models.order import Order
        from models.product import Product
        from models.category import Category
        from models.withdrawal import Withdrawal
        from models.advertisement import Advertisement

        # 检查数据库表是否存在
        inspector = db.inspect(db.engine)
        tables = inspector.get_table_names()
        
        # 如果表不存在，创建所有表
        if not tables:
            logger.info("数据库表不存在，正在创建...")
            db.create_all()
            logger.info("数据库表创建成功")
        
        # 初始化管理员用户
        init_admin_user()
    
    # 初始化群发服务
    from bot.broadcast_service import BroadcastService
    broadcast_service = BroadcastService()
    broadcast_service.init_app(app)
    
    @app.route('/api/system/restart', methods=['POST'])
    @login_required
    def restart_system():
        try:
            stop_bot_system()
            start_bot_system()
            return jsonify({
                'success': True,
                'message': '系统重启成功'
            })
        except Exception as e:
            return jsonify({
                'success': False,
                'message': f'系统重启失败: {str(e)}'
            }), 500
    
    return app

def start_bot_in_thread():
    """在后台线程中启动机器人系统"""
    def run():
        try:
            with app.app_context():
                start_bot_system()
        except Exception as e:
            logger.info(f"启动机器人系统时出错: {str(e)}")
    
    thread = threading.Thread(target=run)
    thread.daemon = True
    thread.start()

# 初始化登录管理器
login_manager = LoginManager()

def init_admin_user():
    """初始化管理员用户"""
    try:
        admin_username = os.environ.get('ADMIN_USERNAME', 'admin')
        admin_password = os.environ.get('ADMIN_PASSWORD')
        if not admin_password:
            logger.warning("ADMIN_PASSWORD 未设置，跳过初始管理员创建")
            return

        # 检查管理员用户是否存在
        admin = User.query.filter_by(
            username=admin_username,
            bot_username='@admin'  # 使用固定的管理员机器人用户名
        ).first()
        
        if not admin:
            # 创建管理员用户
            admin = User(
                telegram_id='admin',  # 使用固定的管理员ID
                username=admin_username,
                nickname='管理员',
                bot_username='@admin',  # 使用固定的管理员机器人用户名
                balance=0.0,
                password_hash='default'
            )
            admin.password = admin_password
            db.session.add(admin)
            db.session.commit()
            logger.info("管理员用户创建成功")
        else:
            logger.info("管理员用户已存在")
    except Exception as e:
        logger.info(f"初始化管理员用户失败: {str(e)}")
        db.session.rollback()

def cleanup():
    """清理函数"""
    stop_bot_system()

if __name__ == '__main__':
    app = create_app()
    
    # 注册清理函数
    atexit.register(cleanup)
    
    logger.info("\n=== 正在启动 Flask 应用 ===")
    
    # Bot polling is opt-in so a local UI test never contacts Telegram.
    if (os.environ.get('ENABLE_BOT_SYSTEM', '1') == '1'
            and not os.environ.get('WERKZEUG_RUN_MAIN')):
        start_bot_in_thread()
    
    # 启动 Flask 应用
    app.run(
        host=os.environ.get('APP_HOST', '0.0.0.0'),
        port=int(os.environ.get('APP_PORT', '5002')),
        debug=os.environ.get('FLASK_DEBUG', '0') == '1',
        use_reloader=False,
    )
