# Security review

Reviewed source: `C:\Users\Administrator\Desktop\电报机器人源码+教程`

## Scan result

- Microsoft Defender custom scan completed with signature `1.459.120.0` (updated 2026-09-09).
- The scan produced zero new detections.
- No PE executables, DLLs, PowerShell, batch, VBS, MSI, JAR, or shortcut payloads were present in the effective project tree.
- Static searches found no `eval`, `exec`, `marshal`, `pickle`, Base64 loader, shell command, registry persistence, or scheduled-task chain.

This is evidence against common malware, not a proof that the code is harmless.

## High-risk findings

- Distributed logs expose real Telegram bot tokens, payment credentials, Telegram user IDs, usernames, order data, and payment URLs. All exposed credentials must be revoked or rotated.
- All 10 bundled backup databases contain non-empty bot/payment credentials; individual backups contain between 7 and 113 user records. None were copied into the runnable build.
- The original app listens on `0.0.0.0:5002`, enables Flask debug mode, uses a static session secret, and creates `admin/admin`.
- Three unauthenticated payment callbacks can mark orders paid without cryptographically verifying the provider signature. They remain disabled in this local build.
- One payment integration replaced a loopback callback URL with a hard-coded third-party domain and used a hard-coded Telegram return account. Those substitutions were removed.
- One payment request disabled TLS certificate verification. Normal certificate verification is restored.
- Bot and payment secrets are stored in plaintext and returned by the configuration API to authenticated users.
- Frontend dependencies are loaded from public CDNs without Subresource Integrity.

## Local-run controls

- The copied project contains no downloaded logs, databases, bytecode caches, or macOS metadata.
- It binds only to `127.0.0.1`, disables debug mode, and uses generated secrets.
- `run-local.ps1` disables Telegram polling and payment callbacks for local UI testing.
- Normal server startup keeps Telegram polling and payment callbacks enabled.
- A non-default administrator password is required through `ADMIN_PASSWORD`.

Do not expose this application to the internet until callback signature verification, CSRF protection, secret storage, dependency review, and production WSGI deployment are implemented.
