from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from models.category import Category
from models.order import Order
from models.product import Product
from models.user import User
from extensions import db
from handlers.base_handler import BaseHandler
from logging import getLogger
logger = getLogger(__name__)

def create_main_keyboard():
    """创建主键盘"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row(
        KeyboardButton("📁 分类列表"),
        KeyboardButton("🛍 商品列表")
    )
    keyboard.row(
        KeyboardButton("📋 订单列表"),
        KeyboardButton("👤 个人中心")
    )
    keyboard.row(
        KeyboardButton("💰 余额充值"),
        KeyboardButton("📞 联系客服")
    )
    keyboard.row(
        KeyboardButton("🔄 免費克隆")
    )
    return keyboard

class CommandHandlers(BaseHandler):
    def __init__(self, bot_instance):
        self.bot = bot_instance.bot
        self.config = bot_instance.config
        self.app = bot_instance.app
    
    def show_categories(self, message, parent_id=None):
        """显示分类列表
        Args:
            message: Telegram消息对象
            parent_id: 父分类ID，None表示显示顶级分类
        """
        # 查询分类
        if parent_id is None:
            # 查询顶级分类（没有父分类的）
            categories = Category.query.filter(
                ~Category.parents.any()  # 没有父分类的
            ).order_by(Category.sort_index.asc()).all()
        else:
            # 查询指定父分类的子分类
            parent = Category.query.get(parent_id)
            if not parent:
                self.bot.reply_to(message, "分类不存在")
                return
            categories = parent.children.order_by(Category.sort_index.asc()).all()
            
            # 如果没有子分类，显示该分类下的商品
            if not categories:
                return self.show_category_products(message, parent_id)
        
        if not categories:
            self.bot.reply_to(message, "暂无分类")
            return
        
        # 创建内联键盘
        keyboard = InlineKeyboardMarkup()
        for cat in categories:
            # 检查是否有子分类
            has_children = cat.children.count() > 0
            button_text = f"📁 {cat.name}" if has_children else f"📦 {cat.name}"
            callback_data = f"cat_{cat.id}"
            keyboard.add(InlineKeyboardButton(button_text, callback_data=callback_data))
        
        # 如果不是顶级分类，添加返回按钮
        if parent_id is not None:
            parent_of_parent = Category.query.filter(Category.children.any(id=parent_id)).first()
            back_id = parent_of_parent.id if parent_of_parent else None
            keyboard.add(InlineKeyboardButton("⬅️ 返回上级", callback_data=f"cat_{back_id}" if back_id else "cat_root"))
        
        # 发送分类列表消息
        msg = "📁 分类列表：\n\n"
        if parent_id is not None:
            parent = Category.query.get(parent_id)
            msg = f"📁 {parent.name} - 子分类：\n\n"
        
        self.bot.reply_to(message, msg, reply_markup=keyboard)
    
    def show_category_products(self, message, category_id):
        """显示分类下的商品"""
        try:
            category = Category.query.get(category_id)
            if not category:
                self.bot.reply_to(message, "分类不存在")
                return
            
            products = Product.query.filter_by(
                category_id=category_id,
                is_active=True
            ).order_by(Product.sort_index.asc()).all()
            
            if not products:
                # 创建返回按钮
                keyboard = InlineKeyboardMarkup()
                parent = Category.query.filter(Category.children.any(id=category_id)).first()
                back_id = parent.id if parent else None
                keyboard.add(InlineKeyboardButton("⬅️ 返回上级", callback_data=f"cat_{back_id}" if back_id else "cat_root"))
                
                self.bot.reply_to(
                    message,
                    f"📁 {category.name}\n\n暂无商品",
                    reply_markup=keyboard
                )
                return
            
            # 创建商品列表键盘
            keyboard = InlineKeyboardMarkup()
            # 按库存量排序,库存为0的排在最后
            sorted_products = sorted(products, key=lambda p: (p.total_keys - p.used_keys == 0, -(p.total_keys - p.used_keys)))
            for product in sorted_products:
                available = product.total_keys - product.used_keys
                button_text = f"💎 {product.name} (${product.price:.2f}) [{available}]"
                keyboard.add(InlineKeyboardButton(button_text, callback_data=f"prod_{product.id}"))
            
            # 添加返回按钮
            parent = Category.query.filter(Category.children.any(id=category_id)).first()
            back_id = parent.id if parent else None
            keyboard.add(InlineKeyboardButton("⬅️ 返回上级", callback_data=f"cat_{back_id}" if back_id else "cat_root"))
            
            # 发送商品列表
            msg = f"📁 {category.name} - 商品列表：\n\n"
            msg += "选择商品查看详情\n"
            msg += "💎 商品名称 (单价) [库存]"
            
            self.bot.reply_to(message, msg, reply_markup=keyboard)
            
        except Exception as e:
            logger.info(f"[Bot] 显示分类商品出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，获取商品列表失败，请稍后重试")
    
    def show_products(self, message):
        """显示商品列表"""
        try:
            products = Product.query.filter_by(is_active=True).order_by(Product.sort_index.asc()).all()
            
            if not products:
                self.bot.reply_to(message, "暂无商品")
                return
            
            # 创建商品列表键盘
            keyboard = InlineKeyboardMarkup()
            
            # 按库存量排序,库存为0的排在最后
            sorted_products = sorted(
                products,
                key=lambda p: (
                    0 if (99999 if p.is_same_key else p.total_keys - p.used_keys) == 0 else 1,
                    -(99999 if p.is_same_key else p.total_keys - p.used_keys),
                ),
            )
            
            for product in sorted_products:
                available = 99999 if product.is_same_key else product.total_keys - product.used_keys
                # 计算最终价格(包含所有返佣)
                final_price = self.calculate_final_price(product.price)
                button_text = f"💎 {product.name} (${final_price:.2f}) [{available}]"
                keyboard.add(
                    InlineKeyboardButton(button_text, callback_data=f"prod_{product.id}")
                )
            
            # 发送商品列表
            msg = "🛍 商品列表：\n\n"
            msg += "选择商品查看详情\n"
            msg += "💎 商品名称 (单价) [库存]"
            
            self.bot.reply_to(message, msg, reply_markup=keyboard)
            
        except Exception as e:
            logger.error(f"[Bot] 显示商品列表出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，获取商品列表失败，请稍后重试")
    
    def show_orders(self, message):
        """显示订单列表"""
        user_id = str(message.from_user.id)
        orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()
        
        if not orders:
            self.bot.reply_to(message, "您还没有任何订单")
            return
        
        msg = "📋 您的订单列表：\n\n"
        for order in orders:
            msg += f"订单号：{order.id}\n"
            msg += f"商品：{order.product.name}\n"
            msg += f"数量：{order.quantity}\n"
            msg += f"金额：${order.total_amount:.2f}\n"
            msg += f"状态：{self.get_order_status(order.status)}\n"
            msg += f"时间：{order.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        
        self.bot.reply_to(message, msg)
    
    def show_profile(self, message):
        """显示个人中心"""
        user_id = str(message.from_user.id)
        user = User.query.filter_by(
            telegram_id=str(user_id),
            bot_username=self.config.bot_username
        ).first()
        
        if not user:
            self.bot.reply_to(message, "获取用户信息失败")
            return
        
        msg = "👤 个人中心\n\n"
        msg += f"用户ID：{user.id}\n"
        msg += f"用户名：{user.username}\n"
        msg += f"昵称：{user.nickname}\n"
        msg += f"余额：${user.balance:.2f}\n"
        msg += f"注册时间：{user.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n"
        
        self.bot.reply_to(message, msg)
    
    def show_recharge(self, message):
        """显示充值信息"""
        try:
            # 创建充值选项键盘
            keyboard = InlineKeyboardMarkup()
            
            # USDT充值选项
            keyboard.row(
                InlineKeyboardButton("💎 10 USDT", callback_data="recharge_10"),
                InlineKeyboardButton("💎 20 USDT", callback_data="recharge_20")
            )
            keyboard.row(
                InlineKeyboardButton("💎 50 USDT", callback_data="recharge_50"),
                InlineKeyboardButton("💎 100 USDT", callback_data="recharge_100")
            )
            keyboard.row(
                InlineKeyboardButton("💎 200 USDT", callback_data="recharge_200"),
                InlineKeyboardButton("💎 500 USDT", callback_data="recharge_500")
            )
            keyboard.row(
                InlineKeyboardButton("💎 自定义金额", callback_data="recharge_custom")
            )
            
            # 发送充值信息
            msg = "💰 余额充值\n\n"
            msg += "请选择充值金额，或点击自定义金额输入其他金额\n"
            msg += "支持USDT-TRC20充值\n\n"
            msg += "当前余额：${:.2f}".format(
                User.query.filter_by(
                    telegram_id=str(message.from_user.id),
                    bot_username=self.config.bot_username
                ).first().balance
            )
            
            self.bot.reply_to(message, msg, reply_markup=keyboard)
            
        except Exception as e:
            logger.error(f"[Bot] 显示充值信息出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，获取充值信息失败，请稍后重试")
    
    def contact_support(self, message):
        """显示客服联系方式"""
        try:
            # 创建客服联系键盘
            keyboard = InlineKeyboardMarkup()
            
            # 添加客服联系按钮
            if self.config.support_username:
                keyboard.add(
                    InlineKeyboardButton(
                        "💬 联系客服",
                        url=f"https://t.me/{self.config.support_username.lstrip('@')}"
                    )
                )
            
            # 发送客服信息
            msg = "📞 客服服务\n\n"
            msg += "如果您有任何问题，请点击下方按钮联系客服\n"
            msg += "工作时间：24小时\n\n"
            
            if self.config.support_username:
                msg += f"客服账号：@{self.config.support_username.lstrip('@')}"
            else:
                msg += "暂无客服信息"
            
            self.bot.reply_to(message, msg, reply_markup=keyboard)
            
        except Exception as e:
            logger.error(f"[Bot] 显示客服信息出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，获取客服信息失败，请稍后重试")
    
    def show_clone_info(self, message):
        """显示克隆信息"""
        try:
            if not self.config.allow_clone:
                self.bot.reply_to(message, "抱歉，当前机器人未开启克隆功能")
                return
            
            # 创建克隆信息键盘
            keyboard = InlineKeyboardMarkup()
            keyboard.add(
                InlineKeyboardButton(
                    "🤖 开始克隆",
                    callback_data="clone_start"
                )
            )
            
            # 发送克隆信息
            msg = "🔄 机器人克隆\n\n"
            msg += "点击下方按钮开始克隆机器人\n"
            msg += "克隆后您将获得一个完全相同的机器人\n\n"
            msg += "克隆说明：\n"
            msg += "1. 完全免费\n"
            msg += "2. 独立后台\n"
            msg += "3. 分成系统\n"
            msg += "4. 技术支持\n"
            
            self.bot.reply_to(message, msg, reply_markup=keyboard)
            
        except Exception as e:
            logger.error(f"[Bot] 显示克隆信息出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，获取克隆信息失败，请稍后重试")
    
    def handle_buy_command(self, message, product_id):
        """处理购买命令"""
        try:
            product = Product.query.get(product_id)
            if not product:
                self.bot.reply_to(message, "商品不存在或已下架")
                return
            
            # TODO: 实现购买逻辑
            self.bot.reply_to(message, "购买功能开发中...")
        except Exception as e:
            logger.info(f"[Bot] 处理购买命令出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，处理购买请求时出现错误")
    
    def handle_pay_command(self, message, order_id):
        """处理支付命令"""
        try:
            order = Order.query.get(order_id)
            if not order:
                self.bot.reply_to(message, "订单不存在")
                return
            
            if order.user_id != str(message.from_user.id):
                self.bot.reply_to(message, "这不是您的订单")
                return
            
            # TODO: 实现支付逻辑
            self.bot.reply_to(message, "支付功能开发中...")
        except Exception as e:
            logger.info(f"[Bot] 处理支付命令出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，处理支付请求时出现错误")
    
    def get_order_status(self, status):
        """获取订单状态的中文描述"""
        status_map = {
            'pending': '待支付',
            'paid': '已支付',
            'completed': '已完成',
            'cancelled': '已取消',
            'failed': '失败'
        }
        return status_map.get(status, status) 

    def setup_handlers(self):
        from telebot.types import InlineQueryResultArticle, InputTextMessageContent, BotCommand
        """设置所有命令处理器"""
        
        # 设置命令菜单
        commands = [
            BotCommand("start", "开始使用"),
            BotCommand("products", "购买会员"), 
            BotCommand("profile", "个人中心"),
            BotCommand("recharge", "充值余额"),
            BotCommand("orders", "我的订单"),
            BotCommand("support", "联系客服"),
            BotCommand("help", "帮助信息")
        ]
        try:
            self.bot.set_my_commands(commands)
        except Exception as e:
            logger.error(f"设置命令菜单失败: {str(e)}")
        
        # 商品列表命令
        @self.bot.message_handler(commands=['products'])
        def products(message):
            with self.app.app_context():
                try:
                    self.show_products(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理商品列表命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 分类列表命令
        @self.bot.message_handler(commands=['categories'])
        def categories(message):
            with self.app.app_context():
                try:
                    self.show_categories(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理分类列表命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 订单列表命令
        @self.bot.message_handler(commands=['orders'])
        def orders(message):
            with self.app.app_context():
                try:
                    self.show_orders(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理订单列表命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 个人中心命令
        @self.bot.message_handler(commands=['profile'])
        def profile(message):
            with self.app.app_context():
                try:
                    self.show_profile(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理个人中心命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 余额充值命令
        @self.bot.message_handler(commands=['recharge'])
        def recharge(message):
            with self.app.app_context():
                try:
                    self.show_recharge(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理余额充值命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 联系客服命令
        @self.bot.message_handler(commands=['support'])
        def support(message):
            with self.app.app_context():
                try:
                    self.contact_support(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理联系客服命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 服务器状态命令
        @self.bot.message_handler(commands=['server_status'])
        def server_status(message):
            with self.app.app_context():
                try:
                    import psutil
                    import os
                    cpu_percent = psutil.cpu_percent(interval=1)
                    mem = psutil.virtual_memory()
                    mem_percent = mem.percent
                    disk = psutil.disk_usage('/')
                    disk_percent = disk.percent
                    cpu_count = psutil.cpu_count()
                    
                    msg = (
                        f"🖥 服务器状态:\n"
                        f"------------------\n"
                        f"🌐 后端地址: {self.config.backend_url}\n"
                        f"💻 CPU核心数: {cpu_count}\n"
                        f"📊 CPU使用率: {cpu_percent}%\n"
                        f"📈 内存使用率: {mem_percent}%\n"
                        f"💾 磁盘使用率: {disk_percent}%\n"
                    )
                    self.bot.reply_to(message, msg, parse_mode="HTML")
                except Exception as e:
                    logger.error(f"[Bot] 获取服务器状态失败: {str(e)}")
                    self.bot.reply_to(message, "获取服务器状态失败")

        # Start命令处理
        @self.bot.message_handler(commands=['start'])
        def start(message):
            with self.app.app_context():
                try:
                    logger.info(f"[Bot] 用户进入: {message.from_user.to_dict()}")
                    # 检查用户是否存在
                    user_id = str(message.from_user.id)
                    user = User.query.filter_by(id=user_id).first()
                    
                    if not user:
                        # 创建新用户
                        try:
                            # 生成基础用户名
                            base_username = message.from_user.username or f"user_{user_id}"
                            username = base_username
                            counter = 1
                            while User.query.filter_by(username=username).first():
                                username = f"{base_username}_{counter}"
                                counter += 1
                            
                            user = User(
                                id=user_id,
                                username=username,
                                nickname=message.from_user.first_name or username,
                                bot_username=self.config.bot_username,
                                balance=0.0,
                                password_hash='default'
                            )
                            db.session.add(user)
                            db.session.commit()
                            logger.info(f"[Bot] 新用户注册成功: {user.to_dict()}")
                        except Exception as e:
                            logger.info(f"[Bot] 创建用户失败: {str(e)}")
                            db.session.rollback()
                            self.bot.reply_to(message, "注册失败，请稍后重试。")
                            return
                    
                    # 检查是否有start参数
                    args = message.text.split()
                    if len(args) > 1:
                        # 处理start参数
                        param = args[1]
                        if param.startswith('buy_'):
                            # 处理购买命令
                            try:
                                product_id = int(param.split('_')[1])
                                self.handle_buy_command(message, product_id)
                                return
                            except (IndexError, ValueError):
                                pass
                        elif param.startswith('pay_'):
                            # 处理支付命令
                            try:
                                order_id = param.split('_')[1]
                                self.handle_pay_command(message, order_id)
                                return
                            except IndexError:
                                pass
                    
                    # 发送欢迎消息
                    welcome_msg = f"欢迎使用 {self.config.bot_username}！"
                    if self.config.announcement and self.config.announcement.strip():
                        welcome_msg += f"\n\n{self.config.announcement}"
                    
                    # 发送带键盘的欢迎消息
                    self.bot.reply_to(message, welcome_msg, reply_markup=create_main_keyboard())
                    
                except Exception as e:
                    logger.info(f"[Bot] 处理start命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理您的请求时出现错误，请稍后重试。")
        
        # 处理文本消息
        @self.bot.message_handler(func=lambda message: True)
        def handle_text(message):
            with self.app.app_context():
                try:
                    if message.text == "📁 分类列表":
                        self.show_categories(message)
                    elif message.text == "🛍 商品列表":
                        self.show_products(message)
                    elif message.text == "📋 订单列表":
                        self.show_orders(message)
                    elif message.text == "👤 个人中心":
                        self.show_profile(message)
                    elif message.text == "💰 余额充值":
                        self.show_recharge(message)
                    elif message.text == "📞 联系客服":
                        self.contact_support(message)
                    elif message.text == "🔄 免費克隆":
                        self.show_clone_info(message)
                except Exception as e:
                    logger.info(f"[Bot] 处理消息出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理您的请求时出现错误，请稍后重试。")
        
        
        @self.bot.inline_handler(lambda query: True)
        def handle_inline_query(inline_query):
            try:
                query = inline_query.query.strip()  # 用户输入的搜索词
                logger.info(f"[Bot] 收到内联查询: 用户ID={inline_query.from_user.id}, 查询内容='{query}'")
                results = []

                if query:
                    # 从商品数据库中搜索
                    from models.product import Product
                    from telebot.types import InlineQueryResultArticle, InputTextMessageContent, InlineKeyboardMarkup, InlineKeyboardButton

                    with self.app.app_context():
                        # 模糊搜索商品名称和描述
                        products = Product.query.filter(
                            Product.is_active == True,
                            (Product.name.ilike(f"%{query}%")) | (Product.description.ilike(f"%{query}%"))
                        ).limit(10).all()
                        logger.info(f"[Bot] 内联查询结果数量: {len(products)}")

                        for product in products:
                            title = product.name
                            description = product.description[:50] if product.description else ""
                            final_price = self.calculate_final_price(product.price)
                            price = f"{final_price:.2f} USDT"
                            # 构建商品详情文案
                            msg = f"🛍 商品：{product.name}\n💰 价格：{price}\n\n{product.description or ''}"

                            # 构建内联键盘，包含购买和分享按钮
                            keyboard = InlineKeyboardMarkup()
                            # 购买按钮
                            keyboard.add(
                                InlineKeyboardButton(
                                    text="🛒 立即购买",
                                    callback_data=f"buy_{product.id}"
                                )
                            )
                            # 分享按钮，允许分享到其他群组/个人
                            share_url = f"https://t.me/{self.config.bot_username}?start=buy_{product.id}"
                            keyboard.add(
                                InlineKeyboardButton(
                                    text="🔗 分享给好友",
                                    switch_inline_query=product.name  # 让用户可以一键转发到其他聊天
                                )
                            )

                            result = InlineQueryResultArticle(
                                id=str(product.id),
                                title=title,
                                input_message_content=InputTextMessageContent(
                                    message_text=msg
                                ),
                                description=description if description else price,
                                reply_markup=keyboard
                            )
                            results.append(result)
                            logger.info(f"[Bot] 内联查询添加商品: {title} (ID: {product.id})")

                # 返回搜索结果
                self.bot.answer_inline_query(inline_query.id, results)
                logger.info(f"[Bot] 已返回内联查询结果，共{len(results)}条")

            except Exception as e:
                logger.error(f"处理内联查询出错: {e}")
                self.bot.answer_inline_query(inline_query.id, [])

        # 添加回调查询处理器
        @self.bot.callback_query_handler(func=lambda call: True)
        def handle_callback_query(call):
            with self.app.app_context():
                try:
                    if call.data == "cat_root":
                        # 显示顶级分类
                        self.show_categories(call.message)
                    elif call.data.startswith("cat_"):
                        # 显示子分类或商品
                        category_id = int(call.data.split("_")[1]) if call.data.split("_")[1] != "None" else None
                        self.show_categories(call.message, category_id)
                    elif call.data.startswith("prod_"):
                        # 显示商品详情
                        product_id = int(call.data.split("_")[1])
                        self.show_product_detail(call.message, product_id, call)
                    
                    # 删除回调查询通知
                    self.bot.answer_callback_query(call.id)
                except Exception as e:
                    logger.info(f"[Bot] 处理回调查询出错: {str(e)}")
                    self.bot.answer_callback_query(call.id, "处理请求时出错，请重试")
    
    def show_product_detail(self, message, product_id, call=None):
        """显示商品详情"""
        try:
            product = Product.query.get(product_id)
            if not product:
                self.bot.reply_to(message, "商品不存在或已下架")
                return
            
            # 创建商品详情键盘
            keyboard = InlineKeyboardMarkup()
            available = product.total_keys - product.used_keys
            if available > 0:
                keyboard.add(InlineKeyboardButton("🛒 立即购买", callback_data=f"prod_{product_id}"))
            
            # 添加返回按钮
            # keyboard.add(InlineKeyboardButton("⬅️ 返回列表", callback_data=f"cat_{product.category_id}"))
            
            # 构建商品详情消息
            msg = f"💎 {product.name}\n\n"
            msg += f"价格：${product.price:.2f}\n"
            msg += f"库存：{available}\n"
            if product.description:
                msg += f"\n{product.description}"
            
            try:
                # 判断是普通消息还是inline_message_id推送
                if hasattr(message, "chat") and hasattr(message, "message_id"):
                    # 普通消息
                    self.bot.reply_to(message, msg, reply_markup=keyboard)
                elif call is not None and hasattr(call, "inline_message_id") and call.inline_message_id:
                    # inline_message_id推送
                    self.bot.edit_message_text(
                        msg,
                        inline_message_id=call.inline_message_id,
                        reply_markup=keyboard
                    )
                else:
                    # 兜底，尝试reply_to
                    self.bot.reply_to(message, msg, reply_markup=keyboard)
            except Exception as e:
                print(call, e)
                
            
        except Exception as e:
            logger.info(f"[Bot] 显示商品详情出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，获取商品详情失败，请稍后重试") 