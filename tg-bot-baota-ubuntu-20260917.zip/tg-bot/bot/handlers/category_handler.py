from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from models.category import Category
from models.product import Product
from .base_handler import BaseHandler
from logging import getLogger
logger = getLogger(__name__)

class CategoryHandler(BaseHandler):
    def show_categories(self, message, parent_id=None):
        """显示分类列表"""
        with self.app.app_context():
            # 查询分类
            if parent_id is None:
                # 查询顶级分类（没有父分类的）
                categories = Category.query.filter(
                    ~Category.parents.any()  # 没有父分类的
                ).order_by(Category.sort_index.asc()).all()
            else:
                # 查询指定父分类的子分类
                parent = Category.query.get(parent_id)
                if not parent:
                    self.bot.reply_to(message, "分类不存在")
                    return
                categories = parent.children.order_by(Category.sort_index.asc()).all()
                
                # 如果没有子分类，显示该分类下的商品
                if not categories:
                    return self.show_category_products(message, parent_id)
            
            if not categories:
                self.bot.reply_to(message, "暂无分类")
                return
            
            # 创建内联键盘
            keyboard = InlineKeyboardMarkup()
            for cat in categories:
                # 检查是否有子分类
                has_children = cat.children.count() > 0
                button_text = f"📁 {cat.name}" if has_children else cat.name
                callback_data = f"cat_{cat.id}"
                keyboard.add(InlineKeyboardButton(button_text, callback_data=callback_data))
            
            # 如果不是顶级分类，添加返回按钮
            if parent_id is not None:
                parent_of_parent = Category.query.filter(Category.children.any(id=parent_id)).first()
                back_id = parent_of_parent.id if parent_of_parent else None
                keyboard.add(InlineKeyboardButton("⬅️ 返回上级", callback_data=f"cat_{back_id}" if back_id else "cat_root"))
            
            # 发送分类列表消息
            msg = "📁 分类列表：\n\n"
            if parent_id is not None:
                parent = Category.query.get(parent_id)
                msg = f"📁 {parent.name} - 子分类：\n\n"
            
            self.bot.reply_to(message, msg, reply_markup=keyboard)
    
    def show_category_products(self, message, category_id):
        """显示分类下的商品"""
        with self.app.app_context():
            try:
                category = Category.query.get(category_id)
                if not category:
                    self.bot.reply_to(message, "分类不存在")
                    return
                
                products = Product.query.filter_by(
                    category_id=category_id,
                    is_active=True
                ).order_by(Product.sort_index.asc()).all()
                
                if not products:
                    # 创建返回按钮
                    keyboard = InlineKeyboardMarkup()
                    parent = Category.query.filter(Category.children.any(id=category_id)).first()
                    back_id = parent.id if parent else None
                    keyboard.add(InlineKeyboardButton("⬅️ 返回上级", callback_data=f"cat_{back_id}" if back_id else "cat_root"))
                    
                    self.bot.reply_to(
                        message,
                        f"📁 {category.name}\n\n暂无商品",
                        reply_markup=keyboard
                    )
                    return
                
                from datetime import datetime
                # 获取有效的广告
                now = datetime.now()
                from models.advertisement import Advertisement
                ads = Advertisement.query.filter(
                    Advertisement.is_active == True,
                    Advertisement.expire_at > now
                ).all()
                
                # 创建商品列表键盘
                keyboard = InlineKeyboardMarkup()
                # 按库存量排序,库存为0的排在最后
                sorted_products = sorted(products, key=lambda p: (
                    0 if (99999 if p.is_same_key else p.total_keys - p.used_keys) == 0 else 1,
                    -(99999 if p.is_same_key else p.total_keys - p.used_keys)
                ))
                for product in sorted_products:
                    available = 99999 if product.is_same_key else product.total_keys - product.used_keys
                    # 计算最终价格(包含所有返佣)
                    final_price = self.calculate_final_price(product.price)
                    button_text = f"💎 {product.name} (${final_price:.2f}) [{available}]"
                    keyboard.add(InlineKeyboardButton(button_text, callback_data=f"prod_{product.id}"))
                
                # 添加分隔线和广告按钮
                if ads:
                    keyboard.add(InlineKeyboardButton("----广告区域----", callback_data="divider"))
                    for ad in ads:
                        keyboard.add(InlineKeyboardButton(
                            f"📢 {ad.description}",
                            url=f"https://t.me/{ad.username}"
                        ))
                
                # 添加返回按钮
                parent = Category.query.filter(Category.children.any(id=category_id)).first()
                back_id = parent.id if parent else None
                keyboard.add(InlineKeyboardButton("⬅️ 返回上级", callback_data=f"cat_{back_id}" if back_id else "cat_root"))
                
                # 发送商品列表
                msg = f"📁 {category.name} - 商品列表：\n\n"
                msg += "选择商品查看详情\n"
                msg += "💎 商品名称 (单价) [库存]"
                
                self.bot.reply_to(message, msg, reply_markup=keyboard)
                
            except Exception as e:
                logger.info(f"[Bot] 显示分类商品出错: {str(e)}")
                self.bot.reply_to(message, "抱歉，获取商品列表失败，请稍后重试")
    
    def handle_category_callback(self, call):
        """处理分类回调查询"""
        if call.data == "cat_root":
            # 显示顶级分类
            self.show_categories(call.message)
        else:
            # 显示子分类或商品
            category_id = int(call.data.split("_")[1]) if call.data.split("_")[1] != "None" else None
            self.show_categories(call.message, category_id) 