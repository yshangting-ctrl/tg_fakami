
import requests
from datetime import datetime, timezone, timedelta
import time
from logging import getLogger
logger = getLogger(__name__)

def get_transactions(address):
    try:
        url = f"https://apilist.tronscanapi.com/api/filter/trc20/transfers?limit=20&start=0&sort=-timestamp&count=true&filterTokenValue=0&relatedAddress={address}"
        response = requests.get(url)
        return response.json().get('token_transfers', [])
    except Exception as e:
        logger.info(f"获取交易记录失败: {str(e)}")
        return ''

def listen_for_transactions(address, amount):
    for i in range(3):
        seen_transactions = set()
        transactions = get_transactions(address)

        now = datetime.now()
        logger.info(f"开始检查交易记录: {now}")

        if transactions == '':
            time.sleep(10)
            return

        for transaction in transactions:
            if transaction['transaction_id'] not in seen_transactions:
                seen_transactions.add(transaction['transaction_id'])
                try:
                    quant = float(transaction.get("quant", 0))
                except ValueError:
                    quant = 0

                # 转换为北京时间 (UTC+8)
                beijing_tz = timezone(timedelta(hours=8))
                date_time = datetime.fromtimestamp(transaction['block_ts'] / 1000, tz=timezone.utc).astimezone(beijing_tz)
                current_time = datetime.now(beijing_tz)
                # 后期需要改成正式的30分钟
                thirty_minutes_ago = current_time - timedelta(minutes=30)

                if date_time >= thirty_minutes_ago and date_time <= current_time:
                    # 检查交易金额是否匹配订单金额
                    print(float(amount), quant / 1000000)
                    if float(amount) == quant / 1000000:
                        logger.info(f"发现匹配的充值交易: {transaction['transaction_id']}")
                        logger.info(f"订单金额: {amount}, 交易金额: {quant / 1000000}")
                        time.sleep(10)
                        return True

    return False