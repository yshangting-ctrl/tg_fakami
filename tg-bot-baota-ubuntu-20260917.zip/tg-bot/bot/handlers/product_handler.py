from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from models.product import Product
from models.order import Order
from .base_handler import BaseHandler
from models.user import User
from models.config import BotConfig
from datetime import datetime, timedelta
from .yizhifu import generate_payment
from app import db
import os
import tempfile
import zipfile
from models.key import Key
from models.balance_log import BalanceLog
from logging import getLogger

logger = getLogger(__name__)


def to_beijing(dt):
    """将datetime对象转换为北京时间"""
    if dt is None:
        return None
    return dt + timedelta(hours=8)


class ProductHandler(BaseHandler):
    def __init__(self, bot_instance):
        super().__init__(bot_instance)
        self._user_states = {}  # 用于存储用户状态
        self._last_check_time = {}  # 用于存储用户最后点击支付检查的时间

    def show_products(self, message, id=None):
        """显示商品列表"""
        with self.app.app_context():
            try:
                if id:
                    products = (
                        Product.query.filter_by(id=id, is_active=True)
                        .order_by(Product.sort_index.asc())
                        .all()
                    )
                else:
                    products = (
                        Product.query.filter_by(is_active=True)
                        .order_by(Product.sort_index.asc())
                        .all()
                    )

                # 尝试删除原消息
                try:
                    self.bot.delete_message(message.chat.id, message.message_id)
                except:
                    pass

                if not products:
                    self.bot.send_message(message.chat.id, "暂无商品")
                    return

                # 获取有效的广告
                now = datetime.now()
                from models.advertisement import Advertisement

                ads = Advertisement.query.filter(
                    Advertisement.is_active == True, Advertisement.expire_at > now
                ).all()

                # 创建商品列表键盘
                keyboard = InlineKeyboardMarkup()

                # 添加商品按钮
                # 按库存量排序,库存为0的排在最后
                sorted_products = sorted(
                    products,
                    key=lambda p: (
                        0
                        if (99999 if p.is_same_key else p.total_keys - p.used_keys) == 0
                        else 1,
                        -(99999 if p.is_same_key else p.total_keys - p.used_keys),
                    ),
                )
                for product in sorted_products:
                    available = (
                        99999
                        if product.is_same_key
                        else product.total_keys - product.used_keys
                    )
                    # 计算最终价格(包含所有返佣)
                    try:
                        final_price = self.calculate_final_price(product.price)
                        logger.info(f"[Bot] 商品 {product.name} 价格计算 - 原价: {product.price}, 最终价格: {final_price}")
                    except Exception as e:
                        logger.error(f"[Bot] 计算商品 {product.name} 价格出错: {str(e)}")
                        final_price = product.price
                    
                    button_text = (
                        f"💎 {product.name} (${final_price:.2f}) [{available}]"
                    )
                    keyboard.add(
                        InlineKeyboardButton(
                            button_text, callback_data=f"prod_{product.id}"
                        )
                    )

                # 添加分隔线和广告按钮
                if ads:
                    keyboard.add(
                        InlineKeyboardButton(
                            "----广告区域----", callback_data="divider"
                        )
                    )
                    for ad in ads:
                        keyboard.add(
                            InlineKeyboardButton(
                                f"📢 {ad.description}",
                                url=f"https://t.me/{ad.username}",
                            )
                        )

                # 发送商品列表
                msg = "🛍 商品列表：\n\n"
                msg += "选择商品查看详情\n"
                msg += "💎 商品名称 (单价) [库存]"

                self.bot.send_message(message.chat.id, msg, reply_markup=keyboard)

            except Exception as e:
                logger.info(f"[Bot] 显示商品列表出错: {str(e)}")
                self.bot.send_message(
                    message.chat.id, "抱歉，获取商品列表失败，请稍后重试"
                )

    def show_product_detail(self, message, product_id, call=None):
        """显示商品详情"""
        with self.app.app_context():
            try:
                product = Product.query.get(product_id)
                if not product:
                    self.bot.reply_to(message, "商品不存在或已下架")
                    return

                # 创建商品详情键盘
                keyboard = InlineKeyboardMarkup()
                available = (
                    99999
                    if product.is_same_key
                    else product.total_keys - product.used_keys
                )

                if available > 0:
                    # 添加数量选择按钮行
                    keyboard.row(
                        InlineKeyboardButton(
                            "➖", callback_data=f"qty_minus_{product_id}"
                        ),
                        InlineKeyboardButton(
                            "1", callback_data=f"qty_input_{product_id}"
                        ),  # 改为input回调
                        InlineKeyboardButton(
                            "➕", callback_data=f"qty_plus_{product_id}"
                        ),
                    )
                    # 添加购买按钮
                    keyboard.add(
                        InlineKeyboardButton(
                            "🛒 立即购买", callback_data=f"buy_{product_id}_1"
                        )
                    )

                # 添加返回按钮
                # keyboard.add(InlineKeyboardButton("⬅️ 返回列表", callback_data=f"cat_{product.category_id}"))

                # 构建商品详情消息
                msg = f"💎 {product.name}\n\n"
                final_price = self.calculate_final_price(product.price)
                msg += f"价格：${final_price:.2f}\n"
                msg += f"库存：{available}\n"
                if product.description and product.description.strip():
                    msg += f"\n{product.description}"

                try:
                    # 判断是普通消息还是inline_message_id推送
                    if hasattr(message, "chat") and hasattr(message, "message_id"):
                        # 普通消息
                        self.bot.reply_to(message, msg, reply_markup=keyboard)
                    elif (
                        call is not None
                        and hasattr(call, "inline_message_id")
                        and call.inline_message_id
                    ):
                        # inline_message_id推送
                        self.bot.edit_message_text(
                            msg,
                            inline_message_id=call.inline_message_id,
                            reply_markup=keyboard,
                        )
                    else:
                        # 兜底，尝试reply_to
                        self.bot.reply_to(message, msg, reply_markup=keyboard)
                except Exception as e:
                    print(call, e)

            except Exception as e:
                logger.info(f"[Bot] 显示商品详情出错: {str(e)}")
                self.bot.reply_to(message, "抱歉，获取商品详情失败，请稍后重试")

    def handle_product_callback(self, call):
        """处理商品回调查询"""
        try:
            self.bot.answer_callback_query(call.id)
            action = call.data.split("_")[0]
            if action == "prod":
                product_id = int(call.data.split("_")[1])
                self.show_product_detail(call.message, product_id, call)
            elif action == "qty":
                self.handle_quantity_callback(call)
        except Exception as e:
            logger.info(f"[Bot] 处理商品回调出错: {str(e)}")
            self.bot.reply_to(call.message, "抱歉，处理请求时出现错误，请稍后重试")

    def handle_quantity_callback(self, call):
        """处理数量调整回调"""
        try:
            _, action, product_id = call.data.split("_")
            product_id = int(product_id)

            # 如果是输入数量的回调
            if action == "input":
                user_id = str(call.from_user.id)
                self._user_states[user_id] = {
                    "state": "waiting_quantity",
                    "product_id": product_id,
                    "message_id": call.message.message_id,
                }
                self.bot.answer_callback_query(
                    call.id, "请直接发送要购买的数量", show_alert=True
                )
                return

            # 获取当前数量
            current_qty = 1
            for row in call.message.reply_markup.keyboard:
                for button in row:
                    if button.callback_data.startswith("qty_input"):
                        current_qty = int(button.text)
                        break

            # 获取商品库存
            with self.app.app_context():
                product = Product.query.get(product_id)
                if not product:
                    self.bot.answer_callback_query(call.id, "商品不存在")
                    return
                available = product.total_keys - product.used_keys

            # 调整数量
            if action == "minus":
                new_qty = max(1, current_qty - 1)
            elif action == "plus":
                new_qty = min(available, current_qty + 1)
            else:
                return

            # 更新键盘
            keyboard = call.message.reply_markup
            for row in keyboard.keyboard:
                for button in row:
                    if button.callback_data.startswith("qty_input"):
                        button.text = str(new_qty)
                    elif button.callback_data.startswith("buy_"):
                        button.callback_data = f"buy_{product_id}_{new_qty}"

            # 更新消息
            self.bot.edit_message_reply_markup(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                reply_markup=keyboard,
            )

            # 如果达到最小/最大值，显示提示
            if new_qty == 1 and action == "minus":
                self.bot.answer_callback_query(call.id, "已经是最小购买数量")
            elif new_qty == available and action == "plus":
                self.bot.answer_callback_query(call.id, "已经达到最大库存数量")
            else:
                self.bot.answer_callback_query(call.id)

        except Exception as e:
            logger.info(f"[Bot] 处理数量调整出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出现错误")

    def handle_quantity_input(self, message):
        """处理用户输入的数量"""
        user_id = str(message.from_user.id)
        if (
            user_id not in self._user_states
            or self._user_states[user_id]["state"] != "waiting_quantity"
        ):
            return

        try:
            quantity = int(message.text)
            product_id = self._user_states[user_id]["product_id"]
            message_id = self._user_states[user_id]["message_id"]

            with self.app.app_context():
                product = Product.query.get(product_id)
                if not product:
                    self.bot.reply_to(message, "商品不存在")
                    return

                available = product.total_keys - product.used_keys

                if quantity < 1:
                    self.bot.reply_to(message, "购买数量不能小于1")
                    return

                if quantity > available:
                    self.bot.reply_to(
                        message, f"库存不足，当前最大可购买数量为 {available}"
                    )
                    return

                # 更新键盘
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("➖", callback_data=f"qty_minus_{product_id}"),
                    InlineKeyboardButton(
                        str(quantity), callback_data=f"qty_input_{product_id}"
                    ),
                    InlineKeyboardButton("➕", callback_data=f"qty_plus_{product_id}"),
                )
                keyboard.add(
                    InlineKeyboardButton(
                        "🛒 立即购买", callback_data=f"buy_{product_id}_{quantity}"
                    )
                )
                # keyboard.add(InlineKeyboardButton("⬅️ 返回列表", callback_data=f"cat_{product.category_id}"))

                # 更新原消息的键盘
                self.bot.edit_message_reply_markup(
                    chat_id=message.chat.id,
                    message_id=message_id,
                    reply_markup=keyboard,
                )

                # 删除用户输入的消息
                self.bot.delete_message(message.chat.id, message.message_id)

        except ValueError:
            self.bot.reply_to(message, "请输入有效的数字")
        except Exception as e:
            logger.info(f"[Bot] 处理数量输入出错: {str(e)}")
            self.bot.reply_to(message, "处理输入时出现错误，请重试")
        finally:
            # 清理用户状态
            if user_id in self._user_states:
                del self._user_states[user_id]

    def handle_buy_callback(self, call):
        """处理购买回调查询"""
        try:
            self.bot.answer_callback_query(call.id, "正在生成购买信息")
            _, product_id, quantity = call.data.split("_")
            print(call.data, "fwefwfwe")
            self.handle_buy_command(call.message, int(product_id), int(quantity))
        except Exception as e:
            logger.info(f"[Bot] 处理购买回调出错: {str(e)}")
            self.bot.reply_to(call.message, "抱歉，处理购买请求时出现错误，请稍后重试")

    def handle_buy_command(self, message, product_id, quantity=1):
        """处理购买命令"""
        with self.app.app_context():
            try:
                product = Product.query.get(product_id)
                print(product)
                if not product:
                    self.bot.reply_to(message, "商品不存在或已下架")
                    return

                available = (
                    99999
                    if product.is_same_key
                    else product.total_keys - product.used_keys
                )
                if available <= 0:
                    self.bot.reply_to(message, "抱歉，该商品已售罄")
                    return

                if quantity > available:
                    self.bot.reply_to(
                        message, f"抱歉，商品库存不足，当前最大可购买数量为 {available}"
                    )
                    return

                # 计算总价
                final_price = self.calculate_final_price(product.price)
                total_amount = final_price * quantity

                # 创建购买确认键盘
                keyboard = InlineKeyboardMarkup()
                # 添加支付方式按钮
                keyboard.row(
                    InlineKeyboardButton(
                        f"💰 余额支付 ${total_amount:.2f}",
                        callback_data=f"pay_balance_{product_id}_{quantity}",
                    )
                )
                keyboard.row(
                    InlineKeyboardButton(
                        f"💎 USDT支付 ${total_amount:.2f}",
                        callback_data=f"pay_usdt_{product_id}_{quantity}",
                    )
                )

                _config = ""

                if self.config.parent_bot_username:
                    _config = BotConfig.query.filter_by(
                        bot_username=self.config.parent_bot_username
                    ).first()
                else:
                    _config = self.config

                try:
                    if _config.epay_key:
                        keyboard.row(
                            InlineKeyboardButton(
                                f"💳 微信支付 ${total_amount:.2f}",
                                callback_data=f"pay_weixin_{product_id}_{quantity}",
                            )
                        )

                        keyboard.row(
                            InlineKeyboardButton(
                                f"💳 支付宝支付 ${total_amount:.2f}",
                                callback_data=f"pay_zfb_{product_id}_{quantity}",
                            )
                        )

                except Exception as e:
                    pass

                if _config.fll_key:
                    keyboard.row(
                        InlineKeyboardButton(
                            f"💰 福利来支付 ${total_amount:.2f}",
                            callback_data=f"pay_fll_{product_id}_{quantity}",
                        )
                    )
                if _config.okpay_key:
                    keyboard.row(
                        InlineKeyboardButton(
                            f"💰 okpay支付 ${total_amount:.2f}",
                            callback_data=f"pay_okpay_{product_id}_{quantity}",
                        )
                    )

                # 添加取消按钮
                keyboard.row(
                    InlineKeyboardButton(
                        "❌ 取消", callback_data=f"cancel_buy_{product_id}"
                    )
                )

                # 发送购买确认消息
                msg = f"💎 确认购买 {product.name}\n\n"
                msg += f"数量：{quantity}\n"
                msg += f"单价：${final_price:.2f}\n"
                msg += f"总价：${total_amount:.2f}\n"
                msg += f"库存：{available}\n\n"
                msg += "请选择支付方式："

                # 如果是回复消息,编辑原消息
                if hasattr(message, "message_id"):
                    self.bot.edit_message_text(
                        msg,
                        chat_id=message.chat.id,
                        message_id=message.message_id,
                        reply_markup=keyboard,
                    )
                else:
                    # 如果是新消息,先删除原消息再发送新消息
                    try:
                        self.bot.delete_message(message.chat.id, message.message_id)
                    except:
                        pass
                    self.bot.send_message(message.chat.id, msg, reply_markup=keyboard)

            except Exception as e:
                logger.info(f"[Bot] 处理购买命令出错: {str(e)}")
                self.bot.reply_to(message, "抱歉，处理购买请求时出现错误，请稍后重试")

    def process_paid_order(self, chat_id, order, message_id=None):
        """处理已支付订单
        Args:
            chat_id: 用户的聊天ID
            order: 订单对象
            message_id: 可选，需要更新的消息ID
        Returns:
            bool: 是否处理成功
        """
        try:
            # 更新订单状态
            order.status = "paid"
            order.payment_time = datetime.utcnow()
            db.session.commit()

            # 发送支付成功消息
            msg = f"✅ 支付成功！\n\n"
            msg += f"订单号：{order.id}\n"
            msg += f"商品：{order.product.name}\n"
            msg += f"数量：{order.quantity}\n"
            msg += f"总价：${order.total_amount:.2f}\n"
            msg += f"支付方式：{order.payment_type}\n\n"
            msg += "正在处理您的订单，请稍候..."

            if message_id:
                self.bot.edit_message_text(msg, chat_id, message_id)
            else:
                self.bot.send_message(chat_id, msg)

            # 发送商品
            return self.send_products_to_user(chat_id, order)

        except Exception as e:
            logger.info(f"[Bot] 处理已支付订单出错: {str(e)}")
            error_msg = "❌ 订单处理失败\n\n"
            error_msg += "处理订单时出现错误。\n"
            error_msg += "请联系客服处理。"
            self.bot.send_message(chat_id, error_msg)
            return False

    def generate_unique_payment_amount(self, base_amount):
        """生成唯一的支付金额
        Args:
            base_amount: 基础金额
        Returns:
            float: 唯一的支付金额
        """
        try:
            # 获取30分钟内的所有USDT订单的金额(包括所有状态)
            thirty_mins_ago = datetime.utcnow() - timedelta(minutes=30)
            existing_amounts = set(
                order.total_amount
                for order in Order.query.filter(
                    Order.payment_type == "USDT", Order.created_at >= thirty_mins_ago
                ).all()
            )

            # 从基础金额开始，每次加0.01，直到找到一个未使用的金额
            amount = float(base_amount)
            while amount in existing_amounts:
                amount = round(amount + 0.01, 2)

            logger.info(
                f"[Bot] 生成唯一支付金额 - 基础金额: {base_amount}, 最终金额: {amount}, 现有金额: {existing_amounts}"
            )
            return amount

        except Exception as e:
            logger.info(f"[Bot] 生成唯一支付金额出错: {str(e)}")
            # 如果出错，返回原始金额
            return base_amount

    def handle_payment_callback(self, call):
        """处理支付回调"""
        try:
            # 解析回调数据
            parts = call.data.split("_")
            payment_type = parts[1]  # balance 或 usdt 或 weixin 或 zfb
            product_id = int(parts[2])
            quantity = int(parts[3])

            with self.app.app_context():
                product = Product.query.get(product_id)
                if not product:
                    self.bot.answer_callback_query(call.id, "商品不存在")
                    return

                available = (
                    99999
                    if product.is_same_key
                    else product.total_keys - product.used_keys
                )
                if available < quantity:
                    self.bot.answer_callback_query(call.id, "商品库存不足")
                    return

                # 计算基础金额
                base_amount = product.price * quantity
                # 计算最终价格(包含所有返佣)
                final_amount = self.calculate_final_price(base_amount)

                try:
                    # 如果是USDT支付，生成唯一金额
                    if payment_type == "usdt":
                        total_amount = self.generate_unique_payment_amount(final_amount)
                    elif payment_type == "balance":
                        total_amount = final_amount
                    elif payment_type == "weixin":
                        total_amount = final_amount
                    elif payment_type == "zfb":
                        total_amount = final_amount
                    elif payment_type == "okpay":
                        total_amount = final_amount
                    elif payment_type == "fll":
                        total_amount = final_amount

                    total_amount = round(float(total_amount), 2)

                    # 生成16位随机订单号
                    import random
                    import string

                    order_id = "".join(
                        random.choices(string.ascii_uppercase + string.digits, k=16)
                    )
                    logger.info(f"[Bot] 创建新订单: {order_id}")
                    order = Order(
                        id=order_id,
                        user_id=str(call.from_user.id),
                        product_id=product_id,
                        bot_username=self.config.bot_username,
                        unit_price=product.price,
                        quantity=quantity,
                        total_amount=total_amount,  # 使用包含返佣的最终金额
                        payment_type=payment_type.upper(),
                        status="pending",
                    )
                    db.session.add(order)
                    db.session.flush()
                    logger.info(f"[Bot] 新订单创建成功: {order.id}")

                    if payment_type == "balance":
                        # 检查用户余额
                        user = User.query.filter_by(
                            telegram_id=str(call.from_user.id),
                            bot_username=self.config.bot_username,
                        ).first()

                        user.balance = round(float(user.balance), 2)

                        if not user:
                            self.bot.answer_callback_query(
                                call.id, "用户信息不存在,请先发送 /start 进行初始化"
                            )
                            return
                        if user.balance < total_amount:
                            self.bot.answer_callback_query(
                                call.id, "余额不足，请先充值"
                            )
                            return

                        # 扣除余额
                        user.balance -= total_amount

                        # 添加余额变动记录
                        balance_log = BalanceLog(
                            username=user.username,
                            telegram_id=user.telegram_id,
                            bot_username=self.config.bot_username,
                            type="decrease",
                            amount=total_amount,
                            balance=user.balance,
                            description=f"购买商品: {product.name} x {quantity}",
                        )
                        db.session.add(balance_log)
                        db.session.commit()

                        logger.info(f"[Bot] 余额支付成功: {order.id}")

                        # 处理订单
                        self.process_paid_order(
                            call.message.chat.id, order, call.message.message_id
                        )

                    elif payment_type == "usdt":  # USDT支付
                        # 设置支付地址和过期时间
                        order.payment_address = (
                            self.config.recharge_address
                        )  # 使用配置中的地址
                        order.created_at = datetime.utcnow()
                        # 30分钟后过期
                        logger.info(datetime.utcnow())
                        logger.info(order.created_at)
                        logger.info(order.created_at.strftime("%Y-%m-%d %H:%M:%S"))
                        expire_time = order.created_at + timedelta(minutes=30)

                        db.session.commit()
                        logger.info(f"[Bot] USDT支付订单已创建: {order.id}")

                        # 创建支付信息键盘
                        keyboard = InlineKeyboardMarkup()
                        keyboard.row(
                            InlineKeyboardButton(
                                "✅ 支付完成", callback_data=f"check_pay_{order.id}"
                            )
                        )
                        keyboard.row(
                            InlineKeyboardButton(
                                "⬅️ 返回选择", callback_data=f"back_to_pay_{order.id}"
                            ),
                            InlineKeyboardButton(
                                "❌ 取消订单", callback_data=f"cancel_pay_{order.id}"
                            ),
                        )

                        # 发送支付信息
                        msg = "💎 USDT支付订单\n\n"
                        msg += f"📝 订单号：{order.id}\n"
                        msg += "------------\n"
                        msg += "💳 收款地址：\n"
                        msg += f"`{order.payment_address}`\n"  # 使用Markdown格式使地址可点击复制
                        msg += "👆 点击上方地址即可复制\n\n"
                        msg += f"💵 实付金额：{total_amount:.2f} USDT\n"  # 显示包含返佣的最终金额
                        msg += f"📦 数量：{quantity}\n"
                        msg += "------------\n"
                        # 使用北京时间
                        msg += f"⏰ 创建时间：{to_beijing(order.created_at).strftime('%Y-%m-%d %H:%M:%S')}\n"
                        msg += f"⌛️ 结束时间：{to_beijing(expire_time).strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                        msg += "⚠️ 注意事项：\n"
                        msg += "1️⃣ 请在规定时间内完成付款\n"
                        msg += "2️⃣ 必须使用 TRC20 网络转账\n"
                        msg += "3️⃣ 转账金额必须完全一致\n"
                        msg += "4️⃣ 点击地址自动复制"

                        # 发送或编辑消息
                        if call.message.message_id:
                            sent_message = self.bot.edit_message_text(
                                msg,
                                call.message.chat.id,
                                call.message.message_id,
                                reply_markup=keyboard,
                                parse_mode="Markdown",
                            )
                        else:
                            sent_message = self.bot.send_message(
                                call.message.chat.id,
                                msg,
                                reply_markup=keyboard,
                                parse_mode="Markdown",
                            )

                        # 设置30分钟后删除消息
                        def delete_message_later(chat_id, message_id):
                            import time

                            time.sleep(1800)  # 等待30分钟
                            try:
                                self.bot.delete_message(
                                    chat_id=chat_id, message_id=message_id
                                )
                                logger.info(f"已删除过期支付消息: {epay_order_id}")
                            except Exception as e:
                                logger.info(f"删除过期支付消息失败: {str(e)}")

                        import threading

                        # 启动删除消息的线程
                        delete_thread = threading.Thread(
                            target=delete_message_later,
                            args=(sent_message.chat.id, sent_message.message_id),
                        )
                        delete_thread.daemon = True
                        delete_thread.start()
                    elif payment_type == "weixin" or payment_type == "zfb":
                        _config = ""

                        if self.config.parent_bot_username:
                            _config = BotConfig.query.filter_by(
                                bot_username=self.config.parent_bot_username
                            ).first()
                        else:
                            _config = self.config

                        config_pay = {
                            "usdt_rate": _config.usdt_rate,
                            "epay_pid": _config.epay_pid,
                            "epay_key": _config.epay_key,
                            "backend_url": _config.backend_url,
                            "return_url": (
                                f"https://t.me/{_config.bot_username.lstrip('@')}"
                            ),
                        }

                        pay = float(config_pay["usdt_rate"]) * total_amount

                        if pay > 2000:
                            self.bot.answer_callback_query(
                                call.id, "单笔支付金额超过2000元，请分多次支付"
                            )
                            return

                        # 设置支付地址和过期时间
                        order.created_at = datetime.utcnow()
                        # 10分钟后过期
                        expire_time = order.created_at + timedelta(minutes=5)

                        db.session.commit()
                        logger.info(f"[Bot] weixin支付订单已创建: {order.id}")

                        # 创建支付信息键盘
                        keyboard = InlineKeyboardMarkup()
                        keyboard.row(
                            InlineKeyboardButton(
                                "✅ 支付完成", callback_data=f"check_pay_{order.id}"
                            )
                        )
                        keyboard.row(
                            InlineKeyboardButton(
                                "⬅️ 返回选择", callback_data=f"back_to_pay_{order.id}"
                            ),
                            InlineKeyboardButton(
                                "❌ 取消订单", callback_data=f"cancel_pay_{order.id}"
                            ),
                        )

                        # 发送微信支付信息
                        msg = (
                            "💳 "
                            + ("微信支付" if payment_type == "weixin" else "支付宝支付")
                            + "订单\n\n"
                        )
                        def format_amount(amount):
                            return round(amount, 2)

                        msg += f"订单号：{order.id}\n"
                        msg += f"商品名称：{order.product.name}\n"
                        msg += f"购买数量：{order.quantity}\n"
                        msg += f"支付金额：${format_amount(pay):.2f}\n"
                        # 直接使用北京时间显示
                        msg += f"创建时间：{to_beijing(order.created_at).strftime('%Y-%m-%d %H:%M:%S')}\n"
                        msg += f"结束时间：{to_beijing(expire_time).strftime('%Y-%m-%d %H:%M:%S')}\n\n"

                        payment_result = generate_payment(config_pay, format_amount(pay), payment_type)
                        logger.info(payment_result)

                        if (
                            isinstance(payment_result, tuple)
                            and len(payment_result) == 2
                        ):
                            qr_path, payment_url = payment_result
                            if payment_url:
                                # 从payment_url中提取订单号
                                import urllib.parse
                                import copy

                                parsed_url = copy.deepcopy(
                                    urllib.parse.urlparse(payment_url)
                                )
                                query_params = copy.deepcopy(
                                    urllib.parse.parse_qs(parsed_url.query)
                                )
                                epay_order_id = copy.deepcopy(
                                    query_params.get("out_trade_no", [""])[0]
                                )

                                # 更新订单支付编号
                                with self.app.app_context():
                                    # 重新查询订单信息
                                    order = (
                                        db.session.query(Order)
                                        .filter_by(id=order.id)
                                        .first()
                                    )
                                    if order:
                                        order.payment_no = epay_order_id
                                        db.session.commit()
                                        logger.info(
                                            f"订单支付编号已更新: {order.id}, payment_no={epay_order_id}"
                                        )
                                    else:
                                        logger.error(f"订单不存在: {order.id}")

                                # 修改键盘,添加支付链接按钮
                                keyboard = InlineKeyboardMarkup()
                                keyboard.row(
                                    InlineKeyboardButton("🔗 立即支付", url=payment_url)
                                )

                                keyboard.row(
                                    InlineKeyboardButton(
                                        "✅ 支付完成",
                                        callback_data=f"check_pay_{order.id}",
                                    )
                                )

                                # 修改响应消息
                                msg = f"{msg}\n💓支付订单号: {epay_order_id}\n"
                                msg += "⚠️ 请在5分钟内完成支付，超时订单将自动取消\n"
                                msg += "⚠️ 支付成功后系统将自动为您发货\n"
                                msg += "⚠️ 请勿重复支付或支付错误金额"
                                sent_message = self.bot.send_message(
                                    chat_id=call.message.chat.id,
                                    text=msg,
                                    reply_markup=keyboard,
                                    parse_mode="Markdown",
                                )

                                # 启动一个线程5分钟后删除消息
                                def delete_message_later(chat_id, message_id):
                                    import time

                                    time.sleep(300)  # 等待5分钟
                                    try:
                                        self.bot.delete_message(
                                            chat_id=chat_id, message_id=message_id
                                        )
                                        logger.info(
                                            f"已删除过期支付消息: {epay_order_id}"
                                        )
                                    except Exception as e:
                                        logger.info(f"删除过期支付消息失败: {str(e)}")

                                import threading

                                delete_thread = threading.Thread(
                                    target=delete_message_later,
                                    args=(
                                        sent_message.chat.id,
                                        sent_message.message_id,
                                    ),
                                )
                                delete_thread.daemon = True
                                delete_thread.start()
                            else:
                                # 如果没有二维码，直接发送文本消息
                                self.bot.send_message(
                                    chat_id=call.message.chat.id,
                                    text=msg,
                                    parse_mode="Markdown",
                                )
                        else:
                            logger.info("支付订单创建失败：返回格式不正确")
                            self.bot.send_message(
                                chat_id=call.message.chat.id,
                                text="❌ 支付订单创建失败，请稍后重试",
                                parse_mode="Markdown",
                            )
                        return
                    elif payment_type == "okpay":
                        # 获取okpay配置
                        _config = ""
                        if self.config.parent_bot_username:
                            _config = BotConfig.query.filter_by(
                                bot_username=self.config.parent_bot_username
                            ).first()
                        else:
                            _config = self.config

                        if not _config.okpay_id or not _config.okpay_key:
                            self.bot.answer_callback_query(
                                call.id, "OkayPay配置不完整，请联系管理员"
                            )
                            return

                        # 设置订单过期时间
                        order.created_at = datetime.utcnow() + timedelta(hours=8)
                        expire_time = order.created_at + timedelta(minutes=30)

                        db.session.commit()
                        logger.info(f"[Bot] OkayPay支付订单已创建: {order.id}")

                        # 导入okpay支付服务
                        from .okpay import create_payment_direct

                        # 创建okpay支付
                        payment_result = create_payment_direct(
                            user_id=str(call.from_user.id),
                            amount=total_amount,
                            coin="USDT",
                            merchant_id=_config.okpay_id,
                            token=_config.okpay_key,
                            description=f"购买商品: {product.name} x {quantity}",
                        )

                        if payment_result["success"] and payment_result.get(
                            "payment_url"
                        ):
                            # 更新订单支付编号
                            order.payment_no = payment_result.get("api_order_id", "")
                            db.session.commit()

                            # 创建支付信息键盘
                            keyboard = InlineKeyboardMarkup()
                            keyboard.row(
                                InlineKeyboardButton(
                                    "🔗 立即支付", url=payment_result["payment_url"]
                                )
                            )
                            keyboard.row(
                                InlineKeyboardButton(
                                    "✅ 支付完成", callback_data=f"check_pay_{order.id}"
                                )
                            )
                            keyboard.row(
                                InlineKeyboardButton(
                                    "❌ 取消订单",
                                    callback_data=f"cancel_pay_{order.id}",
                                )
                            )

                            # 发送支付信息
                            msg = "🟢 OkayPay支付订单\n\n"
                            msg += f"📝 订单号：{order.id}\n"
                            msg += f"📦 商品名称：{product.name}\n"
                            msg += f"🔢 购买数量：{quantity}\n"
                            msg += f"💵 支付金额：{total_amount:.2f} USDT\n"
                            msg += f"⏰ 创建时间：{order.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n"
                            msg += f"⌛️ 结束时间：{expire_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                            msg += "⚠️ 注意事项：\n"
                            msg += "1️⃣ 请在规定时间内完成付款\n"
                            msg += "2️⃣ 点击【立即支付】按钮跳转到支付页面\n"
                            msg += "3️⃣ 支付完成后请点击【支付完成】按钮\n"
                            msg += "4️⃣ 请勿重复支付或支付错误金额"

                            sent_message = self.bot.send_message(
                                chat_id=call.message.chat.id,
                                text=msg,
                                reply_markup=keyboard,
                                parse_mode="Markdown",
                            )

                            # 启动一个线程30分钟后删除消息
                            def delete_message_later(chat_id, message_id):
                                import time

                                time.sleep(1800)  # 等待30分钟
                                try:
                                    self.bot.delete_message(
                                        chat_id=chat_id, message_id=message_id
                                    )
                                    logger.info(
                                        f"已删除过期OkayPay支付消息: {order.id}"
                                    )
                                except Exception as e:
                                    logger.info(
                                        f"删除过期OkayPay支付消息失败: {str(e)}"
                                    )

                            import threading

                            delete_thread = threading.Thread(
                                target=delete_message_later,
                                args=(sent_message.chat.id, sent_message.message_id),
                            )
                            delete_thread.daemon = True
                            delete_thread.start()

                        else:
                            logger.error(
                                f"[Bot] OkayPay支付创建失败: {payment_result.get('message', '未知错误')}"
                            )
                            self.bot.answer_callback_query(
                                call.id, "创建支付失败，请稍后重试"
                            )
                        return

                    elif payment_type == "fll":
                        # 获取福利来配置
                        _config = ""
                        if self.config.parent_bot_username:
                            _config = BotConfig.query.filter_by(
                                bot_username=self.config.parent_bot_username
                            ).first()
                        else:
                            _config = self.config

                        if not _config.fll_id or not _config.fll_key:
                            self.bot.answer_callback_query(
                                call.id, "福利来配置不完整，请联系管理员"
                            )
                            return

                        # 设置订单过期时间
                        order.created_at = datetime.utcnow() + timedelta(hours=8)
                        expire_time = order.created_at + timedelta(minutes=30)

                        db.session.commit()
                        logger.info(f"[Bot] 福利来支付订单已创建: {order.id}")

                        # 导入福利来支付服务
                        from .fll import create_payment_direct

                        # 创建福利来支付
                        payment_result = create_payment_direct(
                            user_id=str(call.from_user.id),
                            amount=total_amount,
                            coin="USDT",
                            order_id=order.id,
                            app_id=_config.fll_id,
                            key=_config.fll_key,
                            description=f"购买商品: {product.name} x {quantity}",
                        )

                        if payment_result["success"] and payment_result.get(
                            "payment_url"
                        ):
                            # 更新订单支付编号
                            order.payment_no = payment_result.get("order_id", "")
                            db.session.commit()

                            # 创建支付信息键盘
                            keyboard = InlineKeyboardMarkup()
                            keyboard.row(
                                InlineKeyboardButton(
                                    "🔗 立即支付", url=payment_result["payment_url"]
                                )
                            )

                            keyboard.row(
                                InlineKeyboardButton(
                                    "✅ 支付完成", callback_data=f"check_pay_{order.id}"
                                )
                            )

                            keyboard.row(
                                InlineKeyboardButton(
                                    "❌ 取消订单",
                                    callback_data=f"cancel_pay_{order.id}",
                                )
                            )

                            # 发送支付信息
                            msg = "💳 福利来支付订单\n\n"
                            msg += f"📝 订单号：{order.id}\n"
                            msg += f"📦 商品名称：{product.name}\n"
                            msg += f"🔢 购买数量：{quantity}\n"
                            msg += f"💵 支付金额：{total_amount:.2f} USDT\n"
                            msg += f"⏰ 创建时间：{order.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n"
                            msg += f"⌛️ 结束时间：{expire_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                            msg += "⚠️ 注意事项：\n"
                            msg += "1️⃣ 请在规定时间内完成付款\n"
                            msg += "2️⃣ 点击【立即支付】按钮跳转到支付页面\n"
                            msg += "3️⃣ 支付完成后请点击【支付完成】按钮\n"
                            msg += "4️⃣ 请勿重复支付或支付错误金额"

                            sent_message = self.bot.send_message(
                                chat_id=call.message.chat.id,
                                text=msg,
                                reply_markup=keyboard,
                                parse_mode="Markdown",
                            )

                            # 启动一个线程30分钟后删除消息
                            def delete_message_later(chat_id, message_id):
                                import time

                                time.sleep(1800)  # 等待30分钟
                                try:
                                    self.bot.delete_message(
                                        chat_id=chat_id, message_id=message_id
                                    )
                                    logger.info(f"已删除过期福利来支付消息: {order.id}")
                                except Exception as e:
                                    logger.info(f"删除过期福利来支付消息失败: {str(e)}")

                            import threading

                            delete_thread = threading.Thread(
                                target=delete_message_later,
                                args=(sent_message.chat.id, sent_message.message_id),
                            )
                            delete_thread.daemon = True
                            delete_thread.start()

                        else:
                            logger.error(
                                f"[Bot] 福利来支付创建失败: {payment_result.get('message', '未知错误')}"
                            )
                            self.bot.answer_callback_query(
                                call.id, "创建支付失败，请稍后重试"
                            )
                        return
                except Exception as e:
                    logger.info(f"[Bot] 创建支付订单时出错: {str(e)}")
                    db.session.rollback()
                    self.bot.answer_callback_query(
                        call.id, "创建订单时出现错误，请重试"
                    )

        except Exception as e:
            logger.info(f"[Bot] 处理支付回调时出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出现错误")

    def handle_back_to_pay(self, call):
        """处理返回支付选择回调"""
        try:
            # 获取完整的订单号
            order_id = call.data.split("back_to_pay_")[1]
            logger.info(f"[Bot] 尝试返回支付选择: {order_id}")

            with self.app.app_context():
                order = Order.query.get(order_id)
                if not order:
                    logger.info(f"[Bot] 订单不存在: {order_id}")
                    self.bot.answer_callback_query(call.id, "订单不存在")
                    return

                if order.user_id != str(call.from_user.id):
                    self.bot.answer_callback_query(call.id, "这不是您的订单")
                    return

                if order.status != "pending":
                    self.bot.answer_callback_query(
                        call.id, "订单状态已改变，无法修改支付方式"
                    )
                    return

                # 创建支付选择键盘
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton(
                        f"💰 余额支付 ${order.total_amount:.2f}",
                        callback_data=f"pay_balance_{order.product_id}_{order.quantity}",
                    )
                )
                keyboard.row(
                    InlineKeyboardButton(
                        f"💎 USDT支付 ${order.total_amount:.2f}",
                        callback_data=f"pay_usdt_{order.product_id}_{order.quantity}",
                    )
                )
                _config = ""

                if self.config.parent_bot_username:
                    _config = BotConfig.query.filter_by(
                        bot_username=self.config.parent_bot_username
                    ).first()
                else:
                    _config = self.config

                try:
                    if _config.epay_key:
                        keyboard.row(
                            InlineKeyboardButton(
                                f"💳 微信支付 ${order.total_amount:.2f}",
                                callback_data=f"pay_weixin_{order.product_id}_{order.quantity}",
                            )
                        )

                        keyboard.row(
                            InlineKeyboardButton(
                                f"💳 支付宝支付 ${order.total_amount:.2f}",
                                callback_data=f"pay_zfb_{order.product_id}_{order.quantity}",
                            )
                        )
                except Exception as e:
                    pass

                keyboard.row(
                    InlineKeyboardButton(
                        "❌ 取消", callback_data=f"cancel_pay_{order.id}"
                    )
                )

                # 发送支付选择消息
                msg = f"💎 确认购买 {order.product.name}\n\n"
                msg += f"订单号：{order.id}\n"
                msg += f"数量：{order.quantity}\n"
                msg += f"单价：${order.unit_price:.2f}\n"
                msg += f"总价：${order.total_amount:.2f}\n"
                msg += f"库存：{order.product.total_keys - order.product.used_keys}\n\n"
                msg += "请选择支付方式："

                self.bot.edit_message_text(
                    text=msg,
                    chat_id=call.message.chat.id,
                    message_id=call.message.message_id,
                    reply_markup=keyboard,
                )
                logger.info(f"[Bot] 已返回支付选择: {order_id}")

        except Exception as e:
            logger.info(f"[Bot] 处理返回支付选择出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出现错误")

    def handle_check_payment(self, call):
        """处理支付完成回调"""
        try:
            import time

            user_id = str(call.from_user.id)
            current_time = time.time()

            # 检查用户是否在10秒内重复点击
            if user_id in self._last_check_time:
                time_diff = current_time - self._last_check_time[user_id]
                if time_diff < 30:  # 30秒内不允许重复点击
                    remaining_time = round(30 - time_diff)
                    self.bot.answer_callback_query(
                        call.id,
                        f"请等待 {remaining_time} 秒后再次检查支付状态",
                        show_alert=True,
                    )
                    return

            # 更新最后点击时间
            self._last_check_time[user_id] = current_time

            order_id = call.data.split("_")[2]
            with self.app.app_context():
                order = Order.query.get(order_id)
                if not order:
                    self.bot.answer_callback_query(call.id, "订单不存在")
                    return

                if order.user_id != str(call.from_user.id):
                    self.bot.answer_callback_query(call.id, "这不是您的订单")
                    return

                print(order)

                if order.status != "pending" and order.status != "paid":
                    self.bot.answer_callback_query(call.id, "订单状态异常，请联系客服")
                    return

                # 检查订单是否过期
                if datetime.utcnow() - order.created_at > timedelta(minutes=30):
                    order.status = "cancelled"
                    db.session.commit()
                    self.bot.answer_callback_query(call.id, "订单已过期")
                    return

                payment_received = False

                if order.status != "paid":
                    # 检查USDT支付是否到账
                    from .address_pay import listen_for_transactions

                    payment_received = listen_for_transactions(
                        address=order.payment_address, amount=order.total_amount
                    )
                else:
                    payment_received = True

                if payment_received:
                    # 更新订单状态
                    order.status = "completed"
                    order.payment_time = datetime.utcnow()
                    db.session.commit()

                    # 发送成功消息
                    msg = f"✅ 支付成功！\n\n"
                    msg += f"订单号：{order.id}\n"
                    msg += f"商品：{order.product.name}\n"
                    msg += f"数量：{order.quantity}\n"
                    msg += f"总价：${order.total_amount}\n"
                    msg += f"支付方式：{order.payment_type}\n\n"
                    msg += "正在处理您的订单，请稍候..."

                    if call.message.message_id:
                        self.bot.edit_message_text(
                            msg, call.message.chat.id, call.message.message_id
                        )
                    else:
                        self.bot.send_message(call.message.chat.id, msg)

                    # 发送商品
                    return self.send_products_to_user(call.message.chat.id, order)

                else:
                    self.bot.answer_callback_query(
                        call.id, "未检测到支付到账，请确认支付后再试", show_alert=True
                    )

        except Exception as e:
            logger.info(f"[Bot] 检查支付状态出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "检查支付状态时出现错误")

    def handle_cancel_payment(self, call):
        """处理取消支付回调"""
        try:
            order_id = call.data.split("_")[2]
            logger.info(f"[Bot] 尝试取消订单: {order_id}")

            with self.app.app_context():
                order = Order.query.get(order_id)
                if not order:
                    logger.info(f"[Bot] 订单不存在: {order_id}")
                    self.bot.answer_callback_query(call.id, "订单不存在")
                    return

                logger.info(f"[Bot] 订单信息: {order.to_dict()}")

                if order.user_id != str(call.from_user.id):
                    self.bot.answer_callback_query(call.id, "这不是您的订单")
                    return

                if order.status != "pending":
                    self.bot.answer_callback_query(call.id, "订单状态已改变，无法取消")
                    return

                # 取消订单
                order.status = "cancelled"
                db.session.commit()
                logger.info(f"[Bot] 订单已取消: {order_id}")

                # 删除订单消息
                self.bot.delete_message(call.message.chat.id, call.message.message_id)

                self.bot.answer_callback_query(call.id, "订单已取消")

        except Exception as e:
            logger.info(f"[Bot] 取消支付出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "取消支付时出现错误")

    def add_to_zip(self, zipf, source_path, target_path):
        """递归添加文件到zip
        Args:
            zipf: ZipFile对象
            source_path: 源文件路径
            target_path: zip中的目标路径
        """
        if os.path.isfile(source_path):
            # 如果是文件，直接添加到指定路径
            zipf.write(source_path, target_path)
        else:
            # 如果是目录，先创建目录本身（通过添加一个空文件来实现）
            try:
                info = zipfile.ZipInfo(target_path + "/")
                info.external_attr = 0o40775 << 16  # 设置目录权限
                zipf.writestr(info, "")
            except Exception as e:
                logger.info(f"[Bot] 创建目录失败: {str(e)}")

            # 递归添加目录内容
            for root, dirs, files in os.walk(source_path):
                # 获取相对路径
                relative_path = os.path.relpath(root, source_path)

                # 添加文件
                for file in files:
                    source_file = os.path.join(root, file)
                    # 如果是在根目录，直接放在目标目录下
                    if relative_path == ".":
                        target_file = os.path.join(target_path, file)
                    else:
                        # 否则保持相对路径结构
                        target_file = os.path.join(target_path, relative_path, file)
                    # 统一路径分隔符
                    target_file = target_file.replace("\\", "/")
                    zipf.write(source_file, target_file)

    def send_products_to_user(self, chat_id, order):
        """发送商品给用户
        Args:
            chat_id: 用户的聊天ID
            order: 订单对象
        Returns:
            bool: 是否发送成功
        """
        try:
            # 获取未使用的密钥
            if order.product.is_same_key:
                # 如果是单渠道商品,只获取第一个密钥
                unused_keys = (
                    Key.query.filter_by(product_id=order.product_id, is_used=False)
                    .limit(1)
                    .all()
                    * order.quantity
                )
            else:
                # 如果是多渠道商品,获取多个不同密钥
                unused_keys = (
                    Key.query.filter_by(product_id=order.product_id, is_used=False)
                    .limit(order.quantity)
                    .all()
                )

            if len(unused_keys) < order.quantity:
                error_msg = "❌ 商品库存不足\n\n"
                error_msg += "非常抱歉，商品库存不足。\n"
                error_msg += "系统已自动取消订单并退款。\n"
                error_msg += "如有疑问请联系客服。"
                self.bot.send_message(chat_id, error_msg)

                # 退款逻辑
                if order.payment_type == "BALANCE":
                    user = User.query.filter_by(
                        telegram_id=str(order.user_id),
                        bot_username=self.config.bot_username,
                    ).first()
                    if user:
                        user.balance += order.total_amount

                # 更新订单状态
                order.status = "failed"
                db.session.commit()
                return False

            try:
                # 检查是否所有密钥都是文本格式（没有file_name和file_path）
                all_text = all(
                    not key.file_name and not key.file_path for key in unused_keys
                )

                if all_text:
                    # 如果全是文本格式
                    if order.quantity <= 3:
                        # 如果数量小于等于3个，直接发送文本内容
                        msg = f"✅ 您购买的 {order.product.name}\n\n"
                        msg += f"📦 数量：{order.quantity} 个\n"
                        msg += f"🔖 订单号：{order.id}\n"
                        msg += f"⏰ 购买时间：{to_beijing(order.created_at).strftime('%Y-%m-%d %H:%M:%S')}\n"
                        msg += "\n感谢您的购买！如有问题请联系客服。\n\n"
                        msg += "=" * 30 + "\n\n"
                        for key in unused_keys:
                            msg += f"{key.content}\n"

                        self.bot.send_message(chat_id, msg)
                    else:
                        # 如果数量大于3个，生成txt文件发送
                        with tempfile.TemporaryDirectory() as temp_dir:
                            # 创建txt文件
                            txt_path = os.path.join(temp_dir, f"order_{order.id}.txt")
                            with open(txt_path, "w", encoding="utf-8") as f:
                                f.write(f"订单号: {order.id}\n")
                                f.write(f"商品名称: {order.product.name}\n")
                                f.write(f"购买数量: {order.quantity}\n")
                                f.write(
                                    f"购买时间: {to_beijing(order.created_at).strftime('%Y-%m-%d %H:%M:%S')}\n"
                                )
                                f.write("\n感谢您的购买！如有问题请联系客服。\n")
                                f.write("=" * 30 + "\n\n")
                                for key in unused_keys:
                                    f.write(f"{key.content}\n")

                            # 发送txt文件
                            with open(txt_path, "rb") as f:
                                caption = f"✅ 您购买的 {order.product.name}\n\n"
                                caption += f"📦 数量：{order.quantity} 个\n"
                                caption += f"🔖 订单号：{order.id}\n\n"
                                caption += "请查看文本文件获取密钥信息"

                                self.bot.send_document(chat_id, f, caption=caption)
                else:
                    # 创建临时目录用于存放zip文件
                    with tempfile.TemporaryDirectory() as temp_dir:
                        zip_path = os.path.join(temp_dir, f"order_{order.id}.zip")

                        # 创建zip文件
                        with zipfile.ZipFile(
                            zip_path, "w", zipfile.ZIP_DEFLATED
                        ) as zipf:
                            # 创建说明文件
                            readme_path = os.path.join(temp_dir, "README.txt")
                            with open(readme_path, "w", encoding="utf-8") as f:
                                f.write(f"订单号: {order.id}\n")
                                f.write(f"商品名称: {order.product.name}\n")
                                f.write(f"购买数量: {order.quantity}\n")
                                # 订单时间用北京时间
                                f.write(
                                    f"购买时间: {to_beijing(order.created_at).strftime('%Y-%m-%d %H:%M:%S')}\n"
                                )
                                f.write("\n感谢您的购买！如有问题请联系客服。\n")

                            # 添加说明文件到zip
                            zipf.write(readme_path, "README.txt")

                            # 添加商品文件
                            for i, key in enumerate(unused_keys, 1):
                                if os.path.exists(key.file_path):
                                    # 如果是文件或目录，递归添加
                                    base_name = os.path.basename(key.file_path)
                                    # 只取下划线前面的内容作为前端展示名
                                    if "_" in key.file_name:
                                        frontend_name = key.file_name.split("_")[0]
                                    else:
                                        frontend_name = key.file_name
                                    if os.path.isdir(key.file_path):
                                        # 如果是目录，保持完整的目录结构
                                        target_path = f"{frontend_name}"
                                        self.add_to_zip(
                                            zipf, key.file_path, target_path
                                        )
                                    else:
                                        # 如果是单个文件，直接添加
                                        target_path = f"{frontend_name}"
                                        zipf.write(key.file_path, target_path)
                                else:
                                    # 如果是文本内容，创建文本文件
                                    if "_" in key.file_name:
                                        file_name = key.file_name.split("_")[0]
                                    else:
                                        file_name = key.file_name
                                    content_path = os.path.join(temp_dir, file_name)
                                    with open(content_path, "w", encoding="utf-8") as f:
                                        f.write(key.content)
                                    zipf.write(content_path, file_name)

                        # 发送zip文件
                        with open(zip_path, "rb") as f:
                            caption = f"✅ 您购买的 {order.product.name}\n\n"
                            caption += f"📦 数量：{order.quantity} 个\n"
                            caption += f"🔖 订单号：{order.id}\n\n"
                            caption += "请查看压缩包中的说明文件"

                            self.bot.send_document(chat_id, f, caption=caption)

                # 更新密钥使用时间
                for key in unused_keys:
                    if not order.product.is_same_key:
                        key.is_used = True
                    key.used_at = datetime.utcnow()
                    # 建立订单和卡密的关联关系
                    order.keys.append(key)

                # 更新商品已使用数量
                if not order.product.is_same_key:
                    order.product.used_keys += len(unused_keys)

                # 更新订单状态
                order.status = "completed"
                db.session.commit()

                # 发送成功通知给用户
                success_msg = "🎉 订单处理完成！\n\n"
                success_msg += "您的商品已经发送，请查收。\n"
                success_msg += "如有问题请联系客服。"
                self.bot.send_message(chat_id, success_msg)

                # 处理分红
                logger.info(f"[Bot] 开始处理订单 {order.id} 的分红")
                commission_success = self.process_commission(order)
                if commission_success:
                    logger.info(f"[Bot] 订单 {order.id} 分红处理成功")
                else:
                    logger.error(f"[Bot] 订单 {order.id} 分红处理失败")

                # 发送通知给管理员
                admin_msg = f"💰 新订单完成通知\n\n"
                admin_msg += f"商品：{order.product.name}\n"
                admin_msg += f"数量：{order.quantity}\n"
                admin_msg += f"金额：{order.total_amount}\n"
                admin_msg += f"订单号：{order.id}\n"
                admin_msg += f"用户ID：{order.user_id}\n"
                user = User.query.filter_by(telegram_id=order.user_id).first()
                admin_msg += f"用户名：@{user.username if user else '未知'}"

                # 给所有管理员发送通知
                bot_config = BotConfig.query.filter_by(
                    bot_username=self.config.bot_username
                ).first()

                if bot_config and bot_config.admin_usernames:
                    admin_usernames = bot_config.admin_usernames.split(",")
                    for username in admin_usernames:
                        # 去掉@前缀再查询
                        clean_username = username.strip().lstrip("@")
                        admin = User.query.filter(
                            User.username.ilike(clean_username)
                        ).first()
                        if admin and admin.telegram_id:
                            try:
                                self.bot.send_message(admin.telegram_id, admin_msg)
                            except Exception as e:
                                logger.info(f"[Bot] 发送管理员通知失败: {str(e)}")
                                continue

                return True

            except Exception as e:
                logger.info(f"[Bot] 打包发送商品失败: {str(e)}")
                error_msg = "❌ 发送商品失败\n\n"
                error_msg += "订单处理过程中出现错误。\n"
                error_msg += "请联系客服处理。"
                self.bot.send_message(chat_id, error_msg)

                # 回滚数据库更改
                db.session.rollback()
                return False

        except Exception as e:
            logger.info(f"[Bot] 处理订单失败: {str(e)}")
            self.bot.send_message(chat_id, "❌ 订单处理失败，请联系客服")
            return False
