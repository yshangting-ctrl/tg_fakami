import time
import hashlib
import requests
import os
import logging
from logging.handlers import RotatingFileHandler

# 配置日志
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logs')
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# 创建支付日志记录器
logger = logging.getLogger('payment')

# 只有在没有处理器的情况下才添加新的处理器
if not logger.handlers:
    # 创建支付日志处理器
    payment_handler = RotatingFileHandler(
        os.path.join(log_dir, 'payment.log'),
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    payment_handler.setFormatter(
        logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    )
    logger.setLevel(logging.DEBUG)
    logger.addHandler(payment_handler)

# 创建images目录用于存储二维码
if not os.path.exists('images'):
    os.makedirs('images')


def generate_payment(config_pay, cash, payment_type):
    """生成支付订单
    Args:
        config_pay: 支付配置信息
        cash: 支付金额
    Returns:
        tuple: (image_path, trade_no) 或 None
        如果返回 None 作为 image_path，请检查 trade_no 中是否包含跳转链接
    """
    try:
        # 生成订单号 (年月日时分秒+随机数)
        out_trade_no = time.strftime('%Y%m%d%H%M%S') + str(int(time.time() * 1000))[-3:]
        backend_url = config_pay['backend_url'].rstrip('/')
        account_info = {
            'epay_pid': config_pay['epay_pid'],
            'epay_key': config_pay['epay_key'],
            'backend_url': backend_url,
            'usdt_rate': config_pay['usdt_rate']
        }

        logger.info(f"开始生成支付订单: {out_trade_no}")
        logger.debug(f"支付配置: {account_info}")

        # 支付参数
        params = {
            'pid': account_info['epay_pid'],  # 商户ID
            'type': 'wxpay' if payment_type == 'weixin' else 'alipay' if payment_type == 'zfb' else 'wxpay',  # 支付方式
            'out_trade_no': out_trade_no,  # 商户订单号
            'notify_url': f"{account_info['backend_url']}/notify",  # 异步通知地址
            'return_url': config_pay.get('return_url') or backend_url,
            'name': 'VIP会员',  # 商品名称
            'money': str(cash),  # 商品金额
            'clientip': '127.0.0.1',  # 用户IP地址
            'device': 'pc',  # 设备类型
            'param': '',  # 业务扩展参数
            'sign_type': 'MD5'  # 签名类型
        }

        # 准备签名的参数（排除sign、sign_type和空值）
        sign_params = {}
        for k, v in params.items():
            # 跳过sign、sign_type和空值
            if k not in ['sign', 'sign_type'] and v != '':
                sign_params[k] = v

        # 按照参数名ASCII码从小到大排序
        param_list = sorted(sign_params.items(), key=lambda x: x[0])

        # 拼接成URL键值对的格式
        param_str = '&'.join([f'{k}={v}' for k, v in param_list])

        # 直接拼接商户密钥（不加任何前缀）
        param_str = param_str + account_info['epay_key']

        logger.debug(f"待签名字符串: {param_str}")

        # 生成MD5签名（结果为小写）
        sign = hashlib.md5(param_str.encode('utf-8')).hexdigest().lower()
        params['sign'] = sign

        logger.debug(f"生成的签名: {sign}")

        # 构建支付跳转URL
        api_url = 'https://futoon.org/submit.php'

        # 构建完整的支付URL
        param_list = []
        for k, v in params.items():
            param_list.append(f"{k}={requests.utils.quote(str(v))}")
        payment_url = f"{api_url}?{'&'.join(param_list)}"

        logger.info(f"订单生成成功 - 订单号: {out_trade_no}, 金额: {params['money']}")
        logger.info(f"支付跳转链接: {payment_url}")

        # 返回支付链接
        return None, payment_url
    except Exception as e:
        logger.error(f"生成支付订单时发生错误: {str(e)}", exc_info=True)
        return None, None
