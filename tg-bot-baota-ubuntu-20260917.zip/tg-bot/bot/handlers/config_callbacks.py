from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from models.config import BotConfig
from models.user import User
from models.order import Order
from datetime import datetime, timedelta
from sqlalchemy import func
import traceback
from logging import getLogger
logger = getLogger(__name__)

class ConfigCallbacks:
    def __init__(self, handler):
        self.handler = handler
        self.bot = handler.bot
        self.config = handler.config
        self.app = handler.app
    
    def handle_commission(self, call):
        """处理返佣提成设置"""
        try:
            logger.info("[Bot] 开始处理返佣提成设置")
            
            with self.app.app_context():
                # 获取当前配置
                bot_username = self.config.bot_username  # 先获取用户名
                logger.info(f"[Bot] 机器人用户名: {bot_username}")
                
                # 获取最新配置
                bot_config = BotConfig.query.filter_by(bot_username=bot_username).first()
                if not bot_config:
                    logger.info("[Bot] 错误：找不到机器人配置")
                    self.bot.answer_callback_query(call.id, "错误：找不到机器人配置")
                    return
                
                logger.info(f"[Bot] 当前配置: {bot_config.parent_bot_username}")
                if not bot_config.parent_bot_username:
                    self.bot.edit_message_text(
                        "您已经是源头，无法配置返佣，请给克隆机器人一个机会吧。",
                        call.message.chat.id,
                        call.message.message_id
                    )
                    return
                
                current_rate = bot_config.commission_rate
                logger.info(f"[Bot] 当前返佣比例: {current_rate}%")
                
                # 更新本地配置
                self.config = bot_config
                
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("➖", callback_data="commission_minus"),
                    InlineKeyboardButton(f"{current_rate:.1f}%", callback_data="noop"),
                    InlineKeyboardButton("➕", callback_data="commission_plus")
                )
                keyboard.row(
                    InlineKeyboardButton("✏️ 手动输入", callback_data="commission_input")
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                )
                
                msg = "💰 返佣提成设置\n\n"
                msg += f"当前比例: {current_rate:.1f}%"
                
                self.bot.edit_message_text(
                    msg,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=keyboard
                )
                logger.info("[Bot] 界面更新成功")
                
        except Exception as e:
            logger.info(f"[Bot] 处理返佣设置出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_admins(self, call):
        """处理管理员设置"""
        try:
            logger.info("[Bot] 开始处理管理员设置")
            
            with self.app.app_context():
                # 获取当前配置
                bot_username = self.config.bot_username  # 先获取用户名
                logger.info(f"[Bot] 机器人用户名: {bot_username}")
                
                # 获取最新配置
                bot_config = BotConfig.query.filter_by(bot_username=bot_username).first()
                if not bot_config:
                    logger.info("[Bot] 错误：找不到机器人配置")
                    self.bot.answer_callback_query(call.id, "错误：找不到机器人配置")
                    return
                
                # 更新本地配置
                self.config = bot_config
                
                # 获取当前管理员列表
                current_admins = bot_config.admin_usernames.split(',') if bot_config.admin_usernames else []
                logger.info(f"[Bot] 当前管理员列表: {current_admins}")
                
                keyboard = InlineKeyboardMarkup()
                msg = "👥 管理员设置\n\n"
                msg += "当前管理员:\n"
                
                # 显示管理员列表
                for admin in current_admins:
                    if admin.strip():
                        msg += f"• @{admin.strip()}\n"
                        keyboard.row(
                            InlineKeyboardButton(f"❌ 删除 @{admin.strip()}", callback_data=f"admin_del_{admin.strip()}")
                        )
                
                keyboard.row(
                    InlineKeyboardButton("➕ 添加管理员", callback_data="admin_add")
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                )
                
                self.bot.edit_message_text(
                    msg,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=keyboard
                )
                logger.info("[Bot] 管理员设置界面更新成功")
            
        except Exception as e:
            logger.info(f"[Bot] 处理管理员设置出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_announcement(self, call):
        """处理公告设置"""
        try:
            logger.info("开始处理公告设置")  # 调试日志
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton("✏️ 修改公告", callback_data="edit_announcement")  # 修改这里的callback_data
            )
            keyboard.row(
                InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
            )
            
            msg = "📝 机器人公告\n\n"
            msg += self.config.announcement if self.config.announcement else "暂无公告"
            
            logger.info("准备发送公告设置消息")  # 调试日志
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard,
                parse_mode='HTML'  # 支持HTML格式
            )
            logger.info("公告设置消息发送成功")  # 调试日志
            
        except Exception as e:
            logger.info(f"[Bot] 处理公告设置出错: {str(e)}")
            logger.info(f"错误详情: {str(e.__traceback__.tb_lineno)}")  # 添加行号信息
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_status(self, call):
        """处理机器人状态"""
        try:
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton(
                    "🟢 已启用" if self.config.is_active else "🔴 已禁用", 
                    callback_data="status_toggle"
                )
            )
            keyboard.row(
                InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
            )
            
            msg = "⚡️ 机器人状态\n\n"
            msg += f"当前状态: {'已启用' if self.config.is_active else '已禁用'}\n"
            msg += f"创建时间: {self.config.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n"
            msg += f"更新时间: {self.config.updated_at.strftime('%Y-%m-%d %H:%M:%S')}"
            
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard
            )
            
        except Exception as e:
            logger.info(f"[Bot] 处理状态设置出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_clone(self, call):
        """处理克隆设置"""
        try:
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton(
                    "✅ 允许克隆" if self.config.allow_clone else "❌ 禁止克隆", 
                    callback_data="clone_toggle"
                )
            )
            keyboard.row(
                InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
            )
            
            msg = "🔄 克隆设置\n\n"
            msg += f"当前状态: {'允许' if self.config.allow_clone else '禁止'}克隆\n"
            
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard
            )
            
        except Exception as e:
            logger.info(f"[Bot] 处理克隆设置出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_subordinates(self, call):
        """处理下级机器人"""
        try:
            with self.app.app_context():
                # 获取下级机器人列表
                subs = BotConfig.query.filter_by(parent_bot_username=self.config.bot_username).all()
                
                keyboard = InlineKeyboardMarkup()
                msg = "👨‍👦 我的下级机器人\n\n"
                
                if not subs:
                    msg += "暂无下级机器人"
                else:
                    for sub in subs:
                        msg += f"• @{sub.bot_username}\n"
                        msg += f"  └ 状态: {'启用' if sub.is_active else '禁用'}\n"
                        msg += f"  └ 创建时间: {sub.created_at.strftime('%Y-%m-%d')}\n\n"
                
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                )
                
                self.bot.edit_message_text(
                    msg,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=keyboard
                )
            
        except Exception as e:
            logger.info(f"[Bot] 处理下级列表出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_stats(self, call):
        """处理数据统计"""
        try:
            with self.app.app_context():
                # 获取今日订单数据
                today = datetime.utcnow().date()
                today_start = datetime.combine(today, datetime.min.time())
                today_end = datetime.combine(today, datetime.max.time())
                
                today_orders = Order.query.filter(
                    Order.bot_username == self.config.bot_username,
                    Order.created_at.between(today_start, today_end)
                )
                
                today_total = today_orders.count()
                today_completed = today_orders.filter_by(status='completed').count()
                today_amount = today_orders.filter_by(status='completed').with_entities(
                    func.sum(Order.total_amount)
                ).scalar() or 0
                
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("📅 查看历史", callback_data="stats_history")
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                )
                
                msg = "📊 今日数据统计\n\n"
                msg += f"总订单数: {today_total}\n"
                msg += f"完成订单: {today_completed}\n"
                msg += f"成交金额: {today_amount:.2f} USDT"
                
                self.bot.edit_message_text(
                    msg,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=keyboard
                )
            
        except Exception as e:
            logger.info(f"[Bot] 处理数据统计出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_back_to_config(self, call):
        """返回配置主菜单"""
        try:
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton("💰 返佣提成", callback_data="config_commission"),
                InlineKeyboardButton("👥 管理员设置", callback_data="config_admins")
            )
            keyboard.row(
                InlineKeyboardButton("📝 修改公告", callback_data="config_announcement"),
                InlineKeyboardButton("🔄 克隆开关", callback_data="config_clone")
            )
            keyboard.row(
                InlineKeyboardButton("📊 数据统计", callback_data="config_stats")
            )
            
            msg = "⚙️ 机器配置\n\n"
            msg += "请选择要修改的配置项："
            
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard
            )
            
        except Exception as e:
            logger.info(f"[Bot] 返回配置主菜单出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")