from .base_handler import BaseHandler
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from .config_callbacks import ConfigCallbacks
from .config_actions import ConfigActions
import traceback
from logging import getLogger
logger = getLogger(__name__)

class ConfigHandler(BaseHandler):
    def __init__(self, bot_instance):
        super().__init__(bot_instance)
        self.callbacks = ConfigCallbacks(self)
        self.actions = ConfigActions(self)
        
    def show_config(self, message):
        """显示机器配置"""
        with self.app.app_context():
            try:
                # 检查是否是管理员
                if not self.is_admin(message.from_user.username):
                    self.bot.reply_to(message, "⚠️ 您没有权限访问此功能")
                    return
                
                # 创建配置菜单
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("💰 返佣提成", callback_data="config_commission"),
                    InlineKeyboardButton("👥 管理员设置", callback_data="config_admins")
                )
                keyboard.row(
                    InlineKeyboardButton("📝 修改公告", callback_data="config_announcement"),
                    InlineKeyboardButton("🔄 克隆开关", callback_data="config_clone"),
                )
                keyboard.row(
                    InlineKeyboardButton("👨‍👦 我的下级", callback_data="config_subordinates"),
                    InlineKeyboardButton("📊 数据统计", callback_data="config_stats")
                )
                
                msg = "⚙️ 机器配置\n\n"
                msg += "请选择要修改的配置项："
                
                self.bot.reply_to(message, msg, reply_markup=keyboard)
                
            except Exception as e:
                logger.info(f"[Bot] 显示机器配置出错: {str(e)}")
                self.bot.reply_to(message, "抱歉，获取配置信息失败，请稍后重试")
    
    def handle_callback(self, call):
        """处理配置相关的回调查询"""
        try:
            # 检查是否是管理员
            if not self.is_admin(call.from_user.username):
                logger.info(f"[Bot] 用户 {call.from_user.username} 不是管理员")
                self.bot.answer_callback_query(call.id, "⚠️ 您没有权限执行此操作")
                return
            
            logger.info(f"[Bot] 收到回调: {call.data}")  # 调试日志
            
            # 处理回调
            if call.data == "edit_announcement":
                logger.info("[Bot] ====== 准备处理公告编辑 ======")
                logger.info(f"[Bot] 回调数据: {call.data}")
                logger.info(f"[Bot] 消息ID: {call.message.message_id}")
                logger.info(f"[Bot] 聊天ID: {call.message.chat.id}")
                logger.info("[Bot] ============================")
                self.actions.handle_announcement_edit(call)
                return
            
            data = call.data.split('_')
            
            # 处理主菜单回调
            if call.data.startswith("config_"):
                action = data[1] if len(data) > 1 else None
                
                if action == "commission":
                    self.callbacks.handle_commission(call)
                elif action == "admins":
                    self.callbacks.handle_admins(call)
                elif action == "announcement":
                    logger.info("[Bot] 处理公告设置")  # 调试日志
                    self.callbacks.handle_announcement(call)
                elif action == "status":
                    self.callbacks.handle_status(call)
                elif action == "clone":
                    self.callbacks.handle_clone(call)
                elif action == "basic":
                    self.callbacks.handle_basic(call)
                elif action == "subordinates":
                    self.callbacks.handle_subordinates(call)
                elif action == "stats":
                    self.callbacks.handle_stats(call)
            
            # 处理返回主菜单
            elif call.data == "back_to_config":
                self.callbacks.handle_back_to_config(call)
            
            # 处理其他具体操作
            elif call.data.startswith("commission_"):
                self.actions.handle_commission_adjust(call, data[1])
            elif call.data == "clone_toggle":
                self.actions.handle_clone_toggle(call)
            elif call.data == "admin_add":
                self.actions.handle_admin_add(call)
            elif call.data.startswith("admin_del_"):
                self.actions.handle_admin_delete(call, data[2])
            elif call.data == "status_toggle":
                self.actions.handle_status_toggle(call)
            elif call.data == "basic_recharge":
                self.actions.handle_basic_recharge(call)
            elif call.data == "basic_epay":
                self.actions.handle_basic_epay(call)
            elif call.data == "stats_history":
                self.actions.handle_stats_history(call)
            else:
                logger.info(f"[Bot] 未处理的回调类型: {call.data}")
            
            # 只有在不是编辑状态时才发送默认回复
            if not call.data in ["edit_announcement", "admin_add", "basic_recharge", "basic_epay"]:
                self.bot.answer_callback_query(call.id)
            
        except Exception as e:
            logger.info(f"[Bot] 处理配置回调出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出现错误")
    
    def handle_text(self, message):
        """处理文本消息"""
        try:
            user_id = str(message.from_user.id)
            
            # 检查用户状态
            if user_id in self.actions._user_states:
                state = self.actions._user_states[user_id]
                
                if message.text == '/cancel':
                    del self.actions._user_states[user_id]
                    self.bot.reply_to(message, "❌ 已取消操作")
                    return
                
                if state['state'] == 'waiting_announcement':
                    self.actions.save_announcement(message)
                elif state['state'] == 'waiting_admin_username':
                    self.actions.save_admin(message)
                elif state['state'] == 'waiting_recharge_address':
                    self.actions.save_recharge_address(message)
                elif state['state'] == 'waiting_epay_config':
                    self.actions.save_epay_config(message)
                elif state['state'] == 'waiting_commission_rate':
                    self.actions.save_commission_rate(message)
                
        except Exception as e:
            logger.info(f"[Bot] 处理配置文本消息出错: {str(e)}")
            self.bot.reply_to(message, "处理请求时出现错误") 