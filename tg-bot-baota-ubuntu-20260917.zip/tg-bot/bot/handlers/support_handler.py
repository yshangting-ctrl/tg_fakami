from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from .base_handler import BaseHandler
import traceback
from logging import getLogger
logger = getLogger(__name__)

class SupportHandler(BaseHandler):
    def __init__(self, bot_instance):
        super().__init__(bot_instance)
        # 保存 bot_username 为字符串，避免 DetachedInstanceError
        self.bot_username = str(bot_instance.config.bot_username)

    def contact_support(self, message):
        """联系客服"""
        try:
            with self.app.app_context():
                from models.config import BotConfig
                from extensions import db
                
                logger.info(f"[Bot] 机器人用户名: {self.bot_username}")
                
                # 获取机器人配置
                bot_config = db.session.query(BotConfig).filter_by(bot_username=self.bot_username).first()
                if not bot_config:
                    logger.info("[Bot] 错误：找不到机器人配置")
                    self.bot.reply_to(message, "❌ 错误：系统配置异常，请稍后重试")
                    return
                
                # 获取客服列表（管理员列表）
                support_staff = bot_config.admin_usernames.split(',') if bot_config.admin_usernames else []
                
                if not support_staff:
                    self.bot.reply_to(message, "⚠️ 暂无可用的客服人员")
                    return
                
                # 创建客服列表消息
                msg = "📞 客服列表\n\n"
                msg += "请选择要联系的客服：\n\n"
                
                # 创建内联键盘
                keyboard = InlineKeyboardMarkup()
                
                # 添加每个客服的联系按钮
                for staff in support_staff:
                    if staff.strip():  # 确保用户名不为空
                        staff_name = staff.strip().lstrip('@')  # 移除可能存在的 @ 前缀
                        msg += f"• @{staff_name}\n"
                        keyboard.row(
                            InlineKeyboardButton(
                                f"💬 联系 @{staff_name}",
                                url=f"https://t.me/{staff_name}"
                            )
                        )
                
                # 发送消息
                self.bot.reply_to(
                    message,
                    msg,
                    reply_markup=keyboard,
                    parse_mode='HTML'
                )
                logger.info("[Bot] 客服列表发送成功")
                
        except Exception as e:
            logger.info(f"[Bot] 显示客服列表出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.reply_to(message, "❌ 获取客服列表失败，请稍后重试") 