#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import hashlib
import requests
import time
from datetime import datetime
from logging import getLogger

logger = getLogger(__name__)

class OkayPay:
    """OkayPay支付接口类"""
    
    def __init__(self, merchant_id, token):
        self.merchant_id = merchant_id
        self.token = token
        self.api_base_url = 'https://api.okaypay.me/shop/'
    
    def sign_data(self, data):
        """对数据进行签名"""
        data['id'] = self.merchant_id
        data = {k: v for k, v in data.items() if v is not None and v != ''}
        sorted_data = dict(sorted(data.items()))
        query_string = '&'.join([f"{k}={v}" for k, v in sorted_data.items()])
        sign_string = f"{query_string}&token={self.token}"
        signature = hashlib.md5(sign_string.encode('utf-8')).hexdigest().upper()
        data['sign'] = signature
        return data
    
    def create_payment_link(self, amount, coin, unique_id=None, name=None):
        """创建支付链接"""
        data = {'amount': amount, 'coin': coin}
        if unique_id:
            data['unique_id'] = unique_id
        if name:
            data['name'] = name
        
        return self._make_request(self.api_base_url + 'payLink', data)
    
    def _make_request(self, url, data):
        """发送HTTP请求"""
        try:
            signed_data = self.sign_data(data)
            logger.info(f"[OkayPay] 发送请求到: {url}")
            logger.info(f"[OkayPay] 请求数据: {signed_data}")
            
            response = requests.post(url, data=signed_data, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                logger.info(f"[OkayPay] 响应成功: {result}")
                return result
            else:
                logger.error(f"[OkayPay] HTTP错误 {response.status_code}: {response.text}")
                return {'error': f'HTTP {response.status_code}', 'message': response.text}
                
        except Exception as e:
            logger.error(f"[OkayPay] 请求异常: {str(e)}")
            return {'error': 'RequestException', 'message': str(e)}

class PaymentBot:
    """支付机器人主类"""
    
    def __init__(self, merchant_id, token):
        self.okaypay = OkayPay(merchant_id, token)
    
    def create_payment(self, user_id, amount, coin, description=None):
        """创建支付"""
        try:
            unique_id = f"order_{user_id}_{int(time.time())}"
            
            result = self.okaypay.create_payment_link(
                amount=amount,
                coin=coin,
                unique_id=unique_id,
                name=description or f"用户{user_id}的支付"
            )
            
            if 'error' not in result:
                # 提取支付链接
                payment_url = (result.get('pay_url') or
                             result.get('data', {}).get('pay_url') or
                             result.get('payment_url') or
                             result.get('url'))
                
                # 提取API订单ID
                api_order_id = (result.get('order_id') or 
                              result.get('data', {}).get('order_id') or
                              result.get('id') or
                              result.get('orderId'))
                
                return {
                    'success': True,
                    'order_id': unique_id,
                    'api_order_id': api_order_id,
                    'payment_url': payment_url or '',
                    'message': '支付创建成功'
                }
            else:
                return {
                    'success': False,
                    'error': result.get('error', 'Unknown error'),
                    'message': result.get('message', '创建支付失败')
                }
                
        except Exception as e:
            logger.error(f"[OkayPay] 创建支付异常: {str(e)}")
            return {
                'success': False,
                'error': 'Exception',
                'message': str(e)
            }

def create_payment_direct(user_id, amount, coin, merchant_id, token, description=None):
    """
    直接创建支付的函数
    
    Args:
        user_id: 用户ID
        amount: 支付金额
        coin: 币种 (USDT, TRX)
        merchant_id: 商户ID
        token: 商户密钥
        description: 支付描述 (可选)
    
    Returns:
        支付结果字典
    """
    logger.info(f"[OkayPay] === 正在创建支付 ===")
    logger.info(f"[OkayPay] 用户ID: {user_id}")
    logger.info(f"[OkayPay] 金额: {amount} {coin}")
    logger.info(f"[OkayPay] 商户ID: {merchant_id}")
    logger.info(f"[OkayPay] 描述: {description or '无'}")
    
    # 创建支付机器人实例
    bot = PaymentBot(merchant_id, token)
    
    # 创建支付
    result = bot.create_payment(user_id, amount, coin, description)
    
    if result['success']:
        logger.info(f"[OkayPay] ✅ 支付创建成功!")
        logger.info(f"[OkayPay] 订单号: {result['order_id']}")
        if result.get('api_order_id'):
            logger.info(f"[OkayPay] API订单ID: {result['api_order_id']}")
        if result.get('payment_url'):
            logger.info(f"[OkayPay] 支付链接: {result['payment_url']}")
        else:
            logger.warning(f"[OkayPay] ⚠️  未找到支付链接")
    else:
        logger.error(f"[OkayPay] ❌ 支付创建失败: {result['message']}")
    
    return result
