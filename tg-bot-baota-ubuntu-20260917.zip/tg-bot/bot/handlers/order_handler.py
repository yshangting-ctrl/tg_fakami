from models.order import Order
from .base_handler import BaseHandler
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from logging import getLogger
logger = getLogger(__name__)

class OrderHandler(BaseHandler):
    def show_orders(self, message, page=1):
        """显示订单列表
        Args:
            message: Telegram消息对象
            page: 当前页码，从1开始
        """
        with self.app.app_context():
            try:
                user_id = str(message.from_user.id)
                # 每页显示5条订单
                page_size = 5
                
                # 计算分页
                offset = (page - 1) * page_size
                orders = Order.query.filter_by(
                    user_id=user_id,
                    bot_username=self.config.bot_username  # 添加机器人用户名过滤
                ).order_by(Order.created_at.desc()).offset(offset).limit(page_size).all()
                
                # 获取总订单数
                total_orders = Order.query.filter_by(
                    user_id=user_id,
                    bot_username=self.config.bot_username  # 添加机器人用户名过滤
                ).count()
                total_pages = (total_orders + page_size - 1) // page_size
                
                if not orders:
                    if page == 1:
                        self.bot.reply_to(message, "您还没有任何订单")
                    else:
                        self.bot.reply_to(message, "没有更多订单了")
                    return
                
                # 创建分页键盘
                keyboard = InlineKeyboardMarkup()
                row_buttons = []
                
                # 上一页按钮
                if page > 1:
                    row_buttons.append(
                        InlineKeyboardButton("⬅️ 上一页", callback_data=f"order_page_{page-1}")
                    )
                
                # 页码信息
                row_buttons.append(
                    InlineKeyboardButton(f"第 {page}/{total_pages} 页", callback_data="noop")
                )
                
                # 下一页按钮
                if page < total_pages:
                    row_buttons.append(
                        InlineKeyboardButton("下一页 ➡️", callback_data=f"order_page_{page+1}")
                    )
                
                keyboard.row(*row_buttons)

                print(orders[0].product)
                
                # 构建订单列表消息
                msg = "📋 订单列表\n\n"
                for order in orders:
                    # 添加订单分隔线
                    msg += "━━━━━━━━━━\n"
                    msg += f"🔖 订单号：{order.id}\n"
                    if order.product and getattr(order.product, 'name', None):
                        msg += f"💎 商品：{order.product.name}\n"
                    else:
                        msg += "💎 商品：项目已被删除\n"
                    msg += f"📦 数量：{order.quantity}\n"
                    msg += f"💰 金额：${order.total_amount:.2f}\n"
                    msg += f"💳 支付方式：{order.payment_type}\n"
                    msg += f"📊 状态：{self.get_order_status(order.status)}\n"
                    msg += f"🕒 时间：{order.created_at.strftime('%Y-%m-%d %H:%M')}\n"
                
                msg += "\n总订单数：" + str(total_orders)
                
                self.bot.reply_to(message, msg, reply_markup=keyboard)
                
            except Exception as e:
                logger.info(f"[Bot] 显示订单列表出错: {str(e)}")
                self.bot.reply_to(message, "抱歉，获取订单列表失败，请稍后重试")
    
    def handle_order_callback(self, call):
        """处理订单相关的回调查询"""
        try:
            data = call.data.split('_')
            if data[0] == "order" and data[1] == "page":
                page = int(data[2])
                self.show_orders(call.message, page)
                
        except Exception as e:
            logger.info(f"[Bot] 处理订单回调出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")
    
    def get_order_status(self, status):
        """获取订单状态显示文本"""
        status_map = {
            'pending': '⏳ 待支付',
            'processing': '⚡️ 处理中',
            'completed': '✅ 已完成',
            'cancelled': '❌ 已取消'
        }
        return status_map.get(status, status) 