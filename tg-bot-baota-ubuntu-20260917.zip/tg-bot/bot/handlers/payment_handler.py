from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from models.order import Order
from .base_handler import BaseHandler
from models.user import User
from models.balance_log import BalanceLog
from datetime import datetime, timedelta, timezone
import time
from app import db
import random
import string
import threading
import time
from logging import getLogger
logger = getLogger(__name__)

# 增加获取北京时间的辅助函数
def get_beijing_time(dt=None):
    """返回北京时间（东八区）"""
    if dt is None:
        dt = datetime.utcnow()
    return dt.replace(tzinfo=timezone.utc).astimezone(timezone(timedelta(hours=8))).replace(tzinfo=None)

class PaymentHandler(BaseHandler):
    def __init__(self, bot_instance):
        super().__init__(bot_instance)
        self._user_states = {}  # 用于存储用户状态
        self._last_check_time = {}  # 用于存储用户最后点击支付检查的时间

    def show_recharge(self, message):
        """显示充值信息"""
        with self.app.app_context():
            try:
                # 创建充值键盘
                keyboard = InlineKeyboardMarkup()
                amounts = [10, 30, 50, 100, 200, 500]
                
                # 添加金额按钮
                for i in range(0, len(amounts), 2):
                    row_buttons = []
                    for amount in amounts[i:i+2]:
                        button = InlineKeyboardButton(
                            f"💰 {amount} USDT",
                            callback_data=f"recharge_{amount}"
                        )
                        row_buttons.append(button)
                    keyboard.row(*row_buttons)
                
                # 添加自定义金额按钮
                keyboard.add(InlineKeyboardButton(
                    "💰 自定义金额",
                    callback_data="recharge_custom"
                ))
                
                msg = "💰 余额充值\n\n"
                msg += "请选择充值金额："
                
                self.bot.reply_to(message, msg, reply_markup=keyboard)
                
            except Exception as e:
                logger.info(f"[Bot] 显示充值信息出错: {str(e)}")
                self.bot.reply_to(message, "抱歉，获取充值信息失败，请稍后重试")
    
    def show_custom_recharge(self, message):
        """显示自定义充值金额输入提示"""
        try:
            user_id = str(message.chat.id)
            self._user_states[user_id] = {
                'state': 'waiting_recharge_amount',
                'message_id': message.message_id
            }
            
            msg = "💰 自定义充值金额\n\n"
            msg += "请直接发送充值金额（USDT），例如：100"
            self.bot.reply_to(message, msg)
            
        except Exception as e:
            logger.info(f"[Bot] 显示自定义充值提示出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")
    
    def handle_custom_amount(self, message):
        """处理用户输入的自定义充值金额"""
        try:
            amount = float(message.text)
            if amount <= 0:
                self.bot.reply_to(message, "充值金额必须大于0")
                return
            
            # 创建充值订单
            self.create_recharge_order(message, amount)
            
            # 清理用户状态
            user_id = str(message.from_user.id)
            if user_id in self._user_states:
                del self._user_states[user_id]
            
        except ValueError:
            self.bot.reply_to(message, "请输入有效的数字金额")
            del self._user_states[user_id]

        except Exception as e:
            logger.info(f"[Bot] 处理自定义充值金额出错: {str(e)}")
            self.bot.reply_to(message, "抱歉，处理充值请求时出现错误，请稍后重试")
            del self._user_states[user_id]
    def generate_unique_payment_amount(self, base_amount):
        """生成唯一的支付金额
        Args:
            base_amount: 基础金额
        Returns:
            float: 唯一的支付金额
        """
        try:
            # 获取30分钟内的所有USDT订单的金额(包括所有状态)
            thirty_mins_ago = datetime.utcnow() - timedelta(minutes=30)
            existing_amounts = set(
                order.total_amount 
                for order in Order.query.filter(
                    Order.payment_type == 'USDT',
                    Order.created_at >= thirty_mins_ago
                ).all()
            )
            
            # 从基础金额开始，每次加0.01，直到找到一个未使用的金额
            amount = float(base_amount)
            while amount in existing_amounts:
                amount = round(amount + 0.01, 2)
            
            logger.info(f"[Bot] 生成唯一支付金额 - 基础金额: {base_amount}, 最终金额: {amount}, 现有金额: {existing_amounts}")
            return amount
            
        except Exception as e:
            logger.info(f"[Bot] 生成唯一支付金额出错: {str(e)}")
            # 如果出错，返回原始金额
            return base_amount

    def create_recharge_order(self, message, amount):
        """创建充值订单
        Args:
            message: Telegram消息对象
            amount: 充值金额
        """
        with self.app.app_context():
            try:
                user_id = str(message.from_user.id)
                chat_id = message.chat.id
                logger.info(f"[Bot] 创建充值订单 - 用户ID: {user_id}")

                user = User.query.filter_by(
                    telegram_id=str(user_id),
                    bot_username=self.config.bot_username
                ).first()
                
                if not user:
                    logger.info(f"[Bot] 用户不存在: {user_id}")
                    self.bot.send_message(chat_id, "用户信息不存在，请先使用 /start 命令注册")
                    return
                
                # 生成16位随机订单号
                order_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
                logger.info(f"[Bot] 开始创建充值订单: {order_id}, 用户: {user_id}, 金额: {amount}")

                # 生成唯一支付金额
                total_amount = self.generate_unique_payment_amount(amount)
                
                # 创建充值订单
                order = Order(
                    id=order_id,
                    user_id=user_id,
                    product_id=None,  # 充值订单不关联商品
                    bot_username=self.config.bot_username,
                    unit_price=total_amount,  # 单价就是充值金额
                    quantity=1,  # 充值订单数量固定为1
                    total_amount=total_amount,
                    payment_type='USDT',
                    status='pending',
                    payment_address=self.config.recharge_address,  # 使用配置的充值地址
                    remark1='recharge'  # 标记这是充值订单
                )
                
                # 设置订单过期时间（北京时间）
                order.created_at = datetime.utcnow()
                beijing_created_at = get_beijing_time(order.created_at)
                expire_time = beijing_created_at + timedelta(minutes=30)
                
                try:
                    db.session.add(order)
                    db.session.commit()
                    logger.info(f"[Bot] 充值订单创建成功: {order.id}")
                except Exception as e:
                    logger.info(f"[Bot] 数据库操作失败: {str(e)}")
                    db.session.rollback()
                    raise
                
                # 创建支付信息键盘
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("✅ 支付完成", callback_data=f"check_recharge_{order.id}")
                )
                keyboard.row(
                    InlineKeyboardButton("❌ 取消充值", callback_data=f"cancel_recharge_{order.id}")
                )
                
                # 发送支付信息
                msg = "💰 USDT充值订单\n\n"
                msg += f"📝 订单号：{order.id}\n"
                msg += "------------\n"
                msg += "💳 收款地址：\n"
                msg += f"`{order.payment_address}`\n"  # 使用Markdown格式使地址可点击复制
                msg += "👆 点击上方地址即可复制\n\n"
                msg += f"💵 实付金额：{total_amount:.2f} USDT\n"  # 显示实际需要支付的金额
                msg += "------------\n"
                msg += f"⏰ 创建时间：{beijing_created_at.strftime('%Y-%m-%d %H:%M:%S')} (北京时间)\n"
                msg += f"⌛️ 结束时间：{expire_time.strftime('%Y-%m-%d %H:%M:%S')} (北京时间)\n\n"
                msg += "⚠️ 注意事项：\n"
                msg += "1️⃣ 请在规定时间内完成付款\n"
                msg += "2️⃣ 必须使用 TRC20 网络转账\n"
                msg += "3️⃣ 转账金额必须完全一致\n"
                msg += "4️⃣ 点击地址自动复制"
                
                self.bot.send_message(
                    chat_id, 
                    msg, 
                    reply_markup=keyboard,
                    parse_mode='Markdown'
                )
                
            except Exception as e:
                logger.info(f"[Bot] 创建充值订单出错: {str(e)}")
                if hasattr(e, '__traceback__'):
                    import traceback
                    logger.info(traceback.format_exc())
                self.bot.send_message(chat_id, "抱歉，创建充值订单失败，请稍后重试")
    
    def handle_payment_callback(self, call):
        """处理支付回调查询"""
        try:
            parts = call.data.split("_")
            if len(parts) < 2:
                return
            
            action = parts[1]
            user_id = str(call.from_user.id)
            chat_id = call.message.chat.id
            logger.info(f"[Bot] 处理充值回调: action={action}, user_id={user_id}")
            
            if action == "custom":
                # 处理自定义金额输入
                self.show_custom_recharge(call.message)
                self.bot.answer_callback_query(call.id)
            elif action.isdigit():
                # 处理预设金额选择
                amount = float(action)
                
                # 删除原消息
                try:
                    self.bot.delete_message(chat_id, call.message.message_id)
                except Exception as e:
                    logger.info(f"[Bot] 删除消息失败: {str(e)}")
                
                # 创建新的充值订单，使用正确的用户ID
                self.create_recharge_order_from_callback(user_id, chat_id, amount)
                self.bot.answer_callback_query(call.id)
            
        except Exception as e:
            logger.info(f"[Bot] 处理充值回调出错: {str(e)}")
            if hasattr(e, '__traceback__'):
                import traceback
                logger.info(traceback.format_exc())
            self.bot.answer_callback_query(call.id, "处理请求时出现错误")

    def create_recharge_order_from_callback(self, user_id, chat_id, amount):
        """从回调创建充值订单
        Args:
            user_id: 用户ID
            chat_id: 聊天ID
            amount: 充值金额
        """
        with self.app.app_context():
            try:
                logger.info(f"[Bot] 创建充值订单 - 用户ID: {user_id}")
                # 检查用户是否存在
                user = User.query.filter_by(
                    telegram_id=str(user_id),
                    bot_username=self.config.bot_username
                ).first()

                if not user:
                    logger.info(f"[Bot] 用户不存在: {user_id}")
                    self.bot.send_message(chat_id, "用户信息不存在，请先使用 /start 命令注册")
                    return
                
                # 生成16位随机订单号
                order_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
                logger.info(f"[Bot] 开始创建充值订单: {order_id}, 用户: {user_id}, 金额: {amount}")

                # 生成唯一支付金额
                total_amount = self.generate_unique_payment_amount(amount)
                
                # 创建充值订单
                order = Order(
                    id=order_id,
                    user_id=user_id,
                    product_id=None,  # 充值订单不关联商品
                    bot_username=self.config.bot_username,
                    unit_price=total_amount,  # 单价就是充值金额
                    quantity=1,  # 充值订单数量固定为1
                    total_amount=total_amount,
                    payment_type='USDT',
                    status='pending',
                    payment_address=self.config.recharge_address,  # 使用配置的充值地址
                    remark1='recharge'  # 标记这是充值订单
                )
                
                # 设置订单过期时间（北京时间）
                order.created_at = datetime.utcnow()
                beijing_created_at = get_beijing_time(order.created_at)
                expire_time = beijing_created_at + timedelta(minutes=30)
                
                try:
                    db.session.add(order)
                    db.session.commit()
                    logger.info(f"[Bot] 充值订单创建成功: {order.id}")
                except Exception as e:
                    logger.info(f"[Bot] 数据库操作失败: {str(e)}")
                    db.session.rollback()
                    raise
                
                # 创建支付信息键盘
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("✅ 支付完成", callback_data=f"check_recharge_{order.id}")
                )
                keyboard.row(
                    InlineKeyboardButton("❌ 取消充值", callback_data=f"cancel_recharge_{order.id}")
                )
                
                # 发送支付信息
                msg = "💰 USDT充值订单\n\n"
                msg += f"📝 订单号：{order.id}\n"
                msg += "------------\n"
                msg += "💳 收款地址：\n"
                msg += f"`{order.payment_address}`\n"  # 使用Markdown格式使地址可点击复制
                msg += "👆 点击上方地址即可复制\n\n"
                msg += f"💵 实付金额：{total_amount:.2f} USDT\n"  # 显示实际需要支付的金额
                msg += "------------\n"
                msg += f"⏰ 创建时间：{beijing_created_at.strftime('%Y-%m-%d %H:%M:%S')} (北京时间)\n"
                msg += f"⌛️ 结束时间：{expire_time.strftime('%Y-%m-%d %H:%M:%S')} (北京时间)\n\n"
                msg += "⚠️ 注意事项：\n"
                msg += "1️⃣ 请在规定时间内完成付款\n"
                msg += "2️⃣ 必须使用 TRC20 网络转账\n"
                msg += "3️⃣ 转账金额必须完全一致\n"
                msg += "4️⃣ 点击地址自动复制"
                
                self.bot.send_message(
                    chat_id, 
                    msg, 
                    reply_markup=keyboard,
                    parse_mode='Markdown'
                )
                
            except Exception as e:
                logger.info(f"[Bot] 创建充值订单出错: {str(e)}")
                if hasattr(e, '__traceback__'):
                    import traceback
                    logger.info(traceback.format_exc())
                self.bot.send_message(chat_id, "抱歉，创建充值订单失败，请稍后重试")
    
    def handle_check_recharge(self, call):
        """处理充值支付完成回调"""
        try:
            user_id = str(call.from_user.id)
            current_time = time.time()
            
            # 检查用户是否在10秒内重复点击
            if user_id in self._last_check_time:
                time_diff = current_time - self._last_check_time[user_id]
                if time_diff < 30:  # 30秒内不允许重复点击
                    remaining_time = round(30 - time_diff)
                    self.bot.answer_callback_query(
                        call.id,
                        f"请等待 {remaining_time} 秒后再次检查支付状态",
                        show_alert=True
                    )
                    return
            
            # 更新最后点击时间
            self._last_check_time[user_id] = current_time
            
            order_id = call.data.split("_")[2]
            with self.app.app_context():
                order = Order.query.get(order_id)
                if not order:
                    self.bot.answer_callback_query(call.id, "订单不存在")
                    return
                
                if order.user_id != str(call.from_user.id):
                    self.bot.answer_callback_query(call.id, "这不是您的订单")
                    return
                
                # 检查USDT支付是否到账
                from .address_pay import listen_for_transactions
                payment_received = listen_for_transactions(
                    address=order.payment_address,
                    amount=order.total_amount
                )

                logger.info(f"[Bot] 检查USDT支付是否到账: {payment_received}")
                logger.info(f"[Bot] 订单: {order}")

                if not payment_received:
                    self.bot.answer_callback_query(
                        call.id,
                        "未检测到支付到账，请确认支付后再试",
                        show_alert=True
                    )
                    return
                
                if payment_received:
                    # 更新订单状态
                    order.status = 'completed'
                    order.payment_time = datetime.utcnow()
                    
                    # 增加用户余额
                    user = User.query.filter_by(
                        telegram_id=str(order.user_id),
                        bot_username=self.config.bot_username
                    ).first()

                    if user:
                        user.balance += order.total_amount
                        
                        # 添加余额变动记录
                        balance_log = BalanceLog(
                            username=user.username,
                            telegram_id=user.telegram_id,
                            bot_username=self.config.bot_username,
                            type='increase',
                            amount=order.total_amount,
                            balance=user.balance,
                            description=f'USDT充值: {order.total_amount} USDT'
                        )
                        db.session.add(balance_log)
                    
                    db.session.commit()
                    
                    # 发送成功消息
                    msg = f"✅ 充值成功！\n\n"
                    msg += f"订单号：{order.id}\n"
                    msg += f"充值金额：{order.total_amount:.2f} USDT\n"
                    msg += f"当前余额：{user.balance:.2f} USDT\n"
                    
                    self.bot.edit_message_text(
                        msg,
                        call.message.chat.id,
                        call.message.message_id
                    )
                else:
                    self.bot.answer_callback_query(
                        call.id,
                        "未检测到支付到账，请确认支付后再试",
                        show_alert=True
                    )
                
        except Exception as e:
            logger.info(f"[Bot] 检查充值支付状态出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "检查支付状态时出现错误")
    
    def handle_cancel_recharge(self, call):
        """处理取消充值回调"""
        try:
            order_id = call.data.split("_")[2]
            logger.info(f"[Bot] 尝试取消充值订单: {order_id}")
            
            with self.app.app_context():
                order = Order.query.get(order_id)
                if not order:
                    logger.info(f"[Bot] 订单不存在: {order_id}")
                    self.bot.answer_callback_query(call.id, "订单不存在")
                    return
                
                if order.user_id != str(call.from_user.id):
                    self.bot.answer_callback_query(call.id, "这不是您的订单")
                    return
                
                if order.status != 'pending':
                    self.bot.answer_callback_query(call.id, "订单状态已改变，无法取消")
                    return
                
                # 取消订单
                order.status = 'cancelled'
                db.session.commit()
                logger.info(f"[Bot] 充值订单已取消: {order_id}")
                
                # 删除订单消息
                self.bot.delete_message(
                    call.message.chat.id,
                    call.message.message_id
                )
                
                self.bot.answer_callback_query(call.id, "充值已取消")
                
        except Exception as e:
            logger.info(f"[Bot] 取消充值出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "取消充值时出现错误") 