#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import hashlib
import json
import requests
import time
from datetime import datetime
from logging import getLogger

logger = getLogger(__name__)

def generate_sign(data: dict, key: str) -> str:
    """
    按照福利来的签名算法生成签名
    :param data: 参与签名的参数字典
    :param key: 商户密钥
    :return: md5签名字符串
    """
    # 过滤掉 sign 字段和空字符串字段
    sign_map = {k: v for k, v in data.items() if k != 'sign' and not (isinstance(v, str) and v == '')}
    # 按字母顺序排序
    keys = sorted(sign_map.keys())
    # 拼接签名字符串
    sign_str = '&'.join(f"{k}={sign_map[k]}" for k in keys)
    sign_str += f"&key={key}"
    # 生成md5
    md5_hash = hashlib.md5(sign_str.encode('utf-8')).hexdigest()
    return md5_hash

def get_paylink(
    app_id: str,
    biz_order_id: str,
    amount: str,
    desc: str,
    return_url: str,
    coin: str,
    key: str,
    api_url: str = "https://aliyun.xg805.com/api/gate/pub/paylink"
) -> dict:
    """
    获取福利来的支付链接
    :param app_id: 商户app_id
    :param biz_order_id: 商户订单号
    :param amount: 支付金额（字符串，2位小数）
    :param desc: 购买描述
    :param return_url: 支付完成后跳转地址
    :param coin: 支付币种
    :param key: 商户密钥
    :param api_url: 支付链接API地址
    :return: 返回API响应的json
    """
    try:
        payload = {
            "app_id": app_id,
            "biz_order_id": biz_order_id,
            "amount": amount,
            "desc": desc,
            "return_url": return_url,
            "coin": coin
        }
        payload["sign"] = generate_sign(payload, key)
        headers = {"Content-Type": "application/json"}
        
        logger.info(f"[FLL] 发送请求到: {api_url}")
        logger.info(f"[FLL] 请求数据: {payload}")
        
        resp = requests.post(api_url, data=json.dumps(payload), headers=headers, timeout=10)
        resp.raise_for_status()
        result = resp.json()
        
        logger.info(f"[FLL] API响应: {result}")
        return result
        
    except Exception as e:
        logger.error(f"[FLL] 请求异常: {str(e)}")
        return {"error": "RequestException", "message": str(e)}

def create_payment_direct(user_id, order_id, amount, coin, app_id, key, description=None):
    """
    直接创建福利来支付
    
    Args:
        user_id: 用户ID
        amount: 支付金额
        coin: 币种 (USDT, TRX)
        app_id: 商户app_id
        order_id: 商户订单号
        key: 商户密钥
        description: 支付描述 (可选)
    
    Returns:
        支付结果字典
    """
    logger.info(f"[FLL] === 正在创建福利来支付 ===")
    logger.info(f"[FLL] 用户ID: {user_id}")
    logger.info(f"[FLL] 金额: {amount} {coin}")
    logger.info(f"[FLL] 商户ID: {app_id}")
    logger.info(f"[FLL] 描述: {description or '无'}")
    
    try:
        # 生成订单号
        biz_order_id = order_id
        
        # 格式化金额为字符串，保留2位小数
        amount_str = f"{float(amount):.2f}"
        
        # 设置返回URL
        return_url = "https://t.me/your_bot_username"  # 可以替换为实际的机器人链接
        
        # 创建支付
        result = get_paylink(
            app_id=app_id,
            biz_order_id=biz_order_id,
            amount=amount_str,
            desc=description or f"用户{user_id}的支付",
            return_url=return_url,
            coin=coin,
            key=key
        )
        
        if result.get("code") == 20000 and "data" in result:
            payment_url = result["data"].get("pay_url")
            if payment_url:
                logger.info(f"[FLL] ✅ 支付创建成功!")
                logger.info(f"[FLL] 订单号: {result['data'].get('order_id', biz_order_id)}")
                logger.info(f"[FLL] 支付链接: {payment_url}")
                
                return {
                    'success': True,
                    'order_id': result['data'].get('order_id', biz_order_id),
                    'payment_url': payment_url,
                    'message': '支付创建成功'
                }
            else:
                logger.error(f"[FLL] ❌ 支付链接为空")
                return {
                    'success': False,
                    'error': 'EmptyPaymentUrl',
                    'message': '支付链接为空'
                }
        else:
            error_msg = result.get("msg", "未知错误")
            logger.error(f"[FLL] ❌ 支付创建失败: {error_msg}")
            return {
                'success': False,
                'error': result.get("code", "Unknown"),
                'message': error_msg
            }
            
    except Exception as e:
        logger.error(f"[FLL] 创建支付异常: {str(e)}")
        return {
            'success': False,
            'error': 'Exception',
            'message': str(e)
        }
