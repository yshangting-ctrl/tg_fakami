from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton, InlineQueryResultArticle, InputTextMessageContent
from models.config import BotConfig
from models.user import User
from models.balance_log import BalanceLog
from models.product import Product
from models.advertisement import Advertisement
from extensions import db
from logging import getLogger
from datetime import datetime
logger = getLogger(__name__)

def create_main_keyboard(bot_username=None, user_name=None):
    """创建主键盘
    Args:
        bot_username: 机器人用户名
        user_id: 用户ID,用于判断是否是管理员
    """
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row(
        KeyboardButton("📁 分类列表"),
        KeyboardButton("🛍 商品列表")
    )
    keyboard.row(
        KeyboardButton("📋 订单列表"),
        KeyboardButton("👤 个人中心")
    )
    keyboard.row(
        KeyboardButton("💰 余额充值"),
        KeyboardButton("📞 联系客服")
    )
    
    if bot_username:
        bot_config = BotConfig.query.filter_by(bot_username=bot_username).first()
        if bot_config:
            # 检查是否是管理员
            if user_name:
                # 移除可能的@前缀再比较
                clean_username = str(user_name).lstrip('@')
                admin_usernames = [name.lstrip('@') for name in bot_config.admin_usernames.split(',')]
                if clean_username in admin_usernames:
                    # 管理员 - 显示机器配置和克隆按钮
                    if bot_config.allow_clone:
                        keyboard.row(KeyboardButton("⚙️ 机器配置"), KeyboardButton("🔄 免費克隆"))
                    else:
                        keyboard.row(KeyboardButton("⚙️ 机器配置"))
                elif bot_config.allow_clone:
                    # 普通用户 - 如果允许克隆则显示克隆按钮
                    keyboard.row(KeyboardButton("🔄 免費克隆"))
            elif bot_config.allow_clone:
                # 未登录用户 - 如果允许克隆则显示克隆按钮
                keyboard.row(KeyboardButton("🔄 免費克隆"))
    
    return keyboard

class BaseHandler:
    """基础处理器类"""
    def __init__(self, bot_instance):
        self.bot = bot_instance.bot
        self.config = bot_instance.config
        self.app = bot_instance.app

    def calculate_final_price(self, base_price):
        """计算最终价格(包含返佣)
        Args:
            base_price: 基础价格
        Returns:
            float: 最终价格
        """
        with self.app.app_context():
            try:
                # 每次重新从数据库获取当前机器人配置
                current_bot = BotConfig.query.filter_by(
                    bot_username=self.config.bot_username
                ).first()
                
                if not current_bot:
                    logger.info(f"[Bot] 未找到机器人配置: {self.config.bot_username}")
                    return base_price

                final_price = base_price
                commission_chain = []

                # 获取完整的返佣链
                while current_bot:
                    # 记录佣金信息
                    commission_chain.append({
                        'bot': current_bot.bot_username,
                        'rate': current_bot.commission_rate,
                        'parent': current_bot.parent_bot_username
                    })
                    
                    # 应用当前机器人的返佣比例
                    final_price = final_price * (1 + current_bot.commission_rate / 100)
                    
                    # 获取上级机器人(每次重新查询以获取最新配置)
                    if current_bot.parent_bot_username:
                        current_bot = BotConfig.query.filter_by(
                            bot_username=current_bot.parent_bot_username
                        ).first()
                        if not current_bot:
                            logger.info(f"[Bot] 未找到上级机器人配置: {current_bot.parent_bot_username}")
                            break
                    else:
                        break

                return round(final_price, 2)  # 保留两位小数
                
            except Exception as e:
                logger.info(f"[Bot] 计算最终价格出错: {str(e)}")
                return base_price  # 出错时返回基础价格

    def process_commission(self, order):
        """处理订单分红
        Args:
            order: 订单对象
        """
        import time
        max_retries = 3  # 最大重试次数
        
        with self.app.app_context():
            for attempt in range(max_retries):
                try:
                    current_bot = self.config
                    base_price = order.unit_price
                    quantity = order.quantity if hasattr(order, 'quantity') and order.quantity else 1  # 默认1

                    # 获取完整的返佣链
                    while current_bot:
                        # 计算当前层级的返佣金额（要乘以购买数量）
                        commission_rate = current_bot.commission_rate / 100
                        commission_amount = round(base_price * quantity * commission_rate, 2)  # 保留2位小数

                        if commission_amount > 0:
                            # 查找当前机器人的管理员用户
                            admin_username = current_bot.admin_usernames.split(',')[0]  # 取第一个管理员
                            admin_user = User.query.filter_by(
                                username=admin_username.strip('@'),
                                bot_username=current_bot.bot_username
                            ).first()
                            
                            if admin_user:
                                # 增加管理员余额
                                admin_user.balance += commission_amount
                                
                                # 记录余额变动
                                balance_log = BalanceLog(
                                    username=admin_user.username,
                                    telegram_id=admin_user.telegram_id,
                                    bot_username=current_bot.bot_username,
                                    type='increase',
                                    amount=commission_amount,
                                    balance=admin_user.balance,
                                    description=f'订单分红: {order.id}, 返佣比例: {current_bot.commission_rate}%, 数量: {quantity}'
                                )
                                db.session.add(balance_log)
                        
                        # 获取上级机器人
                        if current_bot.parent_bot_username:
                            current_bot = BotConfig.query.filter_by(
                                bot_username=current_bot.parent_bot_username
                            ).first()
                        else:
                            break

                    db.session.commit()
                    return True
                
                except Exception as e:
                    if 'database is locked' in str(e) and attempt < max_retries - 1:
                        logger.info(f"[Bot] 数据库锁定,等待重试 (尝试 {attempt + 1}/{max_retries})")
                        db.session.rollback()
                        time.sleep(0.5 * (attempt + 1))  # 递增延迟
                        continue
                    logger.error(f"[Bot] 处理订单分红出错: {str(e)}")
                    db.session.rollback()
                    return False

    def is_admin(self, user_name):
        """检查用户是否是管理员
        Args:
            user_name: 用户名
        Returns:
            bool: 是否是管理员
        """
        if not self.config or not self.config.admin_usernames:
            return False
            
        # 移除可能的@前缀再比较
        clean_username = str(user_name).lstrip('@')
        admin_usernames = [name.lstrip('@') for name in self.config.admin_usernames.split(',')]
        return clean_username in admin_usernames

    def handle_confirm_transfer(self, call):
        """处理确认转账回调"""
        try:
            # 解析回调数据: confirm_transfer_{amount}_{user_id}
            parts = call.data.split('_')
            if len(parts) >= 4:
                amount = float(parts[2])
                user_id = parts[3]
                
                # 记录转账确认
                logger.info(f"[Bot] 用户 {call.from_user.id} 确认转账 {amount} USDT 给用户 {user_id}")
                
                # 在数据库上下文中处理转账确认
                sender = None
                with self.app.app_context():
                    try:
                        # 查找发送方用户
                        sender = User.query.filter_by(
                            telegram_id=str(call.from_user.id),
                            bot_username=self.config.bot_username
                        ).first()
                        
                        if not sender:
                            # 如果用户不存在，创建新用户
                            sender = User(
                                username=call.from_user.username or str(call.from_user.id),
                                telegram_id=str(call.from_user.id),
                                bot_username=self.config.bot_username,
                                balance=0,
                                created_at=datetime.now()
                            )
                            db.session.add(sender)
                            logger.info(f"[Bot] 为新用户 {call.from_user.id} 创建账户")
                        
                        # 记录转账确认日志
                        balance_log = BalanceLog(
                            username=sender.username,
                            telegram_id=sender.telegram_id,
                            bot_username=self.config.bot_username,
                            type='decrease',
                            amount=amount,
                            balance=sender.balance,
                            description=f'转账确认: 转账给用户 {user_id}, 金额: {amount} USDT'
                        )
                        db.session.add(balance_log)
                        
                        # 提交数据库更改
                        db.session.commit()
                        logger.info(f"[Bot] 转账确认成功，用户 {call.from_user.id} 转账记录已保存")
                        
                    except Exception as db_error:
                        db.session.rollback()
                        logger.error(f"[Bot] 数据库操作失败: {db_error}")
                        self.bot.answer_callback_query(call.id, "转账确认失败，请稍后重试")
                        return
                
                # 发送确认消息
                msg = f"✅ 转账确认成功！\n\n💰 金额: {amount} USDT\n👤 接收方: {user_id}\n📅 时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n📝 转账记录已保存"
                
                # 检查是否是内联查询回调
                if call.message:
                    # 普通消息回调 - 更新消息
                    keyboard = InlineKeyboardMarkup()
                    keyboard.add(
                        InlineKeyboardButton(
                            text="✅ 已完成",
                            callback_data="transfer_completed"
                        )
                    )
                    
                    self.bot.edit_message_text(
                        chat_id=call.message.chat.id,
                        message_id=call.message.message_id,
                        text=msg,
                        reply_markup=keyboard
                    )
                else:
                    # 内联查询回调 - 发送新消息
                    keyboard = InlineKeyboardMarkup()
                    keyboard.add(
                        InlineKeyboardButton(
                            text="✅ 已完成",
                            callback_data="transfer_completed"
                        )
                    )
                    
                    # 发送新消息到用户
                    self.bot.send_message(
                        chat_id=call.from_user.id,
                        text=msg,
                        reply_markup=keyboard
                    )
                
                # 回答回调查询
                self.bot.answer_callback_query(call.id, "转账已确认")
            else:
                self.bot.answer_callback_query(call.id, "回调数据格式错误")
                
        except Exception as e:
            logger.error(f"[Bot] 处理确认转账回调出错: {e}")
            self.bot.answer_callback_query(call.id, "处理转账确认时出错")

    def handle_receive_transfer(self, call):
        """处理领取转账回调"""
        try:
            # 解析回调数据: receive_transfer_{amount}_{user_id}
            parts = call.data.split('_')
            if len(parts) >= 4:
                amount = float(parts[2])
                user_id = parts[3]
                
                # 记录转账领取
                logger.info(f"[Bot] 用户 {call.from_user.id} 领取转账 {amount} USDT 来自用户 {user_id}")
                
                # 在数据库上下文中处理余额增加
                receiver = None
                with self.app.app_context():
                    try:
                        # 查找领取用户
                        receiver = User.query.filter_by(
                            telegram_id=str(call.from_user.id),
                            bot_username=self.config.bot_username
                        ).first()
                        
                        if not receiver:
                            # 如果用户不存在，创建新用户
                            receiver = User(
                                username=call.from_user.username or str(call.from_user.id),
                                telegram_id=str(call.from_user.id),
                                bot_username=self.config.bot_username,
                                balance=amount,
                                created_at=datetime.now()
                            )
                            db.session.add(receiver)
                            logger.info(f"[Bot] 为新用户 {call.from_user.id} 创建账户，初始余额: {amount} USDT")
                        else:
                            # 增加用户余额
                            receiver.balance += amount
                            logger.info(f"[Bot] 用户 {call.from_user.id} 余额从 {receiver.balance - amount} 增加到 {receiver.balance} USDT")
                        
                        # 记录余额变动日志
                        balance_log = BalanceLog(
                            username=receiver.username,
                            telegram_id=receiver.telegram_id,
                            bot_username=self.config.bot_username,
                            type='increase',
                            amount=amount,
                            balance=receiver.balance,
                            description=f'转账领取: 来自用户 {user_id}, 金额: {amount} USDT'
                        )
                        db.session.add(balance_log)
                        
                        # 提交数据库更改
                        db.session.commit()
                        logger.info(f"[Bot] 转账领取成功，用户 {call.from_user.id} 余额已更新")

                        # 构建消息文本和按钮
                        fstext = f'''
<a href="tg://user?id={call.from_user.id}">{call.from_user.first_name}</a> 已领取 <b>{amount}</b> USDT
'''
                        url = f"https://t.me/{self.config.bot_username.replace('@','')}?start={call.from_user.id}"
                        keyboard = InlineKeyboardMarkup()
                        keyboard.add(
                            InlineKeyboardButton(
                                text=f"{self.config.bot_username}",
                                url=url
                            )
                        )

                        # 由于是内联查询,使用answer_callback_query和edit_message_text_inline
                        if call.inline_message_id:
                            try:
                                self.bot.edit_message_text(
                                    text=fstext,
                                    inline_message_id=call.inline_message_id,
                                    parse_mode='HTML',
                                    reply_markup=keyboard
                                )
                            except Exception as e:
                                logger.error(f"编辑内联消息失败: {e}")
                                self.bot.answer_callback_query(
                                    callback_query_id=call.id,
                                    text="🎉 收款成功！资金已到账",
                                    show_alert=True
                                )
                        
                    except Exception as db_error:
                        db.session.rollback()
                        logger.error(f"[Bot] 数据库操作失败: {db_error}")
                        self.bot.answer_callback_query(call.id, "转账领取失败，请稍后重试")
                        return
                
        except Exception as e:
            logger.error(f"[Bot] 处理领取转账回调出错: {e}")
            self.bot.answer_callback_query(call.id, "处理转账领取时出错")

    def handle_transfer_completed(self, call):
        """处理转账完成回调"""
        try:
            # 发送转账完成消息
            msg = "✅ 转账已完成！\n\n感谢您的使用！"
            
            # 检查是否是内联查询回调
            if call.message:
                # 普通消息回调 - 更新消息
                self.bot.edit_message_text(
                    chat_id=call.message.chat.id,
                    message_id=call.message.message_id,
                    text=msg
                )
            else:
                # 内联查询回调 - 发送新消息
                self.bot.send_message(
                    chat_id=call.from_user.id,
                    text=msg
                )
            
            # 回答回调查询
            self.bot.answer_callback_query(call.id, "转账已完成")
            
        except Exception as e:
            logger.error(f"处理转账完成回调出错: {e}")
            self.bot.answer_callback_query(call.id, "处理转账完成时出错")

    def handle_transfer_received(self, call):
        """处理转账领取完成回调"""
        try:
            # 发送转账领取完成消息
            msg = "🎁 转账已领取完成！\n\n感谢您的使用！"
            
            # 检查是否是内联查询回调
            if call.message:
                # 普通消息回调 - 更新消息
                self.bot.edit_message_text(
                    chat_id=call.message.chat.id,
                    message_id=call.message.message_id,
                    text=msg
                )
            else:
                # 内联查询回调 - 发送新消息
                self.bot.send_message(
                    chat_id=call.from_user.id,
                    text=msg
                )
            
            # 回答回调查询
            self.bot.answer_callback_query(call.id, "转账已领取")
            
        except Exception as e:
            logger.error(f"处理转账领取完成回调出错: {e}")
            self.bot.answer_callback_query(call.id, "处理转账领取完成时出错")

class CommandHandlers(BaseHandler):
    """命令处理器类"""
    def __init__(self, bot_instance):
        super().__init__(bot_instance)
        # 初始化各个功能处理器
        from .category_handler import CategoryHandler
        from .product_handler import ProductHandler
        from .order_handler import OrderHandler
        from .user_handler import UserHandler
        from .payment_handler import PaymentHandler
        from .support_handler import SupportHandler
        from .clone_handler import CloneHandler
        from .config_handler import ConfigHandler
        
        self.category_handler = CategoryHandler(bot_instance)
        self.product_handler = ProductHandler(bot_instance)
        self.order_handler = OrderHandler(bot_instance)
        self.user_handler = UserHandler(bot_instance)
        self.payment_handler = PaymentHandler(bot_instance)
        self.support_handler = SupportHandler(bot_instance)
        self.clone_handler = CloneHandler(bot_instance)
        self.config_handler = ConfigHandler(bot_instance)

    def handle_quick_action(self, call):
        """处理快捷操作按钮回调"""
        action = call.data.split('_')[1]
        if action == "products":
            self.product_handler.show_products(call.message)
        elif action == "profile":
            self.user_handler.show_profile(call.message)
        elif action == "recharge":
            self.payment_handler.show_recharge(call.message)
        elif action == "support":
            self.support_handler.contact_support(call.message)
        elif action == "orders":
            self.order_handler.show_orders(call.message)
        
    
    def setup_handlers(self):
        """设置所有命令处理器"""
        # 设置机器人命令菜单
        from telebot.types import InlineQueryResultArticle, InputTextMessageContent, BotCommand
        commands = [
            BotCommand('start', '开始使用机器人'),
            BotCommand('products', '🛍 商品列表'),
            BotCommand('categories', '📁 分类列表'), 
            BotCommand('orders', '📋 订单列表'),
            BotCommand('profile', '👤 个人中心'),
            BotCommand('recharge', '💰 余额充值'),
            BotCommand('support', '📞 联系客服')
        ]
        self.bot.set_my_commands(commands)
        
        # Start命令处理
        @self.bot.message_handler(commands=['start'])
        def start(message):
            with self.app.app_context():
                try:
                    logger.info(f"[Bot] 用户进入: {message.from_user.to_dict()}")
                    # 创建用户
                    user = self.user_handler.ensure_user(message)
                    if not user:
                        return
                    
                    # 检查是否有start参数
                    args = message.text.split()
                    if len(args) > 1:
                        param = args[1]
                        if param.startswith('buy_'):
                            print(param,'fwefwfwe')
                            self.product_handler.handle_buy_command(message, param)
                            return
                        elif param.startswith('pay_'):
                            self.payment_handler.handle_pay_command(message, param)
                            return
                        elif param.startswith('fx_'):
                            print("分享来的")
                            print(message)
                            self.product_handler.show_products(message, param.split('_')[1])
                            return
                            
                    
                    # 发送欢迎消息
                    welcome_msg = f"欢迎使用 {self.config.bot_username}！"
                    if self.config.announcement and self.config.announcement.strip():
                        welcome_msg += f"\n\n{self.config.announcement}"
                    
                    # 创建快捷操作内联键盘
                    quick_keyboard = InlineKeyboardMarkup()
                    quick_keyboard.row(
                        InlineKeyboardButton("🛍 商品列表", callback_data="quick_products"),
                        InlineKeyboardButton("👤 个人中心", callback_data="quick_profile")
                    )
                    quick_keyboard.row(
                        InlineKeyboardButton("💰 余额充值", callback_data="quick_recharge"),
                        InlineKeyboardButton("📞 联系客服", callback_data="quick_support")
                    )
                    quick_keyboard.row(
                        InlineKeyboardButton("📋 订单列表", callback_data="quick_orders")
                    )
                    
                    # 获取有效的广告
                    now = datetime.now()
                    ads = Advertisement.query.filter(
                        Advertisement.is_active == True,
                        Advertisement.expire_at > now
                    ).all()
                    
                    # 添加分隔线和广告按钮
                    if ads:
                        quick_keyboard.add(InlineKeyboardButton("----广告区域----", callback_data="divider"))
                        for ad in ads:
                            quick_keyboard.add(InlineKeyboardButton(
                                f"📢 {ad.description}",
                                url=f"https://t.me/{ad.username}"
                            ))
                    
                    # 发送底部键盘消息
                    self.bot.reply_to(
                        message, 
                        text="请选择底部键盘", 
                        reply_markup=create_main_keyboard(
                            self.config.bot_username,
                            message.from_user.username
                        )
                    )
                    
                    # 发送带快捷键盘的欢迎消息
                    self.bot.reply_to(
                        message, 
                        text=welcome_msg, 
                        reply_markup=quick_keyboard
                    )
                except Exception as e:
                    logger.info(f"[Bot] 处理start命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理您的请求时出现错误，请稍后重试。")
        
        # 商品列表命令
        @self.bot.message_handler(commands=['products'])
        def products(message):
            with self.app.app_context():
                try:
                    self.product_handler.show_products(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理商品列表命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 分类列表命令
        @self.bot.message_handler(commands=['categories'])
        def categories(message):
            with self.app.app_context():
                try:
                    self.category_handler.show_categories(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理分类列表命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 订单列表命令
        @self.bot.message_handler(commands=['orders'])
        def orders(message):
            with self.app.app_context():
                try:
                    self.order_handler.show_orders(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理订单列表命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 个人中心命令
        @self.bot.message_handler(commands=['profile'])
        def profile(message):
            with self.app.app_context():
                try:
                    self.user_handler.show_profile(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理个人中心命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 余额充值命令
        @self.bot.message_handler(commands=['recharge'])
        def recharge(message):
            with self.app.app_context():
                try:
                    self.payment_handler.show_recharge(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理余额充值命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 联系客服命令
        @self.bot.message_handler(commands=['support'])
        def support(message):
            with self.app.app_context():
                try:
                    self.support_handler.contact_support(message)
                except Exception as e:
                    logger.error(f"[Bot] 处理联系客服命令出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理请求时出现错误，请稍后重试")

        # 服务器状态命令
        @self.bot.message_handler(commands=['server_status'])
        def server_status(message):
            import psutil
            import os
            try:
                cpu_percent = psutil.cpu_percent(interval=1)
                mem = psutil.virtual_memory()
                mem_percent = mem.percent
                disk = psutil.disk_usage('/')
                disk_percent = disk.percent
                cpu_count = psutil.cpu_count()
                
            except Exception as e:
                cpu_percent = mem_percent = disk_percent = cpu_count = ip = "获取失败"
                print(f"获取状态失败: {str(e)}")

            msg = (
                f"运行状态:\n"
                f"------------------\n"
                f"IP地址: <b>{self.config.backend_url}</b>\n"
                f"CPU核心数: <b>{cpu_count}</b>\n"
                f"CPU使用率: <b>{cpu_percent}%</b>\n"
                f"内存使用率: <b>{mem_percent}%</b>\n"
                f"磁盘使用率: <b>{disk_percent}%</b>\n"
            )

            self.bot.reply_to(message, msg, parse_mode="HTML")

        # 添加回调查询处理器
        @self.bot.callback_query_handler(func=lambda call: True)
        def handle_callback_query(call):
            with self.app.app_context():
                try:
                    logger.info(f"[Bot] 收到按钮回调: {call.data}")
                    if call.data.startswith("cat_"):
                        self.category_handler.handle_category_callback(call)
                    elif call.data.startswith("prod_"):
                        self.product_handler.handle_product_callback(call)
                    elif call.data.startswith("buy_"):
                        self.product_handler.handle_buy_callback(call)
                    elif call.data.startswith("pay_"):
                        if (call.data.startswith("pay_balance_") 
                            or call.data.startswith("pay_usdt_") 
                            or call.data.startswith("pay_weixin_") 
                            or call.data.startswith("pay_zfb_") 
                            or call.data.startswith("pay_fll_") 
                            or call.data.startswith("pay_okpay_")):
                            self.product_handler.handle_payment_callback(call)
                        else:
                            self.payment_handler.handle_payment_callback(call)
                    elif call.data.startswith("qty_"):
                        self.product_handler.handle_quantity_callback(call)
                    elif call.data.startswith("check_pay_"):
                        self.product_handler.handle_check_payment(call)
                    elif call.data.startswith("cancel_pay_"):
                        self.product_handler.handle_cancel_payment(call)
                    elif call.data.startswith("back_to_pay_"):
                        self.product_handler.handle_back_to_pay(call)
                    elif call.data.startswith("order_page_"):
                        self.order_handler.handle_order_callback(call)
                    elif call.data.startswith("recharge_"):
                        self.payment_handler.handle_payment_callback(call)
                    elif call.data.startswith("check_recharge_"):
                        self.payment_handler.handle_check_recharge(call)
                    elif call.data.startswith("cancel_recharge_"):
                        self.payment_handler.handle_cancel_recharge(call)
                    elif call.data == "withdraw":
                        self.user_handler.handle_withdraw_callback(call)
                    elif call.data == "back_to_profile":
                        self.user_handler.show_profile(call.message,call=call)
                    elif call.data.startswith("config_") or call.data == "back_to_config":
                        self.config_handler.handle_callback(call)
                    elif call.data == "edit_announcement":
                        self.config_handler.actions.handle_announcement_edit(call)
                    elif call.data.startswith("commission_"):
                        if call.data in ["commission_plus", "commission_minus"]:
                            self.config_handler.actions.handle_commission_adjust(call, call.data.split('_')[1])
                        elif call.data == "commission_input":
                            self.config_handler.actions.handle_commission_input(call)
                    elif call.data == "admin_add":
                        self.config_handler.actions.handle_admin_add(call)
                    elif call.data.startswith("admin_del_"):
                        username = call.data.split('_')[2]
                        self.config_handler.actions.handle_admin_delete(call, username)
                    elif call.data == "clone_toggle":
                        self.config_handler.actions.handle_clone_toggle(call)
                    elif call.data == "status_toggle":
                        self.config_handler.actions.handle_status_toggle(call)
                    elif call.data == "basic_recharge":
                        self.config_handler.actions.handle_basic_recharge(call)
                    elif call.data == "basic_epay":
                        self.config_handler.actions.handle_basic_epay(call)
                    elif call.data == "stats_history":
                        self.config_handler.actions.handle_stats_history(call)
                    elif call.data.startswith("quick_"):
                        self.handle_quick_action(call)
                    elif call.data.startswith("receive_transfer_"):
                        self.handle_receive_transfer(call)
                    elif call.data == "transfer_completed":
                        self.handle_transfer_completed(call)
                    elif call.data == "transfer_received":
                        self.handle_transfer_received(call)
                    else:
                        logger.info(f"[Bot] 未处理的回调类型base: {call.data}")
                        # 只有在未处理的回调类型时才发送默认回复
                        self.bot.answer_callback_query(call.id)
                    
                except Exception as e:
                    logger.info(f"[Bot] 处理回调查询出错: {str(e)}")
                    logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
                    self.bot.answer_callback_query(call.id, "处理请求时出错")

        # 处理文本消息
        @self.bot.message_handler(func=lambda message: True)
        def handle_text(message):
            with self.app.app_context():
                try:
                    # 检查用户状态
                    user_id = str(message.from_user.id)
                    # 自定义的余额充值
                    print(self.payment_handler._user_states)
                    print(self.user_handler._user_states)
                    print(user_id)
                    if user_id in self.payment_handler._user_states:
                        state = self.payment_handler._user_states[user_id]
                        print(state)
                        if state['state'] == 'waiting_recharge_amount':
                            self.payment_handler.handle_custom_amount(message)
                            return
                    elif user_id in self.user_handler._user_states:
                        state = self.user_handler._user_states[user_id]
                        if state['state'] == 'waiting_withdraw_amount':
                            self.user_handler.handle_withdraw_amount(message)
                            return
                        elif state['state'] == 'waiting_withdraw_address':
                            self.user_handler.handle_withdraw_address(message)
                            return
                    elif user_id in self.config_handler.actions._user_states:
                        self.config_handler.handle_text(message)
                        return
                    elif user_id in self.clone_handler._user_states:
                        self.clone_handler.handle_text(message)
                        return

                    if message.text == "📁 分类列表":
                        self.category_handler.show_categories(message)
                    elif message.text == "🛍 商品列表":
                        self.product_handler.show_products(message)
                    elif message.text == "📋 订单列表":
                        self.order_handler.show_orders(message)
                    elif message.text == "👤 个人中心":
                        self.user_handler.show_profile(message)
                    elif message.text == "💰 余额充值":
                        self.payment_handler.show_recharge(message)
                    elif message.text == "📞 联系客服":
                        self.support_handler.contact_support(message)
                    elif message.text == "🔄 免費克隆":
                        self.clone_handler.show_clone_info(message)
                    elif message.text == "⚙️ 机器配置":
                        self.config_handler.show_config(message)
                    elif message.text.isdigit():  # 处理数量输入
                        self.product_handler.handle_quantity_input(message)
                except Exception as e:
                    logger.info(f"[Bot] 处理消息出错: {str(e)}")
                    self.bot.reply_to(message, "抱歉，处理您的请求时出现错误，请稍后重试。") 

        @self.bot.inline_handler(lambda query: True)
        def handle_inline_query(inline_query):
            try:
                query = inline_query.query.strip()  # 用户输入的搜索词
                logger.info(f"[Bot] 收到内联查询: 用户ID={inline_query.from_user.id}, 查询内容='{query}'")
                results = []

                from telebot.types import InlineQueryResultArticle, InputTextMessageContent, InlineKeyboardMarkup, InlineKeyboardButton

                if not query:
                    # 如果用户还未输入关键词，返回一个提示
                    # 点击后发送数据库的start内容，并带有快捷跳转按钮
                    with self.app.app_context():
                        # 获取数据库中的start内容（假设在config.announcement或类似字段）
                        start_content = getattr(self.config, "start_content", None)
                        if not start_content:
                            # 兼容旧字段
                            start_content = getattr(self.config, "announcement", "欢迎使用本机器人！")
                        msg = start_content if start_content else "欢迎使用本机器人！"

                        # 构建底部快捷跳转按钮
                        keyboard = InlineKeyboardMarkup()
                        print(f"https://t.me/{self.config.bot_username.replace('@', '')}")
                        keyboard.add(
                            InlineKeyboardButton(
                                text="🤖 打开机器人",
                                url=f"https://t.me/{self.config.bot_username.replace('@', '')}"
                            )
                        )

                        tip_result = InlineQueryResultArticle(
                            id="tip",
                            title="请输入查询关键词",
                            input_message_content=InputTextMessageContent(
                                message_text=msg,
                                disable_web_page_preview=True,
                                parse_mode='HTML'
                            ),
                            description="在上方输入框输入商品名称或描述进行搜索",
                            reply_markup=keyboard
                        )
                        results.append(tip_result)
                else:
                    # 从商品数据库中搜索
                    with self.app.app_context():
                        # 模糊搜索商品名称和描述
                        products = Product.query.filter(
                            Product.is_active == True,
                            (Product.name.ilike(f"%{query}%")) | (Product.description.ilike(f"%{query}%"))
                        ).limit(10).all()
                        logger.info(f"[Bot] 内联查询结果数量: {len(products)}")

                        for product in products:
                            title = product.name
                            description = product.description[:50] if product.description else ""
                            # 计算包含分红的最终价格
                            final_price = self.calculate_final_price(product.price)
                            price = f"{final_price:.2f} USDT"
                            # 构建商品详情文案
                            msg = f"🛍 商品：{product.name}\n💰 价格：{price}\n\n{product.description or ''}"

                            # 构建底部快捷跳转按钮
                            keyboard = InlineKeyboardMarkup()
                            keyboard.add(
                                InlineKeyboardButton(
                                    text="🤖 立即购买",
                                    url=f"https://t.me/{self.config.bot_username.replace('@', '')}?start=fx_{product.id}"
                                )
                            )

                            result = InlineQueryResultArticle(
                                id=str(product.id),
                                title=title,
                                input_message_content=InputTextMessageContent(
                                    message_text=msg,
                                    disable_web_page_preview=True,
                                    parse_mode='HTML'
                                ),
                                description=description if description else price,
                                reply_markup=keyboard
                            )
                            results.append(result)
                            logger.info(f"[Bot] 内联查询添加商品: {title} (ID: {product.id})")

                # 从数据库查询机器人配置
                with self.app.app_context():
                    try:
                        # 查询当前机器人配置
                        bot_config = BotConfig.query.filter_by(
                            bot_username=self.config.bot_username
                        ).first()
                        
                        # 检查当前用户是否为管理员
                        admin_usernames = [username.replace('@','') for username in bot_config.admin_usernames.split(',')]
                        user_username = inline_query.from_user.username.replace('@','') if inline_query.from_user.username else ''
                        if user_username not in admin_usernames:
                            logger.info(f"非管理员用户 {user_username} 尝试发起转账")
                            return
                            
                    except Exception as e:
                        logger.error(f"查询机器人配置失败: {e}")
                        return

                # 管理员发起转账
                try:
                    amount = float(query)
                    msg = f"💰 转账 {amount} USDT\n\n"
                    msg += "点击下方按钮领取转账"
                    msg += f"\n\n发起人: {inline_query.from_user.id}"  # 记录发起人ID

                    keyboard = InlineKeyboardMarkup()
                    keyboard.add(
                        InlineKeyboardButton(
                            text="🎁 领取转账",
                            callback_data=f"receive_transfer_{amount}_{inline_query.from_user.id}"
                        )
                    )

                    result = InlineQueryResultArticle(
                        id="transfer",
                        title=f"转账 {amount} USDT",
                        input_message_content=InputTextMessageContent(
                            message_text=msg,
                            disable_web_page_preview=True,
                            parse_mode='HTML'
                        ),
                        description="点击领取转账",
                        reply_markup=keyboard
                    )
                    results.append(result)
                except ValueError:
                    logger.error("转账金额格式错误")
                    return

                # 返回搜索结果
                self.bot.answer_inline_query(inline_query.id, results, cache_time=1)
                logger.info(f"[Bot] 已返回内联查询结果，共{len(results)}条")

            except Exception as e:
                logger.error(f"处理内联查询出错: {e}")
                self.bot.answer_inline_query(inline_query.id, [])
