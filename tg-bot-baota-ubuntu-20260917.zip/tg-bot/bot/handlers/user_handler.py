from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from models.user import User
from models.withdrawal import Withdrawal
from models.balance_log import BalanceLog
from .base_handler import BaseHandler
from app import db
from datetime import datetime
from logging import getLogger
logger = getLogger(__name__)

class UserHandler(BaseHandler):
    def __init__(self, bot_instance):
        super().__init__(bot_instance)
        self._user_states = {}  # 用于存储用户状态

    def ensure_user(self, message):
        """确保用户存在，如果不存在则创建
        Args:
            message: Telegram消息对象
        Returns:
            User: 用户对象
        """
        with self.app.app_context():
            try:
                telegram_id = str(message.from_user.id)
                # 查找用户
                user = User.query.filter_by(
                    telegram_id=telegram_id,
                    bot_username=self.config.bot_username
                ).first()
                
                if not user:
                    # 创建新用户
                    try:
                        # 生成基础用户名
                        base_username = message.from_user.username or f"user_{telegram_id}"
                        username = base_username
                        logger.info(f"[Bot] 基础用户名: {username}")
                        logger.info(f"[Bot] 机器人用户名: {self.config.bot_username}")
                        logger.info(f"[Bot] Telegram用户ID: {telegram_id}")
                        counter = 1
                        while User.query.filter_by(
                            username=username,
                            bot_username=self.config.bot_username
                        ).first():
                            username = f"{base_username}_{counter}"
                            counter += 1
                        
                        user = User(
                            telegram_id=telegram_id,
                            username=username,
                            nickname=message.from_user.first_name or username,
                            bot_username=self.config.bot_username,
                            balance=0.0,
                            password_hash='default'
                        )
                        db.session.add(user)
                        db.session.commit()
                        logger.info(f"[Bot] 新用户注册成功: {user.to_dict()}")
                    except Exception as e:
                        logger.info(f"[Bot] 创建用户失败: {str(e)}")
                        db.session.rollback()
                        return None
                
                return user
                
            except Exception as e:
                logger.info(f"[Bot] 确保用户存在时出错: {str(e)}")
                return None

    def show_profile(self, message, call=None):
        """显示个人中心"""
        with self.app.app_context():
            try:
                telegram_id = ""
                try:
                    telegram_id = str(call.from_user.id)
                except:
                    telegram_id = str(message.from_user.id)
                user = User.query.filter_by(
                    telegram_id=telegram_id,
                    bot_username=self.config.bot_username
                ).first()
                if not user:
                    self.bot.reply_to(message, "用户信息不存在")
                    return
                
                # 创建个人中心键盘
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("💰 提现", callback_data="withdraw")
                )
                
                # 发送个人信息
                msg = "👤 个人中心\n\n"
                msg += f"用户ID：{user.telegram_id}\n"
                msg += f"用户名：{user.username}\n"
                msg += f"昵称：{user.nickname}\n"
                msg += f"余额：${user.balance:.2f}\n"
                msg += f"注册时间：{user.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n"
                
                if call:
                    self.bot.edit_message_text(
                        msg,
                        chat_id=call.message.chat.id,
                        message_id=call.message.message_id,
                        reply_markup=keyboard
                    )
                else:
                    self.bot.reply_to(message, msg, reply_markup=keyboard)
                
            except Exception as e:
                logger.info(f"[Bot] 显示个人中心出错: {str(e)}")
                self.bot.reply_to(message, "抱歉，获取个人信息失败，请稍后重试")

    def handle_withdraw_callback(self, call):
        """处理提现回调"""
        try:
            user_id = str(call.from_user.id)
            
            # 检查用户余额
            with self.app.app_context():
                user = User.query.filter_by(
                    telegram_id=user_id,
                    bot_username=self.config.bot_username
                ).first()
                
                if not user:
                    self.bot.answer_callback_query(call.id, "用户信息不存在")
                    return
                
                if user.balance < 5:
                    self.bot.answer_callback_query(call.id, "余额不足5 USDT，无法提现", show_alert=True)
                    return
            
            self._user_states[user_id] = {
                'state': 'waiting_withdraw_amount',
                'message_id': call.message.message_id
            }
            
            msg = "💰 申请提现\n\n"
            msg += f"当前余额: {user.balance:.2f} USDT\n"
            msg += "------------------------\n"
            msg += "提现规则:\n"
            msg += "1. 最低提现金额: 5 USDT\n"
            msg += "2. 账户余额必须大于5 USDT\n"
            msg += "3. 提现金额必须是整数\n"
            msg += "------------------------\n"
            msg += "请输入提现金额（USDT）"
            
            self.bot.edit_message_text(
                msg,
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                reply_markup=InlineKeyboardMarkup().add(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_profile")
                )
            )
            
        except Exception as e:
            logger.info(f"[Bot] 处理提现回调出错: {str(e)}")
            self.bot.answer_callback_query(call.id, "处理请求时出现错误")

    def handle_withdraw_amount(self, message):
        """处理用户输入的提现金额"""
        user_id = str(message.from_user.id)
        if user_id not in self._user_states or self._user_states[user_id]['state'] != 'waiting_withdraw_amount':
            return
        
        try:
            amount = float(message.text)
            
            # 验证提现金额
            if amount < 5:
                self.bot.reply_to(message, "❌ 提现金额必须大于等于5 USDT")
                return
                
            if amount != int(amount):
                self.bot.reply_to(message, "❌ 提现金额必须是整数")
                return
            
            # 检查用户余额
            with self.app.app_context():
                user = User.query.filter_by(
                    telegram_id=user_id,
                    bot_username=self.config.bot_username
                ).first()
                if not user:
                    self.bot.reply_to(message, "用户信息不存在")
                    return
                
                if user.balance < amount:
                    self.bot.reply_to(message, "❌ 余额不足")
                    return
                
                if user.balance < 5:
                    self.bot.reply_to(message, "❌ 账户余额必须大于5 USDT才能提现")
                    return
                
                # 更新用户状态
                self._user_states[user_id].update({
                    'state': 'waiting_withdraw_address',
                    'amount': amount
                })
                
                # 请求输入提现地址
                msg = "💰 申请提现\n\n"
                msg += f"金额：{amount:.2f} USDT\n\n"
                msg += "请输入TRC20提现地址"

                # 发送消息时需要指定 chat_id 和 text
                self.bot.send_message(
                    message.chat.id,
                    msg,
                    reply_markup=InlineKeyboardMarkup().add(
                        InlineKeyboardButton("⬅️ 返回", callback_data="back_to_profile")
                    )
                )
                
        except ValueError:
            self.bot.reply_to(message, "❌ 请输入有效的数字金额")
            del self._user_states[user_id]
        except Exception as e:
            logger.info(f"[Bot] 处理提现金额出错: {str(e)}")
            self.bot.reply_to(message, "处理提现请求时出现错误，请重试")
            del self._user_states[user_id]

    def handle_withdraw_address(self, message):
        """处理用户输入的提现地址"""
        user_id = str(message.from_user.id)
        if user_id not in self._user_states or self._user_states[user_id]['state'] != 'waiting_withdraw_address':
            return
        
        try:
            address = message.text.strip()
            if not address:
                self.bot.reply_to(message, "请输入有效的提现地址")
                return
            
            amount = self._user_states[user_id]['amount']
            
            # 再次检查用户余额
            with self.app.app_context():
                user = User.query.filter_by(
                    telegram_id=user_id,
                    bot_username=self.config.bot_username
                ).first()
                
                if not user:
                    self.bot.reply_to(message, "用户信息不存在")
                    return
                
                if user.balance < amount:
                    self.bot.reply_to(message, "❌ 余额不足")
                    return
                
                if user.balance < 5:
                    self.bot.reply_to(message, "❌ 账户余额必须大于5 USDT才能提现")
                    return
                
                # 扣除用户余额
                user.balance -= amount
                
                # 添加余额变动记录
                balance_log = BalanceLog(
                    username=user.username,
                    telegram_id=user.telegram_id,
                    bot_username=self.config.bot_username,
                    type='decrease',
                    amount=amount,
                    balance=user.balance,
                    description=f'提现申请: {amount} USDT'
                )
                db.session.add(balance_log)
                
                # 创建提现记录
                withdrawal = Withdrawal(
                    user_id=user_id,
                    bot_username=self.config.bot_username,
                    amount=amount,
                    address=address,
                    status='pending'
                )
                db.session.add(withdrawal)
                db.session.commit()
                
                # 发送确认消息
                msg = "✅ 提现申请已提交\n\n"
                msg += f"金额：{amount:.2f} USDT\n"
                msg += f"地址：{address}\n\n"
                msg += "请等待管理员审核"
                
                # 更新原消息
                self.bot.send_message(
                    message.chat.id,
                    msg
                )
                
                # 清理用户状态
                del self._user_states[user_id]
                
        except Exception as e:
            logger.info(f"[Bot] 处理提现地址出错: {str(e)}")
            self.bot.reply_to(message, "处理提现请求时出现错误，请重试") 