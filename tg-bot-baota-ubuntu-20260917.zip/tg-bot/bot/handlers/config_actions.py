from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from models.config import BotConfig
from app import db
from datetime import datetime, timedelta
from models.order import Order
import traceback
from logging import getLogger
logger = getLogger(__name__)

class ConfigActions:
    def __init__(self, handler):
        self.handler = handler
        self.bot = handler.bot
        self.config = handler.config
        self.app = handler.app
        self._user_states = {}  # 用于存储用户状态
        # 保存 bot_username 为字符串
        self.bot_username = str(handler.config.bot_username)

    def handle_announcement_edit(self, call):
        """处理公告编辑"""
        try:
            logger.info("[Bot] 开始处理公告编辑")  # 调试日志
            user_id = str(call.from_user.id)
            self._user_states[user_id] = {
                'state': 'waiting_announcement',
                'message_id': call.message.message_id
            }
            logger.info(f"[Bot] 设置用户状态: {self._user_states[user_id]}")  # 调试日志
            
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
            )
            
            msg = "📝 请直接发送新的公告内容\n\n"
            msg += "当前公告内容：\n"
            msg += f"{self.config.announcement if self.config.announcement else '暂无公告'}\n\n"
            msg += "支持以下HTML标签：\n"
            msg += "• <b>粗体</b>\n"
            msg += "• <i>斜体</i>\n"
            msg += "• <u>下划线</u>\n\n"
            msg += "取消编辑请发送: /cancel"
            
            logger.info("[Bot] 准备发送编辑提示消息")  # 调试日志
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            logger.info("[Bot] 编辑提示消息发送成功")  # 调试日志
            
        except Exception as e:
            logger.info(f"[Bot] 处理公告编辑出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")  # 添加行号信息
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")  # 添加完整堆栈
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def save_announcement(self, message):
        """保存公告内容"""
        try:
            with self.app.app_context():
                # 保存公告
                # 先查找数据库中的最新配置对象再修改
                bot_config = BotConfig.query.filter_by(bot_username=self.config.bot_username).first()
                if bot_config:
                    bot_config.announcement = message.text
                    db.session.commit()
                    self.config.announcement = message.text  # 同步内存对象
                else:
                    raise Exception("未找到机器人配置，无法保存公告")
                
                # 发送成功消息
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("✏️ 继续编辑", callback_data="edit_announcement")  # 修改这里的callback_data
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回主菜单", callback_data="back_to_config")
                )
                
                msg = """✅ 公告更新成功

💡 提示：请在克隆的机器人中执行 /start 命令以获取最新效果。

当前公告内容：
"""
                msg += self.config.announcement
                
                self.bot.reply_to(
                    message, 
                    msg,
                    reply_markup=keyboard,
                    parse_mode='HTML'
                )
                
                # 清理用户状态
                user_id = str(message.from_user.id)
                if user_id in self._user_states:
                    del self._user_states[user_id]
                
        except Exception as e:
            logger.info(f"[Bot] 保存公告出错: {str(e)}")
            self.bot.reply_to(message, "❌ 保存公告失败，请重试")

    def handle_commission_adjust(self, call, action):
        """处理返佣比例调整"""
        try:
            logger.info("[Bot] 开始处理返佣比例调整")
            logger.info(f"[Bot] 动作: {action}")
            
            with self.app.app_context():
                # 获取当前配置
                bot_username = self.config.bot_username  # 先获取用户名
                logger.info(f"[Bot] 机器人用户名: {bot_username}")
                
                # 获取最新配置
                bot_config = BotConfig.query.filter_by(bot_username=bot_username).first()
                if not bot_config:
                    logger.info("[Bot] 错误：找不到机器人配置")
                    self.bot.answer_callback_query(call.id, "错误：找不到机器人配置")
                    return
                
                current_rate = bot_config.commission_rate
                logger.info(f"[Bot] 当前返佣比例: {current_rate}%")
                
                # 调整比例（每次加减0.1%）
                if action == "minus":
                    new_rate = max(0, current_rate - 0.1)
                else:  # plus
                    new_rate = min(100, current_rate + 0.1)
                
                logger.info(f"[Bot] 新的返佣比例: {new_rate}%")
                
                # 更新比例
                bot_config.commission_rate = new_rate
                db.session.add(bot_config)  # 确保对象被跟踪
                db.session.commit()
                logger.info("[Bot] 数据库更新成功")
                
                # 重新获取最新配置
                bot_config = BotConfig.query.filter_by(bot_username=bot_username).first()
                self.config = bot_config
                logger.info(f"[Bot] 重新获取配置成功，当前比例: {bot_config.commission_rate}%")
                
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("➖", callback_data="commission_minus"),
                    InlineKeyboardButton(f"{new_rate:.1f}%", callback_data="noop"),
                    InlineKeyboardButton("➕", callback_data="commission_plus")
                )
                keyboard.row(
                    InlineKeyboardButton("✏️ 手动输入", callback_data="commission_input")
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                )
                
                msg = "💰 返佣提成设置\n\n"
                msg += f"当前比例: {new_rate:.1f}%"
                
                self.bot.edit_message_text(
                    msg,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=keyboard
                )
                logger.info("[Bot] 界面更新成功")
                
        except Exception as e:
            logger.info(f"[Bot] 调整返佣比例出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            db.session.rollback()  # 发生错误时回滚
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_clone_toggle(self, call):
        """处理克隆开关切换"""
        try:
            logger.info("[Bot] 开始处理克隆开关切换")
            
            with self.app.app_context():
                # 获取当前配置
                bot_config = BotConfig.query.filter_by(bot_username=self.config.bot_username).first()
                if not bot_config:
                    logger.info("[Bot] 错误：找不到机器人配置")
                    self.bot.answer_callback_query(call.id, "错误：找不到机器人配置")
                    return
                
                logger.info(f"[Bot] 当前状态: {bot_config.allow_clone}")
                
                # 切换状态
                bot_config.allow_clone = not bot_config.allow_clone
                logger.info(f"[Bot] 新状态: {bot_config.allow_clone}")
                
                # 提交更改
                db.session.commit()
                logger.info("[Bot] 数据库更新成功")
                
                # 更新本地配置
                self.config = bot_config
                
                # 更新界面
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton(
                        "✅ 允许克隆" if bot_config.allow_clone else "❌ 禁止克隆", 
                        callback_data="clone_toggle"
                    )
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                )
                
                msg = """🔄 克隆设置

当前状态: %s克隆

💡 提示：请在克隆的机器人中执行 /start 命令以获取最新效果。""" % ('允许' if bot_config.allow_clone else '禁止')
                
                self.bot.edit_message_text(
                    msg,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=keyboard
                )
                logger.info("[Bot] 界面更新成功")
                
                # 发送操作成功提示
                self.bot.answer_callback_query(
                    call.id,
                    f"已{'启用' if bot_config.allow_clone else '禁用'}克隆功能"
                )
                
        except Exception as e:
            logger.info(f"[Bot] 切换克隆状态出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            db.session.rollback()  # 发生错误时回滚
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_admin_add(self, call):
        """处理添加管理员"""
        try:
            user_id = str(call.from_user.id)
            self._user_states[user_id] = {
                'state': 'waiting_admin_username',
                'message_id': call.message.message_id
            }
            
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
            )
            
            msg = "👥 请发送要添加的管理员用户名\n"
            msg += "注意: 不需要包含@符号\n"
            msg += "取消操作请发送: /cancel"
            
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard
            )
            
        except Exception as e:
            logger.info(f"[Bot] 处理添加管理员出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def save_admin(self, message):
        """保存新管理员"""
        try:
            logger.info("[Bot] 开始处理添加管理员")
            logger.info(f"[Bot] 输入内容: {message.text}")
            
            with self.app.app_context():
                from models.config import BotConfig
                from extensions import db
                
                logger.info(f"[Bot] 机器人用户名: {self.bot_username}")
                
                # 重新查询配置
                bot_config = db.session.query(BotConfig).filter_by(bot_username=self.bot_username).first()
                if not bot_config:
                    logger.info("[Bot] 错误：找不到机器人配置")
                    self.bot.reply_to(message, "❌ 错误：找不到机器人配置")
                    return
                
                # 处理新管理员用户名
                new_admin = message.text.strip().lstrip('@')
                logger.info(f"[Bot] 新管理员用户名: {new_admin}")
                
                # 获取当前管理员列表
                current_admins = set(bot_config.admin_usernames.split(',')) if bot_config.admin_usernames else set()
                logger.info(f"[Bot] 当前管理员列表: {current_admins}")
                
                if new_admin in current_admins:
                    logger.info(f"[Bot] 用户已是管理员: {new_admin}")
                    self.bot.reply_to(message, "❌ 该用户已是管理员")
                    return
                
                # 添加新管理员
                current_admins.add(new_admin)
                bot_config.admin_usernames = ','.join(filter(None, current_admins))
                logger.info(f"[Bot] 更新后的管理员列表: {bot_config.admin_usernames}")
                
                try:
                    # 保存到数据库
                    db.session.merge(bot_config)  # 使用 merge 替代 add
                    db.session.commit()
                    logger.info("[Bot] 数据库更新成功")
                    
                    # 更新本地配置
                    self.config = bot_config
                    
                    # 发送成功消息
                    keyboard = InlineKeyboardMarkup()
                    keyboard.row(
                        InlineKeyboardButton("➕ 继续添加", callback_data="admin_add")
                    )
                    keyboard.row(
                        InlineKeyboardButton("⬅️ 返回主菜单", callback_data="back_to_config")
                    )
                    
                    msg = f"✅ 已添加管理员: @{new_admin}"
                    
                    self.bot.reply_to(
                        message,
                        msg,
                        reply_markup=keyboard
                    )
                    logger.info("[Bot] 成功消息已发送")
                    
                except Exception as db_error:
                    logger.info(f"[Bot] 数据库操作出错: {str(db_error)}")
                    db.session.rollback()
                    raise db_error
                
                finally:
                    # 清理用户状态
                    user_id = str(message.from_user.id)
                    if user_id in self._user_states:
                        del self._user_states[user_id]
                        logger.info("[Bot] 用户状态已清理")
                
        except Exception as e:
            logger.info(f"[Bot] 保存管理员出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.reply_to(message, "❌ 添加管理员失败，请重试")

    def handle_admin_delete(self, call, username):
        """处理删除管理员"""
        try:
            logger.info("[Bot] 开始处理删除管理员")
            logger.info(f"[Bot] 要删除的管理员: {username}")
            
            with self.app.app_context():
                from models.config import BotConfig
                from extensions import db
                
                logger.info(f"[Bot] 机器人用户名: {self.bot_username}")
                
                # 获取最新配置
                bot_config = db.session.query(BotConfig).filter_by(bot_username=self.bot_username).first()
                if not bot_config:
                    logger.info("[Bot] 错误：找不到机器人配置")
                    self.bot.answer_callback_query(call.id, "错误：找不到机器人配置")
                    return
                
                # 获取当前管理员列表
                current_admins = set(bot_config.admin_usernames.split(',')) if bot_config.admin_usernames else set()
                logger.info(f"[Bot] 当前管理员列表: {current_admins}")
                
                if username not in current_admins:
                    logger.info(f"[Bot] 用户不是管理员: {username}")
                    self.bot.answer_callback_query(call.id, "该用户不是管理员")
                    return
                
                # 删除管理员
                current_admins.remove(username)
                bot_config.admin_usernames = ','.join(filter(None, current_admins))
                logger.info(f"[Bot] 更新后的管理员列表: {bot_config.admin_usernames}")
                
                try:
                    # 保存到数据库
                    db.session.merge(bot_config)  # 使用 merge 替代 add
                    db.session.commit()
                    logger.info("[Bot] 数据库更新成功")
                    
                    # 更新本地配置
                    self.config = bot_config
                    
                    # 更新界面
                    keyboard = InlineKeyboardMarkup()
                    msg = "👥 管理员设置\n\n"
                    msg += "当前管理员:\n"
                    
                    for admin in current_admins:
                        if admin.strip():
                            msg += f"• @{admin.strip()}\n"
                            keyboard.row(
                                InlineKeyboardButton(f"❌ 删除 @{admin.strip()}", callback_data=f"admin_del_{admin.strip()}")
                            )
                    
                    keyboard.row(
                        InlineKeyboardButton("➕ 添加管理员", callback_data="admin_add")
                    )
                    keyboard.row(
                        InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                    )
                    
                    self.bot.edit_message_text(
                        msg,
                        call.message.chat.id,
                        call.message.message_id,
                        reply_markup=keyboard
                    )
                    logger.info("[Bot] 界面更新成功")
                    
                    # 发送操作成功提示
                    self.bot.answer_callback_query(
                        call.id,
                        f"已删除管理员: @{username}"
                    )
                    
                except Exception as db_error:
                    logger.info(f"[Bot] 数据库操作出错: {str(db_error)}")
                    db.session.rollback()
                    raise db_error
                
        except Exception as e:
            logger.info(f"[Bot] 删除管理员出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            db.session.rollback()  # 发生错误时回滚
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_status_toggle(self, call):
        """处理机器人状态切换"""
        try:
            with self.app.app_context():
                self.config.is_active = not self.config.is_active
                db.session.commit()
                
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton(
                        "🟢 已启用" if self.config.is_active else "🔴 已禁用", 
                        callback_data="status_toggle"
                    )
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                )
                
                msg = "⚡️ 机器人状态\n\n"
                msg += f"当前状态: {'已启用' if self.config.is_active else '已禁用'}\n"
                msg += f"创建时间: {self.config.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n"
                msg += f"更新时间: {self.config.updated_at.strftime('%Y-%m-%d %H:%M:%S')}"
                
                self.bot.edit_message_text(
                    msg,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=keyboard
                )
                
        except Exception as e:
            logger.info(f"[Bot] 切换机器人状态出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_basic_recharge(self, call):
        """处理充值地址修改"""
        try:
            user_id = str(call.from_user.id)
            self._user_states[user_id] = {
                'state': 'waiting_recharge_address',
                'message_id': call.message.message_id
            }
            
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
            )
            
            msg = "💳 请发送新的充值地址\n"
            msg += "取消编辑请发送: /cancel"
            
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard
            )
            
        except Exception as e:
            logger.info(f"[Bot] 处理充值地址修改出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def save_recharge_address(self, message):
        """保存充值地址"""
        try:
            with self.app.app_context():
                self.config.recharge_address = message.text.strip()
                db.session.commit()
                
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("✏️ 继续编辑", callback_data="basic_recharge")
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回主菜单", callback_data="back_to_config")
                )
                
                msg = "✅ 充值地址更新成功"
                
                self.bot.reply_to(
                    message,
                    msg,
                    reply_markup=keyboard
                )
                
                # 清理用户状态
                user_id = str(message.from_user.id)
                if user_id in self._user_states:
                    del self._user_states[user_id]
                
        except Exception as e:
            logger.info(f"[Bot] 保存充值地址出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.reply_to(message, "❌ 保存充值地址失败，请重试")

    def handle_basic_epay(self, call):
        """处理易支付配置修改"""
        try:
            user_id = str(call.from_user.id)
            self._user_states[user_id] = {
                'state': 'waiting_epay_config',
                'message_id': call.message.message_id
            }
            
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
            )
            
            msg = "🔑 请按以下格式发送易支付配置：\n"
            msg += "商户号|商户密钥\n\n"
            msg += "示例：1001|abcd1234\n"
            msg += "取消编辑请发送: /cancel"
            
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard
            )
            
        except Exception as e:
            logger.info(f"[Bot] 处理易支付配置修改出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def save_epay_config(self, message):
        """保存易支付配置"""
        try:
            with self.app.app_context():
                config = message.text.strip().split('|')
                if len(config) != 2:
                    self.bot.reply_to(message, "❌ 格式错误，请按照示例格式发送")
                    return
                
                self.config.epay_pid = config[0]
                self.config.epay_key = config[1]
                db.session.commit()
                
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("✏️ 继续编辑", callback_data="basic_epay")
                )
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回主菜单", callback_data="back_to_config")
                )
                
                msg = "✅ 易支付配置更新成功"
                
                self.bot.reply_to(
                    message,
                    msg,
                    reply_markup=keyboard
                )
                
                # 清理用户状态
                user_id = str(message.from_user.id)
                if user_id in self._user_states:
                    del self._user_states[user_id]
                
        except Exception as e:
            logger.info(f"[Bot] 保存易支付配置出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.reply_to(message, "❌ 保存易支付配置失败，请重试")

    def handle_stats_history(self, call):
        """处理历史数据统计"""
        try:
            with self.app.app_context():
                from models.order import Order
                from extensions import db
                from datetime import datetime, timedelta
                
                logger.info(f"[Bot] 机器人用户名: {self.bot_username}")
                
                # 获取最近7天的数据
                end_date = datetime.utcnow()
                start_date = end_date - timedelta(days=7)
                
                orders = db.session.query(Order).filter(
                    Order.bot_username == self.bot_username,
                    Order.created_at.between(start_date, end_date)
                ).all()
                
                # 按日期分组统计
                stats = {}
                for order in orders:
                    date = order.created_at.date()
                    if date not in stats:
                        stats[date] = {
                            'total': 0,
                            'completed': 0,
                            'amount': 0
                        }
                    
                    stats[date]['total'] += 1
                    if order.status == 'completed':
                        stats[date]['completed'] += 1
                        stats[date]['amount'] += order.total_amount
                
                # 生成消息
                msg = "📊 最近7天数据统计\n\n"
                for date in sorted(stats.keys()):
                    data = stats[date]
                    msg += f"📅 {date.strftime('%Y-%m-%d')}\n"
                    msg += f"总订单: {data['total']}\n"
                    msg += f"完成: {data['completed']}\n"
                    msg += f"金额: {data['amount']:.2f} USDT\n\n"
                
                keyboard = InlineKeyboardMarkup()
                keyboard.row(
                    InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
                )
                
                self.bot.edit_message_text(
                    msg,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=keyboard
                )
                logger.info("[Bot] 统计数据更新成功")
                
        except Exception as e:
            logger.info(f"[Bot] 处理历史数据统计出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def handle_commission_input(self, call):
        """处理返佣比例手动输入"""
        try:
            user_id = str(call.from_user.id)
            self._user_states[user_id] = {
                'state': 'waiting_commission_rate',
                'message_id': call.message.message_id
            }
            
            keyboard = InlineKeyboardMarkup()
            keyboard.row(
                InlineKeyboardButton("⬅️ 返回", callback_data="back_to_config")
            )
            
            msg = "💰 请输入新的返佣比例\n\n"
            msg += "格式说明：\n"
            msg += "• 直接输入数字，如：5（表示5%）\n"
            msg += "• 支持小数点，如：5.5（表示5.5%）\n"
            msg += "• 范围限制：0-100\n\n"
            msg += f"当前比例：{self.config.commission_rate:.1f}%\n\n"  # 直接显示百分比值
            msg += "取消编辑请发送: /cancel"
            
            self.bot.edit_message_text(
                msg,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard
            )
            
        except Exception as e:
            logger.info(f"[Bot] 处理返佣比例输入出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            self.bot.answer_callback_query(call.id, "处理请求时出错")

    def save_commission_rate(self, message):
        """保存返佣比例"""
        try:
            logger.info("[Bot] 开始处理返佣比例保存")
            logger.info(f"[Bot] 输入内容: {message.text}")
            
            with self.app.app_context():
                # 获取当前配置
                bot_username = self.config.bot_username  # 先获取用户名
                logger.info(f"[Bot] 机器人用户名: {bot_username}")
                
                # 获取最新配置
                bot_config = BotConfig.query.filter_by(bot_username=bot_username).first()
                if not bot_config:
                    logger.info("[Bot] 错误：找不到机器人配置")
                    self.bot.reply_to(message, "❌ 错误：找不到机器人配置")
                    return
                
                logger.info(f"[Bot] 当前数据库中的返佣比例: {bot_config.commission_rate}%")
                
                # 解析输入的比例
                try:
                    # 移除所有空格和%符号
                    rate_text = message.text.strip().rstrip('%').replace(' ', '')
                    logger.info(f"[Bot] 处理后的输入: {rate_text}")
                    
                    # 尝试转换为浮点数
                    rate = float(rate_text)
                    logger.info(f"[Bot] 转换后的数值: {rate}")
                    
                    # 验证范围
                    if rate < 0 or rate > 100:
                        logger.info(f"[Bot] 数值超出范围: {rate}")
                        self.bot.reply_to(message, "❌ 比例必须在0-100之间")
                        return
                    
                    # 更新比例 (直接存储百分比值)
                    bot_config.commission_rate = rate  # 直接存储百分比值
                    logger.info(f"[Bot] 新的返佣比例: {bot_config.commission_rate}%")
                    
                    # 提交更改
                    db.session.add(bot_config)  # 确保对象被跟踪
                    db.session.commit()  # 提交更改
                    logger.info("[Bot] 数据库更新成功")
                    
                    # 重新获取最新配置
                    bot_config = BotConfig.query.filter_by(bot_username=bot_username).first()
                    self.config = bot_config
                    logger.info(f"[Bot] 重新获取配置成功，当前比例: {bot_config.commission_rate}%")
                    
                    # 发送成功消息
                    keyboard = InlineKeyboardMarkup()
                    keyboard.row(
                        InlineKeyboardButton("✏️ 继续编辑", callback_data="config_commission")
                    )
                    keyboard.row(
                        InlineKeyboardButton("⬅️ 返回主菜单", callback_data="back_to_config")
                    )
                    
                    msg = f"✅ 返佣比例已更新为: {rate:.1f}%"
                    
                    self.bot.reply_to(
                        message,
                        msg,
                        reply_markup=keyboard
                    )
                    logger.info("[Bot] 成功消息已发送")
                    
                    # 清理用户状态
                    user_id = str(message.from_user.id)
                    if user_id in self._user_states:
                        del self._user_states[user_id]
                        logger.info("[Bot] 用户状态已清理")
                    
                except ValueError as ve:
                    logger.info(f"[Bot] 输入格式错误: {str(ve)}")
                    self.bot.reply_to(message, "❌ 请输入有效的数字，例如：5.5")
                    return
                
        except Exception as e:
            logger.info(f"[Bot] 保存返佣比例出错: {str(e)}")
            logger.info(f"[Bot] 错误详情: {str(e.__traceback__.tb_lineno)}")
            logger.info(f"[Bot] 完整错误堆栈: {traceback.format_exc()}")
            db.session.rollback()  # 发生错误时回滚
            self.bot.reply_to(message, "❌ 保存返佣比例失败，请重试") 