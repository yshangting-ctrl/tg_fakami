from .base_handler import BaseHandler
from models.config import BotConfig
from extensions import db
import re
import telebot
import threading
import logging
from logging import getLogger
logger = getLogger(__name__)

logger = logging.getLogger(__name__)

class CloneHandler(BaseHandler):
    def show_clone_info(self, message):
        """显示克隆信息"""
        with self.app.app_context():
            try:
                # 检查是否允许克隆
                bot_config = BotConfig.query.filter_by(
                    bot_username=self.config.bot_username
                ).first()
                
                if not bot_config or not bot_config.allow_clone:
                    msg = "⚠️ 该机器人暂不支持克隆功能"
                    self.bot.reply_to(message, msg)
                    return
                
                msg = """🤖 克隆机器人

💡 使用说明：
1️⃣ 打开 @BotFather
2️⃣ 发送 /newbot 创建新机器人
3️⃣ 设置机器人名称和用户名
4️⃣ 获取 API Token
5️⃣ 将 Token 发送给我

⚠️ 注意事项：
1️⃣ Token格式类似：123456789:ABCdefGHIjklMNOpqrsTUVwxyz
2️⃣ 请勿泄露您的Token
3️⃣ 每个用户可以克隆多个机器人
4️⃣ 您将获得直接下级机器人订单的返佣差价收益
5️⃣ 默认返佣比例为3%

请发送您的机器人Token："""
                
                # 设置用户状态为等待Token
                user_id = str(message.from_user.id)
                self._user_states[user_id] = {'state': 'waiting_token'}
                
                self.bot.reply_to(message, msg)
                
            except Exception as e:
                logger.info(f"[Bot] 显示克隆信息出错: {str(e)}")
                self.bot.reply_to(message, "抱歉，获取克隆信息失败，请稍后重试")
    
    def __init__(self, bot_instance):
        super().__init__(bot_instance)
        self._user_states = {}
    
    def handle_text(self, message):
        """处理文本消息"""
        with self.app.app_context():
            try:
                user_id = str(message.from_user.id)
                
                # 检查用户状态
                if user_id not in self._user_states:
                    return
                
                state = self._user_states[user_id]
                if state['state'] != 'waiting_token':
                    return
                
                # 清除用户状态
                del self._user_states[user_id]
                
                # 处理Token
                token = message.text.strip()
                
                # 验证Token格式
                if not re.match(r'^\d+:[A-Za-z0-9_-]+$', token):
                    self.bot.reply_to(message, "❌ Token格式不正确，请重新发送正确的Token。")
                    return
                
                # 获取源头机器人配置
                root_bot = BotConfig.query.filter_by(parent_bot_username=None).first()
                if not root_bot:
                    self.bot.reply_to(message, "❌ 系统错误：无法获取源头机器人配置。")
                    return
                
                try:
                    # 使用新token创建临时bot实例来获取用户名
                    temp_bot = telebot.TeleBot(token)
                    bot_info = temp_bot.get_me()
                    bot_username = '@' + bot_info.username
                    
                    # 创建新的机器人配置
                    new_config = BotConfig(
                        bot_username=bot_username,
                        bot_token=token,
                        recharge_address=root_bot.recharge_address,  # 使用源头配置
                        admin_usernames=str(message.from_user.username),  # 设置当前用户为管理员
                        parent_bot_username=self.config.bot_username,  # 设置当前机器人为上级
                        root_bot_username=root_bot.bot_username,  # 设置源头机器人
                        commission_rate=3,  # 默认佣金比例3%
                        allow_clone=True,  # 默认克隆
                        epay_pid=root_bot.epay_pid,  # 使用源头配置
                        epay_key=root_bot.epay_key,  # 使用源头配置
                        backend_url=root_bot.backend_url,
                        usdt_rate=root_bot.usdt_rate,  # 使用源头配置
                        announcement=root_bot.announcement,  # 使用源头配置
                        is_active=True
                    )
                    
                    # 保存到数据库
                    db.session.add(new_config)
                    db.session.commit()
                    
                    # 在新线程中启动机器人
                    def start_new_bot():
                        try:
                            from bot.bot_manager import bot_manager
                            with self.app.app_context():  # 添加应用上下文
                                bot_manager.start_bot(new_config)
                        except Exception as e:
                            logger.error(f"启动新机器人失败: {str(e)}")
                    
                    thread = threading.Thread(target=start_new_bot)
                    thread.daemon = True
                    thread.start()
                    
                    success_message = f"""✅ 恭喜！机器人克隆成功！

🤖 机器人信息：
- 用户名：{bot_username}
- 管理员：@{message.from_user.username}
- 默认佣金比例：3%

💰 收益说明：
- 可在机器人配置中设置商品额外涨价比例
- 所有销售收益将自动返还至您的余额
- 余额达到5U即可申请提现,自动到账

💡 使用提示：
点击 /admin 进入管理面板:
1. 点击【公告设置】修改机器人公告
2. 点击【机器人配置】修改涨价比例等
3. 如需其他帮助，请联系上级机器人管理员"""
                    
                    self.bot.reply_to(message, success_message)
                    
                except Exception as e:
                    logger.error(f"克隆机器人失败: {str(e)}")
                    self.bot.reply_to(message, f"❌ 克隆机器人失败：{str(e)}")
                    db.session.rollback()
                
            except Exception as e:
                logger.error(f"处理Token消息失败: {str(e)}")
                self.bot.reply_to(message, "抱歉，处理您的请求时出现错误，请稍后重试。") 