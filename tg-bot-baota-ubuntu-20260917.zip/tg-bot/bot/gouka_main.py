import sys
import os

# 添加项目根目录到系统路径
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT_DIR)

import logging
import telebot
from flask import Flask
from extensions import init_extensions, db
from models.config import BotConfig
from bot.bot_manager import bot_manager
from logging.handlers import RotatingFileHandler
from logging import getLogger
logger = getLogger(__name__)

# 创建logs目录（如果不存在）
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# 配置日志格式
log_format = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# 配置文件日志处理器
file_handler = RotatingFileHandler(
    os.path.join(log_dir, 'bot.log'),
    maxBytes=10*1024*1024,  # 10MB
    backupCount=5,
    encoding='utf-8'
)
file_handler.setFormatter(log_format)
file_handler.setLevel(logging.DEBUG)

# 配置控制台日志处理器
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(log_format)
console_handler.setLevel(logging.INFO)

# 配置根日志记录器
root_logger = logging.getLogger()
root_logger.setLevel(logging.DEBUG)
root_logger.addHandler(file_handler)
root_logger.addHandler(console_handler)

# 配置telebot日志
telebot.logger.handlers = []  # 清除现有的处理器
for handler in root_logger.handlers:
    telebot.logger.addHandler(handler)
telebot.logger.setLevel(logging.DEBUG)

# 配置应用日志记录器
logger = logging.getLogger(__name__)

def create_app():
    """创建Flask应用（仅用于数据库操作）"""
    try:
        logger.info("[Bot] 创建 Flask 应用...")
        app = Flask(__name__)
        
        # 使用相对于项目根目录的路径
        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        db_path = os.path.join(root_dir, 'instance', 'mall.db')
        app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
        logger.info(f"[Bot] 数据库路径: {db_path}")
        
        # 检查数据库文件是否存在
        if not os.path.exists(db_path):
            logger.info(f"[Bot] 警告: 数据库文件不存在: {db_path}")
            logger.info(f"[Bot] 尝试在其他位置查找数据库文件...")
            
            # 尝试在项目根目录查找
            alt_db_path = os.path.join(root_dir, 'mall.db')
            if os.path.exists(alt_db_path):
                logger.info(f"[Bot] 找到数据库文件: {alt_db_path}")
                db_path = alt_db_path
                app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
            else:
                logger.info(f"[Bot] 错误: 找不到数据库文件")
                raise FileNotFoundError(f"数据库文件不存在: {db_path} 或 {alt_db_path}")
        
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        init_extensions(app, start_backup=False)
        logger.info("[Bot] Flask 应用创建成功")
        return app
    except Exception as e:
        logger.info(f"[Bot] 创建 Flask 应用失败: {str(e)}")
        if hasattr(e, '__traceback__'):
            import traceback
            logger.info(traceback.format_exc())
        raise

def auto_update_tables(app):
    """自动更新数据库表结构"""
    try:
        with app.app_context():
            # 获取所有模型类
            from models.user import User
            from models.config import BotConfig
            from models.order import Order
            from models.product import Product
            from models.category import Category
            from models.withdrawal import Withdrawal
            from models.advertisement import Advertisement
            from models.balance_log import BalanceLog
            from models.key import Key
            from sqlalchemy import text

            models = [User, BotConfig, Order, Product, Category, Withdrawal, Advertisement, BalanceLog, Key]
            inspector = db.inspect(db.engine)

            # 检查每个模型的表和字段
            for model in models:
                table_name = model.__tablename__
                
                # 如果表不存在，创建表
                if not inspector.has_table(table_name):
                    logger.info(f"[Bot] 创建表 {table_name}")
                    model.__table__.create(db.engine)
                    continue

                # 获取现有的列
                existing_columns = {col['name']: col for col in inspector.get_columns(table_name)}
                model_columns = {col.name: col for col in model.__table__.columns}

                # 检查缺失的列
                for col_name, col in model_columns.items():
                    if col_name not in existing_columns:
                        try:
                            # 获取列定义
                            column_type = col.type.compile(dialect=db.engine.dialect)
                            
                            # 对于字符串类型的列，设置默认值为空字符串
                            if isinstance(col.type, db.String):
                                default = " DEFAULT ''"
                            else:
                                default = f" DEFAULT {col.default.arg}" if col.default is not None and col.default.arg is not None else ""
                            
                            nullable = "" if col.nullable else " NOT NULL"
                            
                            # 直接添加新列
                            alter_stmt = text(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {column_type}{nullable}{default}")
                            
                            # 执行 ALTER TABLE
                            db.session.execute(alter_stmt)
                            db.session.commit()
                            
                            # 如果是字符串类型的列，更新现有行的值为空字符串
                            if isinstance(col.type, db.String):
                                update_stmt = text(f"UPDATE {table_name} SET {col_name} = '' WHERE {col_name} IS NULL")
                                db.session.execute(update_stmt)
                                db.session.commit()
                            db.session.execute(alter_stmt)
                            db.session.commit()
                            logger.info(f"[Bot] 成功添加列 {col_name} 到表 {table_name}")
                            
                        except Exception as e:
                            logger.error(f"[Bot] 添加列 {col_name} 到表 {table_name} 时出错: {str(e)}")
                            db.session.rollback()
                            continue

            logger.info("[Bot] 数据库表结构更新完成")
            return True

    except Exception as e:
        logger.error(f"[Bot] 更新数据库表结构时出错: {str(e)}")
        if hasattr(e, '__traceback__'):
            import traceback
            logger.error(traceback.format_exc())
        return False

def main():
    """机器人系统主函数"""
    try:
        logger.info("[Bot] 正在初始化机器人系统...")
        
        # 创建应用上下文
        app = create_app()
        
        # 初始化bot_manager
        bot_manager.init_app(app)
        
        # 自动更新数据库表结构
        logger.info("[Bot] 正在更新数据库表结构...")
        if not auto_update_tables(app):
            logger.error("[Bot] 数据库表结构更新失败，停止启动")
            return
        
        with app.app_context():
            try:
                logger.info("[Bot] 正在查询机器人配置...")
                # 获取所有启用的机器人配置
                configs = BotConfig.query.filter_by(is_active=True).all()
                
                if not configs:
                    logger.info("[Bot] 没有找到已启用的机器人配置")
                    return
                
                logger.info(f"[Bot] 找到 {len(configs)} 个已启用的机器人配置")
                
                # 启动所有机器人
                for config in configs:
                    try:
                        logger.info(f"[Bot] 正在启动机器人: {config.bot_username}")
                        bot_manager.start_bot(config)
                        logger.info(f"[Bot] 机器人 {config.bot_username} 启动成功")
                    except Exception as e:
                        logger.info(f"[Bot] 启动机器人 {config.bot_username} 失败: {str(e)}")
                
                logger.info("[Bot] 机器人系统启动成功")
                logger.info("[Bot] 进入主循环...")
                
                # 保持程序运行
                while True:
                    import time
                    time.sleep(1)
                    
            except Exception as e:
                logger.info(f"[Bot] 数据库操作失败: {str(e)}")
                raise
                
    except KeyboardInterrupt:
        logger.info("[Bot] 收到停止信号，正在关闭机器人系统...")
    except Exception as e:
        logger.info(f"[Bot] 机器人系统运行出错: {str(e)}")
        if hasattr(e, '__traceback__'):
            import traceback
            logger.info(traceback.format_exc())
    finally:
        # 停止所有机器人
        try:
            bot_manager.stop_all()
            logger.info("[Bot] 机器人系统已停止")
        except Exception as e:
            logger.info(f"[Bot] 停止机器人系统时出错: {str(e)}")

if __name__ == '__main__':
    main() 
