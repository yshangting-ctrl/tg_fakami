import subprocess
import logging
import os
import signal
import sys
from typing import Dict
from models.config import BotConfig

logger = logging.getLogger(__name__)

class ProcessManager:
    """机器人进程管理器"""
    def __init__(self):
        self.processes: Dict[str, subprocess.Popen] = {}  # username -> process
    
    def start_bot(self, config: BotConfig):
        """启动机器人进程"""
        username = config.bot_username
        
        # 如果进程已存在，先停止
        if username in self.processes:
            self.stop_bot(username)
        
        try:
            # 启动新进程
            root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            main_path = os.path.join(root_dir, 'bot', 'gouka_main.py')
            process = subprocess.Popen(
                [sys.executable, main_path, username],
                cwd=root_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            self.processes[username] = process
            logger.info(f"启动机器人进程 {username}")
        except Exception as e:
            logger.error(f"启动机器人进程失败 {username}: {str(e)}")
    
    def stop_bot(self, username: str):
        """停止机器人进程"""
        if username in self.processes:
            try:
                process = self.processes[username]
                # 发送SIGTERM信号
                os.kill(process.pid, signal.SIGTERM)
                # 等待进程结束
                process.wait(timeout=5)
                logger.info(f"停止机器人进程 {username}")
            except Exception as e:
                logger.error(f"停止机器人进程失败 {username}: {str(e)}")
                # 如果正常停止失败，强制结束进程
                try:
                    os.kill(process.pid, signal.SIGKILL)
                except:
                    pass
            finally:
                del self.processes[username]
    
    def stop_all(self):
        """停止所有机器人进程"""
        for username in list(self.processes.keys()):
            self.stop_bot(username)
    
    def restart_bot(self, username: str):
        """重启机器人进程"""
        if username in self.processes:
            config = BotConfig.query.filter_by(
                bot_username=username,
                is_active=True
            ).first()
            if config:
                self.stop_bot(username)
                self.start_bot(config)
                logger.info(f"重启机器人进程 {username}")
            else:
                logger.error(f"找不到机器人配置或机器人未启用: {username}")

# 创建全局进程管理器实例
process_manager = ProcessManager() 
