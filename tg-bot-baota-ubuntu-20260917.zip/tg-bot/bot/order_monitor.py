from datetime import datetime, timedelta
import threading
import time
import logging
from extensions import db
from models.order import Order
from telebot.types import InlineKeyboardMarkup

logger = logging.getLogger(__name__)

class OrderMonitor:
    """订单监控器，用于处理过期订单"""
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
            return cls._instance
    
    def __init__(self):
        self.app = None
        self.is_running = False
        self.thread = None
        self._stop_event = threading.Event()
    
    def init_app(self, app):
        """初始化应用"""
        self.app = app
    
    def start(self):
        """启动监控"""
        if self.is_running:
            return
        
        self.is_running = True
        self._stop_event.clear()
        self.thread = threading.Thread(target=self._monitor_orders)
        self.thread.daemon = True
        self.thread.start()
        logger.info("订单监控器已启动")
    
    def stop(self):
        """停止监控"""
        self.is_running = False
        self._stop_event.set()
        if self.thread:
            self.thread.join()
        logger.info("订单监控器已停止")
    
    def _monitor_orders(self):
        """监控订单"""
        while self.is_running:
            try:
                with self.app.app_context():
                    # 查找所有待支付的订单
                    pending_orders = Order.query.filter_by(status='pending').all()
                    current_time = datetime.utcnow()
                    
                    for order in pending_orders:
                        # 检查订单是否过期（30分钟）
                        if current_time - order.created_at > timedelta(minutes=30):
                            try:
                                # 更新订单状态
                                order.status = 'cancelled'
                                db.session.commit()
                                logger.info(f"订单已过期并取消: {order.id}")
                                
                                # 获取机器人实例
                                from bot.bot_manager import bot_manager
                                bot_instance = bot_manager.get_bot(order.bot_username)
                                if bot_instance and bot_instance.bot:
                                    # 尝试编辑原消息
                                    try:
                                        msg = "❌ 订单已过期\n\n"
                                        msg += f"订单号：{order.id}\n"
                                        msg += "------------\n"
                                        if order.product_id:  # 商品订单
                                            msg += f"商品：{order.product.name}\n"
                                            msg += f"数量：{order.quantity}\n"
                                        msg += f"金额：${order.total_amount:.2f}\n"
                                        msg += "------------\n"
                                        msg += "订单已自动取消，如需购买请重新下单"
                                        
                                        # 清除内联键盘
                                        keyboard = InlineKeyboardMarkup()
                                        
                                        # 查找原始消息并更新
                                        # 注意：这需要在数据库中存储消息ID
                                        if hasattr(order, 'message_id') and hasattr(order, 'chat_id'):
                                            bot_instance.bot.edit_message_text(
                                                text=msg,
                                                chat_id=order.chat_id,
                                                message_id=order.message_id,
                                                reply_markup=keyboard
                                            )
                                    except Exception as e:
                                        logger.error(f"更新过期订单消息失败: {str(e)}")
                                        
                            except Exception as e:
                                logger.error(f"处理过期订单时出错: {str(e)}")
                                db.session.rollback()
                    
            except Exception as e:
                logger.error(f"订单监控出错: {str(e)}")
            
            # 每60秒检查一次
            for _ in range(60):
                if self._stop_event.is_set():
                    return
                time.sleep(1)

# 创建单例实例
order_monitor = OrderMonitor() 