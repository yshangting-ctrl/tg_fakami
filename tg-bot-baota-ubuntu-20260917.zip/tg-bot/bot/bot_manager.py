import sys
import os
import time
import logging
import telebot
from threading import Thread, Lock, RLock
from typing import Dict
from models.config import BotConfig
from models.user import User
from extensions import db
from logging import getLogger
logger = getLogger(__name__)

# 配置日志
logger = logging.getLogger(__name__)

class BotInstance:
    """单个机器人实例"""
    def __init__(self, config: BotConfig, app=None):
        self.config = config
        self.bot = None
        self.thread = None
        self.is_running = False
        self.error_count = 0
        self.last_error_time = 0
        self._lock = Lock()
        self.app = app
        self.init_bot()
    
    def init_bot(self):
        """初始化机器人实例"""
        with self._lock:
            try:
                if self.bot:
                    try:
                        self.bot.stop_polling()
                    except:
                        pass
                
                self.bot = telebot.TeleBot(self.config.bot_token)
                # 验证token是否有效
                bot_info = self.bot.get_me()
                logger.info(f"[Bot] 机器人 {self.config.bot_username} 初始化成功")
                
                # 设置命令处理器
                from bot.handlers import CommandHandlers
                handlers = CommandHandlers(self)
                handlers.setup_handlers()
                
            except Exception as e:
                logger.info(f"[Bot] 初始化机器人失败: {str(e)}")
                raise
    
    def start(self):
        """启动机器人"""
        with self._lock:
            if self.is_running:
                return
            
            def run_bot():
                logger.info(f"[Bot] 启动机器人: {self.config.bot_username}")
                while self.is_running:
                    try:
                        self.bot.polling(
                            non_stop=True,
                            timeout=60,
                            allowed_updates=telebot.util.update_types,
                        )
                        self.error_count = 0
                        self.last_error_time = 0
                    except Exception as e:
                        current_time = time.time()
                        if current_time - self.last_error_time > 300:
                            self.error_count = 0
                        
                        self.error_count += 1
                        self.last_error_time = current_time
                        
                        logger.info(f"[Bot] 机器人运行出错: {str(e)}")
                        
                        if self.error_count >= 3:
                            try:
                                logger.info("[Bot] 尝试重新初始化机器人")
                                self.init_bot()
                                self.error_count = 0
                            except Exception as reinit_error:
                                logger.info(f"[Bot] 重新初始化失败: {str(reinit_error)}")
                        
                        wait_time = min(5 * self.error_count, 30)
                        time.sleep(wait_time)
            
            self.is_running = True
            self.thread = Thread(target=run_bot)
            self.thread.daemon = True
            self.thread.start()
            logger.info(f"[Bot] 机器人线程已启动: {self.config.bot_username}")
    
    def stop(self):
        """停止机器人"""
        with self._lock:
            if not self.is_running:
                return
            
            self.is_running = False
            if self.bot:
                try:
                    self.bot.stop_polling()
                except:
                    pass
            if self.thread:
                self.thread.join(timeout=5)
                self.thread = None
            logger.info(f"[Bot] 停止机器人 {self.config.bot_username}")

class BotManager:
    """机器人管理器，负责管理所有机器人实例"""
    _instance = None
    _lock = Lock()
    
    def __new__(cls):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super(BotManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.bots: Dict[str, BotInstance] = {}
            self._lock = RLock()
            self.app = None
            self.initialized = True
    
    def init_app(self, app):
        """初始化Flask应用"""
        self.app = app
    
    def start_bot(self, config: BotConfig):
        """启动单个机器人"""
        with self._lock:
            username = config.bot_username
            
            # 如果机器人已存在且正在运行，直接返回
            if username in self.bots:
                bot_instance = self.bots[username]
                if bot_instance.is_running:
                    logger.info(f"[Bot] 机器人 {username} 已经在运行")
                    return
                
                # 如果配置变化，需要重启
                if bot_instance.config.bot_token != config.bot_token:
                    logger.info(f"[Bot] 机器人 {username} 配置已变更，正在重启")
                    self.stop_bot(username)
                else:
                    # 如果配置未变化但没有运行，重新启动
                    logger.info(f"[Bot] 机器人 {username} 未运行，正在启动")
                    bot_instance.start()
                    return
            
            # 创建并启动新的机器人实例
            try:
                bot_instance = BotInstance(config, app=self.app)
                self.bots[username] = bot_instance  # 先保存实例
                bot_instance.start()  # 再启动
                logger.info(f"[Bot] 机器人 {username} 启动成功")
            except Exception as e:
                logger.info(f"[Bot] 启动机器人 {username} 失败: {str(e)}")
                # 如果启动失败，确保清理
                if username in self.bots:
                    del self.bots[username]
                raise
    
    def stop_bot(self, username: str):
        """停止单个机器人"""
        with self._lock:
            if username in self.bots:
                try:
                    self.bots[username].stop()
                    logger.info(f"停止机器人 {username}")
                except Exception as e:
                    logger.error(f"停止机器人 {username} 失败: {str(e)}")
                finally:
                    del self.bots[username]
    
    def stop_all(self):
        """停止所有机器人"""
        with self._lock:
            for username in list(self.bots.keys()):
                self.stop_bot(username)
            logger.info("所有机器人已停止")

    def get_bot(self, username: str) -> BotInstance:
        """获取机器人实例,如果不存在则返回None
        Args:
            username: 机器人用户名
        Returns:
            BotInstance: 机器人实例，如果不存在则返回None
        """
        logger.info(f"[Bot] 获取机器人实例: {username}")
        
        # 处理username格式,支持带@和不带@的查找
        clean_username = username.lstrip('@')
        username_with_at = '@' + clean_username
        
        # 先从现有实例中查找(支持带@和不带@两种格式)
        if username_with_at in self.bots:
            return self.bots[username_with_at]
        elif clean_username in self.bots:
            return self.bots[clean_username]
            
        # 从配置中查找并创建
        try:
            config = BotConfig.query.filter_by(
                    bot_username=username,
                    is_active=True
            ).first()
            
            if config:
                self.start_bot(config)
                return self.bots.get(username)
                    
        except Exception as e:
            logger.error(f"从配置创建机器人失败 {username}: {str(e)}")
            
        return None

# 创建全局机器人管理器实例
bot_manager = BotManager() 
