import threading
import time
import traceback
from telebot import TeleBot
from models.user import User
from models.config import BotConfig
from extensions import db
from logging import getLogger
logger = getLogger(__name__)

class BroadcastService:
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
            return cls._instance
    
    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.initialized = True
            self.is_broadcasting = False
            self.current_bot = None
            self.stop_flag = False
            self.broadcast_thread = None
            self.status_message = ""
            self.app = None
    
    def init_app(self, app):
        """初始化应用"""
        self.app = app
    
    def get_status(self):
        """获取当前群发状态"""
        if self.is_broadcasting:
            return {
                'status': 'running',
                'message': self.status_message or '群发进行中...'
            }
        return {
            'status': 'stopped',
            'message': self.status_message or '群发已停止'
        }
    
    def start_broadcast(self, content, broadcast_tasks, pin_message=False):
        """开始群发
        Args:
            content: 群发内容
            broadcast_tasks: 群发任务列表，每个任务包含 bot_username 和 user_ids
        """
        if self.is_broadcasting:
            return False, "群发任务正在进行中"
        
        try:
            with self.app.app_context():
                # 获取所有需要的机器人配置
                bot_usernames = [task['bot_username'] for task in broadcast_tasks]
                bot_configs = db.session.query(BotConfig).filter(
                    BotConfig.bot_username.in_(bot_usernames)
                ).all()
                
                # 创建机器人用户名到token的映射
                bot_tokens = {
                    config.bot_username: config.bot_token 
                    for config in bot_configs
                }
                
                # 验证所有机器人配置都存在
                missing_bots = set(bot_usernames) - set(bot_tokens.keys())
                if missing_bots:
                    return False, f"找不到以下机器人的配置: {', '.join(missing_bots)}"
                
                # 创建机器人实例映射
                self.current_bots = {
                    username: TeleBot(token)
                    for username, token in bot_tokens.items()
                }
                
                self.stop_flag = False
                self.is_broadcasting = True
                self.status_message = "正在准备群发..."
                
                # 启动群发线程
                self.broadcast_thread = threading.Thread(
                    target=self._broadcast_task,
                    args=(content, broadcast_tasks, pin_message)
                )
                self.broadcast_thread.daemon = True
                self.broadcast_thread.start()
                
                return True, "群发任务已启动"
                
        except Exception as e:
            logger.info(f"[Broadcast] 启动群发任务失败: {str(e)}")
            logger.info(f"[Broadcast] 错误详情: {traceback.format_exc()}")
            return False, f"启动群发任务失败: {str(e)}"
    
    def stop_broadcast(self):
        """停止群发"""
        if not self.is_broadcasting:
            return False, "没有正在进行的群发任务"
        
        try:
            self.stop_flag = True
            self.status_message = "正在停止群发..."
            
            # 等待线程结束
            if self.broadcast_thread and self.broadcast_thread.is_alive():
                self.broadcast_thread.join(timeout=5)
            
            # 清理资源
            if self.current_bots:
                for bot in self.current_bots.values():
                    bot.stop_polling()
                self.current_bots = {}
            
            self.is_broadcasting = False
            self.status_message = "群发已停止"
            return True, "群发任务已停止"
            
        except Exception as e:
            logger.info(f"[Broadcast] 停止群发任务失败: {str(e)}")
            logger.info(f"[Broadcast] 错误详情: {traceback.format_exc()}")
            return False, f"停止群发任务失败: {str(e)}"
    
    def _broadcast_task(self, content, broadcast_tasks, pin_message=False):
        """群发任务的具体实现"""
        try:
            with self.app.app_context():
                total_success = 0
                total_fail = 0
                total_users = sum(len(task['user_ids']) for task in broadcast_tasks)
                processed = 0
                
                for task in broadcast_tasks:
                    if self.stop_flag:
                        break
                    
                    bot_username = task['bot_username']
                    user_ids = task['user_ids']
                    bot = self.current_bots.get(bot_username)
                    
                    if not bot:
                        logger.info(f"[Broadcast] 找不到机器人实例: {bot_username}")
                        total_fail += len(user_ids)
                        processed += len(user_ids)
                        continue
                    
                    for user_id in user_ids:
                        if self.stop_flag:
                            break
                        
                        try:
                            # 发送消息并置顶
                            message = bot.send_message(
                                chat_id=user_id,
                                text=content,
                                parse_mode='HTML'
                            )
                            if pin_message:
                                # 将消息置顶
                                bot.pin_chat_message(
                                    chat_id=user_id,
                                    message_id=message.message_id,
                                    disable_notification=True
                                )
                            total_success += 1
                            
                        except Exception as e:
                            logger.info(f"[Broadcast] 发送消息给用户 {user_id} 失败: {str(e)}")
                            total_fail += 1
                        
                        processed += 1
                        # 更新状态
                        self.status_message = f"正在群发... ({processed}/{total_users})"
                        
                        # 添加延迟避免触发限制
                        time.sleep(0.1)
                
                # 更新最终状态
                self.status_message = f"群发完成 - 成功: {total_success}, 失败: {total_fail}"
                
        except Exception as e:
            logger.info(f"[Broadcast] 群发任务执行出错: {str(e)}")
            logger.info(f"[Broadcast] 错误详情: {traceback.format_exc()}")
            self.status_message = f"群发任务出错: {str(e)}"
        
        finally:
            # 清理资源
            if self.current_bots:
                for bot in self.current_bots.values():
                    bot.stop_polling()
                self.current_bots = {}
            self.is_broadcasting = False 