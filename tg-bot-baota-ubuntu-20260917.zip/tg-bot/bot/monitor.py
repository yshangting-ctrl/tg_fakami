from threading import Thread
import time
import logging
from flask import current_app
from models.config import BotConfig
from .process_manager import process_manager

logger = logging.getLogger(__name__)

class BotMonitor:
    """机器人监控器，负责定期检查和更新机器人进程"""
    def __init__(self, check_interval=60):
        self.check_interval = check_interval  # 检查间隔（秒）
        self.thread = None
        self.is_running = False
        self.app = None
    
    def init_app(self, app):
        """初始化Flask应用实例"""
        self.app = app
    
    def start(self):
        """启动监控线程"""
        if self.is_running or not self.app:
            return
        
        def run_monitor():
            logger.info("启动机器人监控线程")
            while self.is_running:
                try:
                    with self.app.app_context():
                        # 获取所有启用的机器人配置
                        configs = BotConfig.query.filter_by(is_active=True).all()
                        active_usernames = {config.bot_username for config in configs}
                        
                        # 停止已禁用的机器人
                        for username in list(process_manager.processes.keys()):
                            if username not in active_usernames:
                                process_manager.stop_bot(username)
                        
                        # 启动新的机器人
                        for config in configs:
                            if config.bot_username not in process_manager.processes:
                                process_manager.start_bot(config)
                except Exception as e:
                    logger.error(f"机器人监控出错: {str(e)}")
                time.sleep(self.check_interval)
        
        self.is_running = True
        self.thread = Thread(target=run_monitor)
        self.thread.daemon = True
        self.thread.start()
        logger.info("机器人监控线程启动成功")
    
    def stop(self):
        """停止监控线程"""
        if not self.is_running:
            return
        
        self.is_running = False
        if self.thread:
            self.thread.join()
            self.thread = None
        # 停止所有机器人进程
        process_manager.stop_all()
        logger.info("机器人监控线程停止成功")

# 创建全局监控器实例
bot_monitor = BotMonitor() 