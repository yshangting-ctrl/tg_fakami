from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from models.user import User
from models.balance_log import BalanceLog
from extensions import db

bp = Blueprint('user', __name__)

@bp.route('/users')
@login_required
def users():
    return render_template('users.html')

@bp.route('/api/users', methods=['GET'])
@login_required
def get_users():
    users = User.query.order_by(User.id.asc()).all()
    return jsonify([user.to_dict() for user in users])

@bp.route('/api/users', methods=['POST'])
@login_required
def create_user():
    data = request.json
    # 检查用户ID是否已存在
    if User.query.get(data['id']):
        return jsonify({'message': '用户ID已存在'}), 400
        
    # 检查用户名是否已存在
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': '用户名已存在'}), 400
    
    try:
        user = User(
            id=data['id'],
            username=data['username'],
            nickname=data.get('nickname')
        )
        user.password = data['password']
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify({
            'message': '用户创建成功',
            'user': user.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'用户创建失败: {str(e)}'}), 500

@bp.route('/api/users/<id>/balance', methods=['POST'])
@login_required
def update_user_balance(id):
    user = User.query.get_or_404(id)
    data = request.json
    amount = float(data.get('amount', 0))
    
    try:
        if user.update_balance(amount):
            # 添加余额变动记录
            balance_log = BalanceLog(
                username=user.username,
                telegram_id=user.telegram_id,
                bot_username=user.bot_username,
                type='increase' if amount > 0 else 'decrease',
                amount=abs(amount),  # 记录绝对值
                balance=user.balance,
                description=f'管理员操作: {"增加" if amount > 0 else "减少"} {abs(amount)} USDT'
            )
            db.session.add(balance_log)
            db.session.commit()
            
            return jsonify({
                'message': f'余额更新成功，当前余额: ${user.balance:.2f}',
                'balance': user.balance
            })
        else:
            return jsonify({'message': '余额不足'}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'余额更新失败: {str(e)}'}), 500 