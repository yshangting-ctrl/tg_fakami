from flask import Blueprint, render_template, request, jsonify, send_file
from flask_login import login_required
from models.order import Order
from models.product import Product
from extensions import db
from datetime import datetime
import uuid
import os
import tempfile
import zipfile
import io
from logging import getLogger
logger = getLogger(__name__)

bp = Blueprint('order', __name__)

@bp.route('/orders')
@login_required
def orders():
    return render_template('orders.html')

@bp.route('/api/orders', methods=['GET'])
@login_required
def get_orders():
    # 获取查询参数
    status = request.args.get('status')
    user_id = request.args.get('user_id')
    payment_type = request.args.get('payment_type')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    # 构建查询
    query = Order.query
    
    if status:
        query = query.filter(Order.status == status)
    if user_id:
        query = query.filter(Order.user_id == user_id)
    if payment_type:
        query = query.filter(Order.payment_type == payment_type)
    if start_date:
        query = query.filter(Order.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        query = query.filter(Order.created_at < datetime.strptime(end_date, '%Y-%m-%d'))
    
    # 按创建时间倒序排序
    orders = query.order_by(Order.created_at.desc()).all()
    return jsonify([order.to_dict() for order in orders])

@bp.route('/api/orders/<string:id>', methods=['GET'])
@login_required
def get_order(id):
    # 使用 Session.get() 替代 Query.get()
    order = db.session.get(Order, id)
    if not order:
        return jsonify({'message': '订单不存在'}), 404
    return jsonify(order.to_dict())

# 创建订单API（供后端调用）
def create_order(user_id, product_id, quantity, bot_username, payment_type='RMB'):
    """创建订单
    
    Args:
        user_id (str): 用户ID
        product_id (int): 商品ID
        quantity (int): 购买数量
        bot_username (str): 处理订单的机器人用户名
        payment_type (str, optional): 支付类型. Defaults to 'RMB'.
    
    Returns:
        Order: 创建的订单对象
    """
    # 获取商品信息
    product = db.session.get(Product, product_id)
    if not product:
        raise ValueError('商品不存在')
    
    # 生成订单号
    order_id = f"ORD{datetime.utcnow().strftime('%Y%m%d%H%M%S')}{uuid.uuid4().hex[:6]}"
    
    # 计算总金额
    unit_price = product.price
    total_amount = unit_price * quantity
    
    # 创建订单
    order = Order(
        id=order_id,
        user_id=user_id,
        product_id=product_id,
        bot_username=bot_username,
        unit_price=unit_price,
        quantity=quantity,
        total_amount=total_amount,
        payment_type=payment_type,
        status='pending'
    )
    
    try:
        db.session.add(order)
        db.session.commit()
        return order
    except Exception as e:
        db.session.rollback()
        raise e

# 更新订单状态API（供后端调用）
def update_order_status(order_id, status, payment_address=None, payment_amount=None):
    """更新订单状态
    
    Args:
        order_id (str): 订单ID
        status (str): 新状态
        payment_address (str, optional): 支付地址. Defaults to None.
        payment_amount (float, optional): 支付金额. Defaults to None.
    
    Returns:
        Order: 更新后的订单对象
    """
    order = db.session.get(Order, order_id)
    if not order:
        raise ValueError('订单不存在')
    
    try:
        order.status = status
        if status == 'paid':
            order.payment_time = datetime.utcnow()
            if payment_address:
                order.payment_address = payment_address
            if payment_amount:
                order.payment_amount = payment_amount
        
        db.session.commit()
        return order
    except Exception as e:
        db.session.rollback()
        raise e

# 取消订单API（供后端调用）
def cancel_order(order_id):
    """取消订单
    
    Args:
        order_id (str): 订单ID
    
    Returns:
        Order: 取消的订单对象
    """
    order = db.session.get(Order, order_id)
    if not order:
        raise ValueError('订单不存在')
    
    if order.status != 'pending':
        raise ValueError('只能取消待支付的订单')
    
    try:
        order.status = 'cancelled'
        db.session.commit()
        return order
    except Exception as e:
        db.session.rollback()
        raise e 

@bp.route('/api/orders/<string:id>/download-keys', methods=['GET'])
@login_required
def download_order_keys(id):
    """下载订单的所有卡密"""
    temp_dir = None
    try:
        order = db.session.get(Order, id)
        if not order:
            return jsonify({'message': '订单不存在'}), 404

        # 创建临时目录用于存放zip文件
        temp_dir = tempfile.mkdtemp()
        zip_path = os.path.join(temp_dir, f'order_{order.id}_keys.zip')
        
        # 创建zip文件
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # 创建说明文件
            readme_path = os.path.join(temp_dir, 'README.txt')
            with open(readme_path, 'w', encoding='utf-8') as f:
                f.write(f"订单号: {order.id}\n")
                f.write(f"商品名称: {order.product.name}\n")
                f.write(f"购买数量: {order.quantity}\n")
                f.write(f"购买时间: {order.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write("\n感谢您的购买！如有问题请联系客服。\n")
            
            # 添加说明文件到zip
            zipf.write(readme_path, 'README.txt')
            
            # 添加所有卡密文件
            for i, key in enumerate(order.keys, 1):
                # 取重命名下划线前面的部分作为前端展示名
                if "_" in key.file_name:
                    frontend_name = key.file_name.split("_")[0]
                else:
                    frontend_name = key.file_name

                if os.path.exists(key.file_path):
                    # 如果是文件或目录，递归添加
                    if os.path.isdir(key.file_path):
                        # 如果是目录，保持完整的目录结构
                        target_path = f"{frontend_name}"
                        add_to_zip(zipf, key.file_path, target_path)
                    else:
                        # 如果是单个文件，直接添加
                        target_path = f"{frontend_name}"
                        zipf.write(key.file_path, target_path)
                else:
                    # 如果是文本内容，创建文本文件
                    file_name = f"{frontend_name}"
                    content_path = os.path.join(temp_dir, file_name)
                    with open(content_path, 'w', encoding='utf-8') as f:
                        f.write(key.content)
                    zipf.write(content_path, file_name)

        # 读取zip文件内容到内存
        with open(zip_path, 'rb') as f:
            data = f.read()

        # 删除临时文件和目录
        try:
            os.unlink(zip_path)  # 删除zip文件
            os.unlink(readme_path)  # 删除README文件
            # 删除其他临时文件
            for file in os.listdir(temp_dir):
                file_path = os.path.join(temp_dir, file)
                try:
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                except Exception as e:
                    logger.info(f"删除临时文件失败: {str(e)}")
            os.rmdir(temp_dir)  # 删除临时目录
        except Exception as e:
            logger.info(f"清理临时文件失败: {str(e)}")

        # 从内存发送文件
        return send_file(
            io.BytesIO(data),
            as_attachment=True,
            download_name=f'order_{order.id}_keys.zip',
            mimetype='application/zip'
        )

    except Exception as e:
        logger.info(f"下载订单卡密出错: {str(e)}")
        # 清理临时文件和目录
        if temp_dir and os.path.exists(temp_dir):
            try:
                for file in os.listdir(temp_dir):
                    file_path = os.path.join(temp_dir, file)
                    try:
                        if os.path.isfile(file_path):
                            os.unlink(file_path)
                    except Exception as e:
                        logger.info(f"删除临时文件失败: {str(e)}")
                os.rmdir(temp_dir)
            except Exception as e:
                logger.info(f"清理临时目录失败: {str(e)}")
        return jsonify({'message': '下载失败'}), 500

def add_to_zip(zipf, source_path, target_path):
    """递归添加文件到zip"""
    if os.path.isfile(source_path):
        # 如果是文件，直接添加到指定路径
        zipf.write(source_path, target_path)
    else:
        # 如果是目录，先创建目录本身
        try:
            info = zipfile.ZipInfo(target_path + '/')
            info.external_attr = 0o40775 << 16   # 设置目录权限
            zipf.writestr(info, '')
        except Exception as e:
            logger.info(f"创建目录失败: {str(e)}")

        # 递归添加目录内容
        for root, dirs, files in os.walk(source_path):
            # 获取相对路径
            relative_path = os.path.relpath(root, source_path)
            
            # 添加文件
            for file in files:
                source_file = os.path.join(root, file)
                # 如果是在根目录，直接放在目标目录下
                if relative_path == '.':
                    target_file = os.path.join(target_path, file)
                else:
                    # 否则保持相对路径结构
                    target_file = os.path.join(target_path, relative_path, file)
                # 统一路径分隔符
                target_file = target_file.replace('\\', '/')
                zipf.write(source_file, target_file) 