from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required
from models.user import User
from extensions import db
from logging import getLogger
logger = getLogger(__name__)

bp = Blueprint('auth', __name__)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method in ('GET', 'HEAD'):
        return render_template('login.html')
    
    if request.method == 'POST':
        try:
            data = request.get_json()
            username = data.get('username')
            password = data.get('password')
            
            if not username or not password:
                return jsonify({
                    'success': False,
                    'message': '用户名和密码不能为空'
                })
            
            user = User.query.filter_by(username=username).first()
            if user and user.verify_password(password):
                login_user(user)
                return jsonify({
                    'success': True,
                    'message': '登录成功'
                })
            
            return jsonify({
                'success': False,
                'message': '用户名或密码错误'
            })
            
        except Exception as e:
            logger.info(f"[Auth] 登录失败: {str(e)}")
            return jsonify({
                'success': False,
                'message': '登录失败，请稍后重试'
            })

@bp.route('/api/change_password', methods=['POST'])
@login_required
def change_password():
    try:
        data = request.get_json()
        username = data.get('username')
        old_password = data.get('old_password')
        new_password = data.get('new_password')
        
        if not all([username, old_password, new_password]):
            return jsonify({
                'success': False,
                'message': '所有字段都必须填写'
            })
        
        user = User.query.filter_by(username=username).first()
        if not user:
            return jsonify({
                'success': False,
                'message': '用户不存在'
            })
        
        if not user.verify_password(old_password):
            return jsonify({
                'success': False,
                'message': '原密码错误'
            })
        
        # 更新密码
        user.password = new_password
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': '密码修改成功'
        })
        
    except Exception as e:
        logger.info(f"[Auth] 修改密码失败: {str(e)}")
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': '修改密码失败，请稍后重试'
        })

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login')) 
