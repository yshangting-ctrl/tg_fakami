from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from models.advertisement import Advertisement
from extensions import db
from datetime import datetime

bp = Blueprint('advertisement', __name__)

@bp.route('/advertisements')
@login_required
def advertisements():
    return render_template('advertisements.html')

@bp.route('/api/advertisements', methods=['GET'])
@login_required
def get_advertisements():
    ads = Advertisement.query.order_by(Advertisement.created_at.desc()).all()
    return jsonify([ad.to_dict() for ad in ads])

@bp.route('/api/advertisements/<int:id>', methods=['GET'])
@login_required
def get_advertisement(id):
    ad = Advertisement.query.get_or_404(id)
    return jsonify(ad.to_dict())

@bp.route('/api/advertisements', methods=['POST'])
@login_required
def create_advertisement():
    data = request.json
    try:
        # 转换过期时间字符串为datetime对象
        expire_at = datetime.strptime(data['expire_at'], '%Y-%m-%dT%H:%M')
        
        ad = Advertisement(
            username=data['username'],
            description=data['description'],
            expire_at=expire_at,
            is_active=data.get('is_active', True)
        )
        
        db.session.add(ad)
        db.session.commit()
        
        return jsonify({
            'message': '广告创建成功',
            'advertisement': ad.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'广告创建失败: {str(e)}'}), 500

@bp.route('/api/advertisements/<int:id>', methods=['PUT'])
@login_required
def update_advertisement(id):
    ad = Advertisement.query.get_or_404(id)
    data = request.json
    
    try:
        ad.username = data['username']
        ad.description = data['description']
        ad.expire_at = datetime.strptime(data['expire_at'], '%Y-%m-%dT%H:%M')
        ad.is_active = data.get('is_active', True)
        
        db.session.commit()
        return jsonify({
            'message': '广告更新成功',
            'advertisement': ad.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'广告更新失败: {str(e)}'}), 500

@bp.route('/api/advertisements/<int:id>', methods=['DELETE'])
@login_required
def delete_advertisement(id):
    ad = Advertisement.query.get_or_404(id)
    try:
        db.session.delete(ad)
        db.session.commit()
        return jsonify({'message': '广告删除成功'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'广告删除失败: {str(e)}'}), 500

@bp.route('/api/advertisements/<int:id>/toggle', methods=['POST'])
@login_required
def toggle_advertisement(id):
    ad = Advertisement.query.get_or_404(id)
    try:
        ad.is_active = not ad.is_active
        db.session.commit()
        return jsonify({
            'message': f'广告已{"启用" if ad.is_active else "禁用"}',
            'is_active': ad.is_active
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'状态更新失败: {str(e)}'}), 500 