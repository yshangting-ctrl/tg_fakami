from flask import Blueprint, render_template, jsonify, request
from flask_login import login_required
from models.order import Order
from models.user import User
from models.product import Product
from sqlalchemy import func, and_
from datetime import datetime, timedelta
from extensions import db
from logging import getLogger
logger = getLogger(__name__)

bp = Blueprint('dashboard', __name__)

@bp.route('/')
@bp.route('/dashboard')
@login_required
def index():
    return render_template('dashboard.html')

@bp.route('/statistics')
@login_required
def statistics():
    return render_template('statistics.html')

@bp.route('/orders')
@login_required
def orders():
    return render_template('orders.html')

@bp.route('/api/dashboard/summary')
@login_required
def get_dashboard_summary():
    """获取控制面板摘要数据"""
    try:
        # 获取今天的时间范围（使用北京时间）
        today = datetime.now()  # 使用当前时间
        # 转换为UTC时间（北京时间减8小时）
        today_start = today.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(hours=8)
        today_end = today.replace(hour=23, minute=59, second=59, microsecond=999999) - timedelta(hours=8)
        
        logger.info(f"[Dashboard] 北京时间范围: {today_start + timedelta(hours=8)} - {today_end + timedelta(hours=8)}")
        logger.info(f"[Dashboard] UTC时间范围: {today_start} - {today_end}")
        
        # 先查询所有订单，不带状态过滤
        all_orders = Order.query.filter(
            Order.created_at.between(today_start, today_end)
        ).all()
        
        logger.info(f"[Dashboard] 今日所有订单: {len(all_orders)}")
        for order in all_orders:
            logger.info(f"[Dashboard] 订单ID: {order.id}, 状态: {order.status}, 创建时间(UTC): {order.created_at}, 创建时间(北京): {order.created_at + timedelta(hours=8)}, 金额: ${order.total_amount:.2f}")
        
        # 统计今日订单（已支付和已完成的）
        today_orders = Order.query.filter(
            and_(
                Order.created_at.between(today_start, today_end),
                Order.status.in_(['paid', 'completed'])
            )
        ).count()
        
        # 统计今日收入
        today_income = db.session.query(
            func.sum(Order.total_amount)
        ).filter(
            and_(
                Order.created_at.between(today_start, today_end),
                Order.status.in_(['paid', 'completed'])
            )
        ).scalar() or 0.0
        
        # 统计用户总数
        total_users = User.query.count()
        
        # 统计商品总数
        total_products = Product.query.count()
        
        # 获取最近订单
        recent_orders = Order.query.order_by(
            Order.created_at.desc()
        ).limit(10).all()
        
        response_data = {
            'today_orders': today_orders,
            'today_income': float(today_income),
            'total_users': total_users,
            'total_products': total_products,
            'recent_orders': [order.to_dict() for order in recent_orders]
        }
        
        logger.info(f"[Dashboard] 今日订单数: {today_orders}")
        logger.info(f"[Dashboard] 今日收入: ${today_income:.2f}")
        logger.info(f"[Dashboard] SQL查询: {db.session.query(Order).filter(Order.created_at.between(today_start, today_end)).statement}")
        
        return jsonify(response_data)
        
    except Exception as e:
        logger.info(f"获取控制面板摘要数据出错: {str(e)}")
        return jsonify({
            'error': '获取数据失败',
            'today_orders': 0,
            'today_income': 0.0,
            'total_users': 0,
            'total_products': 0,
            'recent_orders': []
        }), 500

@bp.route('/api/statistics/income')
@login_required
def get_income_statistics():
    """获取收入统计数据"""
    try:
        # 获取查询参数
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # 获取今日数据（使用北京时间）
        today = datetime.now()  # 使用当前时间
        # 转换为UTC时间（北京时间减8小时）
        today_start = today.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(hours=8)
        today_end = today.replace(hour=23, minute=59, second=59, microsecond=999999) - timedelta(hours=8)
        
        # 获取本月数据（UTC时间）
        month_start = today.replace(day=1, hour=0, minute=0, second=0, microsecond=0) - timedelta(hours=8)
        month_end = today_end
        
        # 如果指定了日期范围，转换为UTC时间
        query_start = month_start
        query_end = month_end
        if start_date:
            # 将输入的北京时间转换为UTC时间
            query_start = datetime.strptime(start_date, '%Y-%m-%d').replace(
                hour=0, minute=0, second=0, microsecond=0
            ) - timedelta(hours=8)
        if end_date:
            query_end = datetime.strptime(end_date, '%Y-%m-%d').replace(
                hour=23, minute=59, second=59, microsecond=999999
            ) - timedelta(hours=8)
        
        logger.info(f"[Statistics] 查询UTC时间范围: {query_start} - {query_end}")
        logger.info(f"[Statistics] 查询北京时间范围: {query_start + timedelta(hours=8)} - {query_end + timedelta(hours=8)}")
        
        # 获取今日统计数据
        today_stats = db.session.query(
            func.count(Order.id).label('order_count'),
            func.sum(Order.total_amount).label('total_income'),
            func.avg(Order.total_amount).label('avg_income')
        ).filter(
            and_(
                Order.created_at.between(today_start, today_end),
                Order.status.in_(['paid', 'completed'])
            )
        ).first() or (0, 0, 0)
        
        # 获取每日收入数据（使用UTC时间）
        daily_data = db.session.query(
            func.date(Order.created_at + timedelta(hours=8)).label('date'),  # 转换为北京时间
            func.sum(Order.total_amount).label('income'),
            func.count(Order.id).label('order_count')
        ).filter(
            and_(
                Order.created_at.between(query_start, query_end),
                Order.status.in_(['paid', 'completed'])
            )
        ).group_by(
            func.date(Order.created_at + timedelta(hours=8))  # 按北京时间分组
        ).order_by(
            func.date(Order.created_at + timedelta(hours=8))  # 按北京时间排序
        ).all() or []
        
        # 获取支付方式分布
        payment_data = db.session.query(
            Order.payment_type,
            func.sum(Order.total_amount).label('income'),
            func.count(Order.id).label('order_count')
        ).filter(
            and_(
                Order.created_at.between(query_start, query_end),
                Order.status.in_(['paid', 'completed'])
            )
        ).group_by(
            Order.payment_type
        ).all() or []
        
        # 计算总收入和总订单数
        total_income = sum(day[1] or 0 for day in daily_data)
        total_orders = sum(day[2] or 0 for day in daily_data)
        
        # 获取热门商品
        hot_products = db.session.query(
            Product.name,
            func.count(Order.id).label('order_count'),
            func.sum(Order.total_amount).label('total_income')
        ).join(
            Order, Order.product_id == Product.id
        ).filter(
            and_(
                Order.created_at.between(query_start, query_end),
                Order.status.in_(['paid', 'completed'])
            )
        ).group_by(
            Product.id,
            Product.name
        ).order_by(
            func.count(Order.id).desc()
        ).limit(10).all() or []
        
        # 构建返回数据
        response_data = {
            'today_stats': {
                'order_count': today_stats[0] or 0,
                'total_income': float(today_stats[1] or 0),
                'avg_income': float(today_stats[2] or 0)
            },
            'daily_income': [{
                'date': str(day[0]),
                'income': float(day[1] or 0),
                'order_count': int(day[2] or 0)
            } for day in daily_data],
            'payment_types': [{
                'type': str(payment[0]),
                'income': float(payment[1] or 0),
                'order_count': int(payment[2] or 0)
            } for payment in payment_data],
            'total_income': float(total_income),
            'total_orders': int(total_orders),
            'hot_products': [{
                'name': str(product[0]),
                'order_count': int(product[1] or 0),
                'total_income': float(product[2] or 0)
            } for product in hot_products]
        }
        
        logger.info(f"[Statistics] 今日统计: {response_data['today_stats']}")
        logger.info(f"[Statistics] 总收入: ${total_income:.2f}")
        logger.info(f"[Statistics] 总订单数: {total_orders}")
        logger.info(f"[Statistics] 每日数据: {response_data['daily_income']}")
        
        return jsonify(response_data)
        
    except Exception as e:
        logger.info(f"获取收入统计数据出错: {str(e)}")
        if hasattr(e, '__traceback__'):
            import traceback
            logger.info(traceback.format_exc())
        return jsonify({
            'error': '获取统计数据失败',
            'today_stats': {
                'order_count': 0,
                'total_income': 0.0,
                'avg_income': 0.0
            },
            'daily_income': [],
            'payment_types': [],
            'total_income': 0.0,
            'total_orders': 0,
            'hot_products': []
        }), 500

@bp.route('/products')
@login_required
def products():
    return render_template('products.html')

@bp.route('/categories')
@login_required
def categories():
    return render_template('categories.html')

@bp.route('/users')
@login_required
def users():
    return render_template('users.html')

@bp.route('/subordinates')
@login_required
def subordinates():
    return render_template('subordinates.html')

@bp.route('/advertisements')
@login_required
def advertisements():
    return render_template('advertisements.html') 