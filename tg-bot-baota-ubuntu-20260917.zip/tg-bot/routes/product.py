import os
import zipfile
import shutil
import random
import string
from flask import Blueprint, render_template, request, jsonify, current_app, send_file, after_this_request
from flask_login import login_required
from werkzeug.utils import secure_filename
from models.product import Product
from models.category import Category
from models.key import Key
from extensions import db
from datetime import datetime
from logging import getLogger
import tempfile
logger = getLogger(__name__)

bp = Blueprint('product', __name__)

# 确保上传目录存在
def ensure_upload_dir():
    upload_dir = os.path.join(current_app.static_folder, 'uploads', 'keys')
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)
    return upload_dir

# 创建商品密钥目录
def create_product_keys_dir():
    base_dir = ensure_upload_dir()
    product_dir = os.path.join(base_dir, f'product_{int(datetime.utcnow().timestamp())}')
    os.makedirs(product_dir)
    return product_dir

# 生成随机字母字符串
def generate_random_string(length=8):
    return ''.join(random.choices(string.ascii_letters, k=length))

def process_session_zip(zip_path):
    """
    处理包含session文件的ZIP包
    :param zip_path: ZIP文件路径
    :return: 处理的session文件数量
    """
    try:
        # 创建临时目录
        temp_dir = os.path.join(os.path.dirname(zip_path), 'processed_' + os.path.basename(zip_path).replace('.zip', ''))
        os.makedirs(temp_dir, exist_ok=True)
        logger.info(f"使用临时目录: {temp_dir}")

        session_files = []
        # 读取并处理ZIP文件
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # 获取所有文件列表
            all_files = [f for f in zip_ref.namelist() 
                        if not f.startswith('__MACOSX/') 
                        and not f.startswith('._')
                        and not '/._' in f]
            
            # 找出所有.session文件
            for file in all_files:
                if file.endswith('.session'):
                    session_name = os.path.splitext(os.path.basename(file))[0]
                    session_files.append({
                        'session_name': session_name,
                        'session_path': file,
                        'json_path': file.replace('.session', '.json')
                    })
            
            logger.info(f"发现 {len(session_files)} 个session文件")

            if len(session_files) == 0:
                return 0
            
            # 处理每个session文件
            for session_file in session_files:
                # 创建session目录
                session_dir = os.path.join(temp_dir, session_file['session_name'])
                os.makedirs(session_dir, exist_ok=True)
                
                # 复制session文件
                session_content = zip_ref.read(session_file['session_path'])
                session_dst = os.path.join(session_dir, os.path.basename(session_file['session_path']))
                with open(session_dst, 'wb') as f:
                    f.write(session_content)
                
                # 尝试复制json文件
                try:
                    if session_file['json_path'] in all_files:
                        json_content = zip_ref.read(session_file['json_path'])
                        json_dst = os.path.join(session_dir, os.path.basename(session_file['json_path']))
                        with open(json_dst, 'wb') as f:
                            f.write(json_content)
                except Exception as e:
                    logger.info(f"JSON文件不存在或复制失败: {session_file['json_path']}")

        # 创建新的ZIP文件
        temp_zip = zip_path + '.temp'
        with zipfile.ZipFile(temp_zip, 'w', zipfile.ZIP_DEFLATED) as zip_out:
            # 添加处理后的文件
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, temp_dir)
                    zip_out.write(file_path, arcname)
        
        # 替换原始ZIP文件
        os.remove(zip_path)
        os.rename(temp_zip, zip_path)
        
        logger.info(f"处理完成，已更新原始ZIP文件: {zip_path}")
        return len(session_files)
    
    except Exception as e:
        logger.error(f"处理ZIP文件时出错: {str(e)}")
        raise
    finally:
        # 清理临时目录
        if 'temp_dir' in locals() and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

@bp.route('/products/add')
@login_required
def add_product():
    return render_template('products/add.html')

@bp.route('/products')
@login_required
def products():
    return render_template('products.html')

@bp.route('/api/products', methods=['GET'])
@login_required
def get_products():
    products = Product.query.order_by(Product.sort_index.asc()).all()
    return jsonify([product.to_dict() for product in products])

@bp.route('/api/products', methods=['POST'])
@login_required
def create_product():
    try:
        # 获取表单数据
        name = request.form['name']
        price = float(request.form['price'])
        sort_index = int(request.form.get('sort_index', 0))
        category_id = int(request.form['category_id'])
        # checkbox选中时值为'on'，未选中时值为None
        is_dedup = request.form.get('is_dedup') == 'on'  # 是否去重
        is_same_key = request.form.get('is_same_key') == 'on'  # 是否为同一密钥

        logger.info("去重选项值: %s", request.form.get('is_dedup'))
        logger.info("处理后的去重状态: %s", is_dedup)
        
        # 检查分类是否存在
        category = Category.query.get_or_404(category_id)
        
        # 处理ZIP文件
        if 'keys_file' not in request.files:
            return jsonify({'message': '没有上传文件'}), 400
            
        file = request.files['keys_file']
        if file.filename == '':
            return jsonify({'message': '没有选择文件'}), 400
            
        if not (file.filename.endswith('.zip') or file.filename.endswith('.txt')):
            return jsonify({'message': '请上传ZIP或TXT格式的文件'}), 400
        
        # 创建商品密钥目录
        product_dir = create_product_keys_dir()
        
        # 获取文件扩展名（转换为小写以便比较）
        file_ext = os.path.splitext(file.filename)[1].lower()

        # 根据文件类型处理
        if file_ext == '.zip':
            # 保存ZIP文件
            zip_path = os.path.join(product_dir, secure_filename(file.filename))
            file.save(zip_path)
            
            # 处理ZIP文件
            try:
                session_count = process_session_zip(zip_path)
                logger.info(f"处理完成，发现 {session_count} 个session文件")
            except Exception as e:
                logger.error(f"处理ZIP文件失败: {str(e)}")
                if os.path.exists(zip_path):
                    os.remove(zip_path)
                raise

            # 解压文件
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(product_dir)
            
            # 删除ZIP文件
            os.remove(zip_path)
            
            # 递归获取所有文件夹（每个文件夹作为一个密钥）
            key_dirs = []
            for root, dirs, files in os.walk(product_dir):
                # 只处理直接子目录
                logger.info(f"处理目录: {root}")
                logger.info(f"处理目录: {dirs}")
                logger.info(f"处理目录: {files}")
                if root == product_dir:
                    key_dirs = [os.path.join(root, d) for d in dirs]
                    break
            
            if not key_dirs:
                shutil.rmtree(product_dir)
                return jsonify({'message': 'ZIP文件中没有密钥目录'}), 400

        elif file_ext == '.txt':
            # 读取TXT文件内容
            content = file.read().decode('utf-8')
            # 按行分割并过滤空行
            keys = [line.strip() for line in content.splitlines() if line.strip()]
            
            if not keys:
                shutil.rmtree(product_dir)
                return jsonify({'message': 'TXT文件中没有有效的密钥内容'}), 400
            
            # 创建商品记录
            product = Product(
                name=name,
                price=price,
                sort_index=sort_index,
                category_id=category_id,
                storage_path=product_dir,
                is_same_key=is_same_key,
                total_keys=len(keys),
                is_dedup=is_dedup
            )
            db.session.add(product)
            db.session.commit()
            
            try:
                # 如果需要去重，先收集所有内容
                used_contents = set()
                success_count = 0
                
                for i, key_content in enumerate(keys):
                    # 如果需要去重且内容已存在，则跳过
                    if is_dedup and key_content in used_contents:
                        continue
                    
                    used_contents.add(key_content)
                    
                    key = Key(
                        content=key_content,  # 直接使用行内容作为密钥
                        file_path='',  # txt格式不需要文件路径
                        file_name='',  # 使用内容作为文件名
                        product_id=product.id
                    )
                    db.session.add(key)
                    success_count += 1
                
                # 更新商品的密钥总数
                product.total_keys = success_count
                db.session.commit()
                
                return jsonify({
                    'message': '商品创建成功',
                    'id': product.id,
                    'total_keys': success_count
                })
                
            except Exception as e:
                # 如果创建密钥记录失败，回滚并删除商品记录
                db.session.rollback()
                db.session.delete(product)
                db.session.commit()
                raise e
            
            return
        
        else:
            shutil.rmtree(product_dir)
            return jsonify({'message': '不支持的文件格式，请上传ZIP或TXT文件'}), 400
        
        # 创建商品记录
        product = Product(
            name=name,
            price=price,
            sort_index=sort_index,
            category_id=category_id,
            storage_path=product_dir,
            is_same_key=is_same_key,
            total_keys=len(key_dirs),
            is_dedup=is_dedup  # 保存去重选项
        )
        db.session.add(product)
        # 先提交以获取商品ID
        db.session.commit()
        
        # 创建密钥记录
        try:
            # 如果需要去重，先收集所有目录名
            used_names = set()
            success_count = 0
            
            for key_dir in key_dirs:
                dir_name = os.path.basename(key_dir)
                
                # 如果需要去重且目录名已存在，则跳过
                if is_dedup and dir_name in used_names:
                    # 删除重复的目录
                    shutil.rmtree(key_dir)
                    continue
                
                # 如果不需要去重且目录名已存在，添加时间戳
                if not is_dedup and dir_name in used_names:
                    new_dir_name = f'{dir_name}_{int(datetime.utcnow().timestamp())}'
                    new_dir_path = os.path.join(os.path.dirname(key_dir), new_dir_name)
                    os.rename(key_dir, new_dir_path)
                    dir_name = new_dir_name
                    key_dir = new_dir_path
                
                used_names.add(dir_name)
                
                key = Key(
                    content=dir_name,  # 使用目录名作为密钥内容
                    file_path=key_dir,
                    file_name=dir_name,
                    product_id=product.id
                )
                db.session.add(key)
                success_count += 1
            
            # 更新商品的密钥总数
            product.total_keys = success_count
            
            # 提交密钥记录
            db.session.commit()
            
            return jsonify({
                'message': '商品创建成功',
                'id': product.id,
                'total_keys': success_count
            })
            
        except Exception as e:
            # 如果创建密钥记录失败，回滚并删除商品记录
            db.session.rollback()
            db.session.delete(product)
            db.session.commit()
            raise e
        
    except Exception as e:
        if 'product_dir' in locals() and os.path.exists(product_dir):
            shutil.rmtree(product_dir)
        db.session.rollback()
        return jsonify({'message': f'商品创建失败: {str(e)}'}), 500

@bp.route('/api/products/<int:id>', methods=['DELETE'])
@login_required
def delete_product(id):
    product = Product.query.get_or_404(id)
    try:
        # 先删除所有关联的密钥记录
        Key.query.filter_by(product_id=id).delete()
        
        # 删除密钥文件目录
        if os.path.exists(product.storage_path):
            shutil.rmtree(product.storage_path)
        
        # 删除商品记录
        db.session.delete(product)
        db.session.commit()
        return jsonify({'message': '商品删除成功'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'商品删除失败: {str(e)}'}), 500

@bp.route('/api/products/<int:id>/toggle', methods=['POST'])
@login_required
def toggle_product(id):
    product = Product.query.get_or_404(id)
    product.is_active = not product.is_active
    try:
        db.session.commit()
        return jsonify({'message': f'商品已{"启用" if product.is_active else "禁用"}'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'状态更新失败: {str(e)}'}), 500

@bp.route('/api/products/<int:product_id>/keys', methods=['GET'])
@login_required
def get_product_keys(product_id):
    product = Product.query.get_or_404(product_id)
    keys = Key.query.filter_by(product_id=product_id).order_by(Key.created_at.desc()).all()
    return jsonify([key.to_dict() for key in keys])

@bp.route('/api/products/<int:product_id>/keys/<int:key_id>', methods=['DELETE'])
@login_required
def delete_product_key(product_id, key_id):
    key = Key.query.filter_by(id=key_id, product_id=product_id).first_or_404()
    if key.is_used:
        return jsonify({'message': '已使用的密钥不能删除'}), 400
    
    try:
        # 删除密钥目录
        if os.path.exists(key.file_path):
            shutil.rmtree(key.file_path)
        
        # 删除数据库记录
        db.session.delete(key)
        product = Product.query.get(product_id)
        product.total_keys -= 1
        db.session.commit()
        return jsonify({'message': '密钥删除成功'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'密钥删除失败: {str(e)}'}), 500

@bp.route('/api/products/<int:product_id>/keys/batch', methods=['POST'])
@login_required
def batch_upload_keys(product_id):
    product = Product.query.get_or_404(product_id)
    is_dedup = False
    is_same_key = request.form.get('is_same_key') == 'on'  # 是否为同一密钥

    logger.info(f"去重选项: {is_dedup}")
    logger.info(f"是否为同一密钥: {is_same_key}")
    
    if 'keys_file' not in request.files:
        return jsonify({'message': '没有上传文件'}), 400
        
    file = request.files['keys_file']
    if file.filename == '':
        return jsonify({'message': '没有选择文件'}), 400
        
    if not file.filename.endswith('.zip') and not file.filename.endswith('.txt'):
        return jsonify({'message': '请上传ZIP或TXT格式的文件'}), 400
    
    try:
        # 创建临时目录
        temp_dir = os.path.join(current_app.static_folder, 'temp', f'upload_{int(datetime.utcnow().timestamp())}')
        os.makedirs(temp_dir, exist_ok=True)
        
        # 获取文件扩展名（转换为小写以便比较）
        file_ext = os.path.splitext(file.filename)[1].lower()
        
        if file_ext == '.zip':
            # 保存ZIP文件
            zip_path = os.path.join(temp_dir, secure_filename(file.filename))
            file.save(zip_path)

            # 处理ZIP文件
            try:
                session_count = process_session_zip(zip_path)
                logger.info(f"处理完成，发现 {session_count} 个session文件")
            except Exception as e:
                logger.error(f"处理ZIP文件失败: {str(e)}")
                if os.path.exists(zip_path):
                    os.remove(zip_path)
                raise
            
            # 先获取ZIP文件中的目录列表
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # 获取所有文件和目录
                all_entries = zip_ref.namelist()
                # 获取第一级目录
                root_dirs = set()
                for entry in all_entries:
                    parts = entry.split('/')
                    if len(parts) > 1:  # 至少包含一个目录
                        root_dirs.add(parts[0])
            
            if not root_dirs:
                return jsonify({'message': 'ZIP文件中没有密钥目录'}), 400

        elif file_ext == '.txt':
            # 读取TXT文件内容
            content = file.read().decode('utf-8')
            # 按行分割并过滤空行
            keys = [line.strip() for line in content.splitlines() if line.strip()]
            
            if not keys:
                return jsonify({'message': 'TXT文件中没有有效的密钥内容'}), 400

            # 创建密钥记录
            success_count = 0
            used_contents = set()  # 用于去重

            for key_content in keys:
                # 如果需要去重且内容已存在，则跳过
                if is_dedup and key_content in used_contents:
                    continue
                
                used_contents.add(key_content)
                
                key = Key(
                    content=key_content,  # 直接使用行内容作为密钥
                    file_path='',  # txt格式不需要文件路径
                    file_name='',  # 使用内容作为文件名
                    product_id=product_id
                )
                db.session.add(key)
                product.total_keys += 1
                success_count += 1

            db.session.commit()
            return jsonify({
                'message': f'成功导入 {success_count} 个密钥',
                'total_keys': product.total_keys
            })
        
        # 获取已有的密钥名称（不管是否去重都需要获取）
        existing_keys = Key.query.filter_by(product_id=product_id).all()
        # 获取基础名称（不包含随机后缀）
        existing_base_names = {key.file_name.split('_')[0] for key in existing_keys}
        logger.info(f"现有的基础名称: {existing_base_names}")
        
        # 处理每个目录名
        dir_mapping = {}  # 原始名称 -> 新名称的映射
        used_names = set()  # 用于跟重模式下跟踪已使用的名称
        
        for dir_name in root_dirs:
            logger.info(f'处理目录: {dir_name}')
            
            if is_dedup:
                # 去重模式：如果名称已使用过，直接跳过
                if dir_name in used_names or dir_name in existing_base_names:
                    logger.info(f'去重模式：跳过重复目录: {dir_name}')
                    continue
                final_name = dir_name
                used_names.add(dir_name)
            else:
                # 非去重模式：直接添加随机后缀
                random_suffix = generate_random_string(8)
                final_name = f'{dir_name}_{random_suffix}'
                logger.info(f'非去重模式：重命名目录: {dir_name} -> {final_name}')
            
            dir_mapping[dir_name] = final_name
            logger.info(f'添加映射: {dir_name} -> {final_name}')
        
        # 解压文件，重命名目录
        success_count = 0
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            for dir_name, final_name in dir_mapping.items():
                try:
                    # 创建目标目录
                    dst_dir = os.path.join(product.storage_path, final_name)
                    os.makedirs(dst_dir, exist_ok=True)
                    logger.info(f'创建目录: {dst_dir}')
                    
                    # 先创建所有目录结构
                    dir_entries = [e for e in all_entries if e.startswith(f'{dir_name}/')]
                    for entry in dir_entries:
                        rel_path = entry[len(dir_name)+1:]  # 移除原始目录名和斜杠
                        if rel_path:
                            full_path = os.path.join(dst_dir, rel_path.replace('/', os.path.sep))
                            # 如果是目录（以/结尾）
                            if entry.endswith('/'):
                                os.makedirs(full_path, exist_ok=True)
                                logger.info(f'创建子目录: {full_path}')
                    
                    # 然后复制所有文件
                    for entry in dir_entries:
                        try:
                            rel_path = entry[len(dir_name)+1:]  # 移除原始目录名和斜杠
                            if rel_path and not entry.endswith('/'):  # 不是目录
                                # 读取文件内容
                                content = zip_ref.read(entry)
                                # 计算新的路径
                                dst_path = os.path.join(dst_dir, rel_path.replace('/', os.path.sep))
                                # 写入文件
                                with open(dst_path, 'wb') as f:
                                    f.write(content)
                        except Exception as e:
                            pass
                            continue
                    
                    # 创建密钥记录
                    key = Key(
                        content=final_name,  # 使用目录名作为密钥内容
                        file_path=dst_dir,
                        file_name=final_name,
                        product_id=product_id
                    )
                    db.session.add(key)
                    product.total_keys += 1
                    success_count += 1
                    logger.info(f'添加密钥记录: {final_name}')
                except Exception as e:
                    logger.info(f'处理目录失败: {dir_name}, 错误: {str(e)}')
                    # 如果处理失败，清理已创建的目录
                    if os.path.exists(dst_dir):
                        shutil.rmtree(dst_dir)
                    continue
        
        db.session.commit()
        return jsonify({
            'message': f'成功导入 {success_count} 个密钥',
            'total_keys': product.total_keys
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'批量导入失败: {str(e)}'}), 500
    finally:
        # 清理临时目录
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

# 下载密钥文件
@bp.route('/api/products/<int:product_id>/keys/<int:key_id>/download', methods=['GET'])
@login_required
def download_key_file(product_id, key_id):
    key = Key.query.filter_by(id=key_id, product_id=product_id).first_or_404()
    if not os.path.exists(key.file_path):
        return jsonify({'message': '密钥文件不存在'}), 404

    try:
        # 创建临时目录用于存放ZIP文件
        temp_dir = os.path.join(current_app.static_folder, 'temp')
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)

        # 创建ZIP文件
        zip_filename = f'{key.file_name}.zip'
        zip_path = os.path.join(temp_dir, zip_filename)

        # 将密钥目录打包成ZIP
        shutil.make_archive(
            os.path.join(temp_dir, key.file_name),  # ZIP文件路径（不包含.zip后缀）
            'zip',  # 压缩格式
            key.file_path  # 要压缩的目录
        )

        @after_this_request
        def remove_file(response):
            try:
                os.remove(zip_path)
            except Exception as e:
                logger.info(f'清理临时文件失败: {str(e)}')
            return response

        # 发送给前端时设置别名（用_前面的部分）
        # 例如: file_name = "abc_def" -> alias = "abc"
        if "_" in key.file_name:
            alias = key.file_name.split("_")[0]
        else:
            alias = key.file_name
        download_name = f"{alias}.zip"

        return send_file(
            zip_path,
            as_attachment=True,
            download_name=download_name
        )

    except Exception as e:
        return jsonify({'message': f'下载失败: {str(e)}'}), 500 

@bp.route('/products/edit')
@login_required
def edit_product():
    return render_template('products/edit.html')

@bp.route('/api/products/<int:id>', methods=['GET'])
@login_required
def get_product(id):
    product = Product.query.get_or_404(id)
    return jsonify(product.to_dict())

@bp.route('/api/products/<int:id>', methods=['PUT'])
@login_required
def update_product(id):
    product = Product.query.get_or_404(id)
    try:
        # 获取表单数据
        product.name = request.form['name']
        product.price = float(request.form['price'])
        product.description = request.form.get('description', '')
        product.sort_index = int(request.form.get('sort_index', 0))
        product.category_id = int(request.form['category_id'])
        product.is_dedup = request.form.get('is_dedup') == 'on'
        product.is_same_key = request.form.get('is_same_key') == 'on'

        logger.info(request.form.get('is_dedup'))

        logger.info(f"商品更新成功: {product.is_same_key}")
        logger.info(f"商品更新成功: {product.is_dedup}")
        
        db.session.commit()
        return jsonify({'message': '商品更新成功'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'商品更新失败: {str(e)}'}), 500 

@bp.route('/api/products/<int:product_id>/keys/batch/delete', methods=['POST'])
@login_required
def batch_delete_keys(product_id):
    try:
        data = request.get_json()
        key_ids = data.get('key_ids', [])
        
        if not key_ids:
            return jsonify({'message': '没有选择要删除的密钥'}), 400
            
        # 获取所有要删除的密钥
        keys = Key.query.filter(
            Key.id.in_(key_ids),
            Key.product_id == product_id
        ).all()
        
        # 检查是否有已使用的密钥
        used_keys = [key for key in keys if key.is_used]
        if used_keys:
            return jsonify({'message': '选中的密钥中包含已使用的密钥，无法删除'}), 400
            
        deleted_count = 0
        for key in keys:
            # 删除密钥目录
            if os.path.exists(key.file_path):
                shutil.rmtree(key.file_path)
            
            # 删除数据库记录
            db.session.delete(key)
            deleted_count += 1
        
        # 更新商品的密钥总数
        product = Product.query.get(product_id)
        product.total_keys -= deleted_count
        
        db.session.commit()
        return jsonify({'message': f'成功删除 {deleted_count} 个密钥'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'批量删除失败: {str(e)}'}), 500

@bp.route('/api/products/<int:product_id>/keys/batch/download', methods=['POST'])
@login_required
def batch_download_keys(product_id):
    try:
        data = request.get_json()
        key_ids = data.get('key_ids', [])
        
        if not key_ids:
            return jsonify({'message': '没有选择要下载的密钥'}), 400
            
        # 获取所有要下载的密钥
        keys = Key.query.filter(
            Key.id.in_(key_ids),
            Key.product_id == product_id
        ).all()
        
        # 检查是否所有密钥都是文本格式（没有file_name）
        all_text = all(not key.file_name for key in keys)
        
        # 创建临时目录
        temp_dir = tempfile.mkdtemp()
        
        if all_text:
            # 如果全是文本格式，创建txt文件
            txt_filename = f'keys_{product_id}.txt'
            txt_path = os.path.join(temp_dir, txt_filename)
            
            # 写入所有密钥内容
            with open(txt_path, 'w', encoding='utf-8') as f:
                for key in keys:
                    f.write(f"{key.content}\n")
            
            @after_this_request
            def remove_file(response):
                try:
                    shutil.rmtree(temp_dir)
                except Exception as e:
                    print(f'Error removing temp file: {e}')
                return response
            
            return send_file(
                txt_path,
                as_attachment=True,
                download_name=txt_filename,
                mimetype='text/plain'
            )
        else:
            # 如果包含目录格式的密钥，创建ZIP文件
            zip_filename = f'keys_{product_id}.zip'
            zip_path = os.path.join(temp_dir, zip_filename)
            
            # 创建ZIP文件
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for key in keys:
                    if os.path.exists(key.file_path):
                        # 取 file_name 下划线前面的部分作为文件夹名
                        folder_name = key.file_name.split('_')[0] if '_' in key.file_name else key.file_name
                        for root, dirs, files in os.walk(key.file_path):
                            for file in files:
                                file_path = os.path.join(root, file)
                                rel_path = os.path.relpath(file_path, key.file_path)
                                arcname = os.path.join(folder_name, rel_path)
                                zipf.write(file_path, arcname)
        
        # 发送文件
        @after_this_request
        def remove_file(response):
            try:
                shutil.rmtree(temp_dir)
            except Exception as e:
                print(f'Error removing temp file: {e}')
            return response
            
        return send_file(
            zip_path,
            as_attachment=True,
            download_name=zip_filename,
            mimetype='application/zip'
        )
        
    except Exception as e:
        if 'temp_dir' in locals():
            shutil.rmtree(temp_dir)
        return jsonify({'message': f'批量下载失败: {str(e)}'}), 500 