from flask import Blueprint, jsonify, request, send_file, current_app, render_template
from flask_login import login_required
import os
import re
from datetime import datetime
import logging
import shutil
import time

bp = Blueprint('logs', __name__)

def get_log_dir():
    """获取日志目录路径"""
    # 使用相对路径获取 logs 目录（相对于当前文件）
    base_dir = os.path.abspath(os.path.dirname(__file__))
    log_dir = os.path.abspath(os.path.join(base_dir, '../logs'))
    return log_dir

@bp.route('/logs')
@login_required
def logs():
    """日志查看页面"""
    return render_template('logs.html')

@bp.route('/api/logs')
@login_required
def get_logs():
    """获取日志内容"""
    try:
        # 获取查询参数
        log_file = request.args.get('file', 'app.log')
        level_filter = request.args.get('level', 'all')
        line_count = int(request.args.get('lines', 50))
        show_debug = request.args.get('debug', 'false').lower() == 'true'
        
        # 验证文件名，防止路径遍历攻击
        allowed_files = ['app.log', 'bot.log', 'payment.log']
        if log_file not in allowed_files:
            return jsonify({'success': False, 'message': '无效的日志文件名'})
        
        # 构建日志文件路径
        log_dir = get_log_dir()
        log_path = os.path.join(log_dir, log_file)
        
        if not os.path.exists(log_path):
            return jsonify({'success': False, 'message': '日志文件不存在'})
        
        # 读取日志文件
        with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        # 过滤日志级别和调试信息
        if level_filter != 'all':
            filtered_lines = []
            for line in lines:
                if re.search(rf'\b{level_filter}\b', line, re.IGNORECASE):
                    filtered_lines.append(line)
            lines = filtered_lines
        
        # 过滤掉一些无用的调试信息
        if not show_debug:
            useful_lines = []
            for line in lines:
                # 跳过一些无用的调试信息
                skip_patterns = [
                    r'Received 0 new updates',
                    r'Task complete',
                    r'Received task',
                    r'Starting new HTTPS connection',
                    r'The server returned:',
                    r'Request: method=',
                    r'Press CTRL\+C to quit',
                    r'WARNING: This is a development server',
                    r'Running on all addresses',
                    r'Running on http://'
                ]
                
                should_skip = False
                for pattern in skip_patterns:
                    if re.search(pattern, line):
                        should_skip = True
                        break
                
                if not should_skip:
                    useful_lines.append(line)
            
            lines = useful_lines
        
        # 获取指定行数
        if len(lines) > line_count:
            lines = lines[-line_count:]
        
        # 合并日志内容
        log_content = ''.join(lines)
        
        return jsonify({
            'success': True,
            'logs': log_content,
            'total_lines': len(lines),
            'file_size': os.path.getsize(log_path)
        })
        
    except Exception as e:
        current_app.logger.error(f"读取日志失败: {str(e)}")
        return jsonify({'success': False, 'message': f'读取日志失败: {str(e)}'})

@bp.route('/api/logs/clear', methods=['POST'])
@login_required
def clear_log():
    """清空日志文件"""
    try:
        log_file = request.args.get('file', 'app.log')
        
        # 验证文件名
        allowed_files = ['app.log', 'bot.log', 'payment.log']
        if log_file not in allowed_files:
            return jsonify({'success': False, 'message': '无效的日志文件名'})
        
        # 构建日志文件路径
        log_dir = get_log_dir()
        log_path = os.path.join(log_dir, log_file)
        
        if not os.path.exists(log_path):
            return jsonify({'success': False, 'message': '日志文件不存在'})
        
        # 备份原文件，处理 Windows 下文件被占用的情况
        backup_path = f"{log_path}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        backup_success = False
        last_exception = None
        for i in range(3):
            try:
                # 尝试复制而不是重命名，避免被占用时报错
                shutil.copy2(log_path, backup_path)
                backup_success = True
                break
            except Exception as e:
                last_exception = e
                time.sleep(0.5)  # 等待一会儿再试
        if not backup_success:
            current_app.logger.error(f"备份日志文件失败: {str(last_exception)}")
            return jsonify({'success': False, 'message': f'备份日志文件失败: {str(last_exception)}'})

        # 清空原文件内容
        try:
            with open(log_path, 'w', encoding='utf-8') as f:
                f.write(f"# 日志文件清空于 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        except Exception as e:
            current_app.logger.error(f"清空日志内容失败: {str(e)}")
            return jsonify({'success': False, 'message': f'清空日志内容失败: {str(e)}'})

        current_app.logger.info(f"日志文件 {log_file} 已清空")
        
        return jsonify({
            'success': True,
            'message': f'日志文件 {log_file} 已清空',
            'backup_file': os.path.basename(backup_path)
        })
        
    except Exception as e:
        current_app.logger.error(f"清空日志失败: {str(e)}")
        return jsonify({'success': False, 'message': f'清空日志失败: {str(e)}'})

@bp.route('/api/logs/download')
@login_required
def download_log():
    """下载日志文件"""
    try:
        log_file = request.args.get('file', 'app.log')
        
        # 验证文件名
        allowed_files = ['app.log', 'bot.log', 'payment.log']
        if log_file not in allowed_files:
            return jsonify({'success': False, 'message': '无效的日志文件名'})
        
        # 构建日志文件路径
        log_dir = get_log_dir()
        log_path = os.path.join(log_dir, log_file)
        
        if not os.path.exists(log_path):
            return jsonify({'success': False, 'message': '日志文件不存在'})
        
        # 生成下载文件名
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        download_filename = f"{log_file.replace('.log', '')}_{timestamp}.log"
        
        return send_file(
            log_path,
            as_attachment=True,
            download_name=download_filename,
            mimetype='text/plain'
        )
        
    except Exception as e:
        current_app.logger.error(f"下载日志失败: {str(e)}")
        return jsonify({'success': False, 'message': f'下载日志失败: {str(e)}'})

@bp.route('/api/logs/info')
@login_required
def get_log_info():
    """获取日志文件信息"""
    try:
        log_files = ['app.log', 'bot.log', 'payment.log']
        log_info = {}
        
        for log_file in log_files:
            log_dir = get_log_dir()
            log_path = os.path.join(log_dir, log_file)
            
            if os.path.exists(log_path):
                stat = os.stat(log_path)
                log_info[log_file] = {
                    'exists': True,
                    'size': stat.st_size,
                    'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                    'size_mb': round(stat.st_size / (1024 * 1024), 2)
                }
            else:
                log_info[log_file] = {
                    'exists': False,
                    'size': 0,
                    'modified': None,
                    'size_mb': 0
                }
        
        return jsonify({
            'success': True,
            'log_info': log_info
        })
        
    except Exception as e:
        current_app.logger.error(f"获取日志信息失败: {str(e)}")
        return jsonify({'success': False, 'message': f'获取日志信息失败: {str(e)}'}) 