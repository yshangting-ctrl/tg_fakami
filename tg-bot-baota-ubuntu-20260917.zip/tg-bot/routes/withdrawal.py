from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from models.withdrawal import Withdrawal
from models.user import User
from models.balance_log import BalanceLog
from extensions import db
from datetime import datetime
from logging import getLogger
logger = getLogger(__name__)

bp = Blueprint('withdrawal', __name__)

@bp.route('/withdrawals')
@login_required
def withdrawals():
    return render_template('withdrawals.html')

@bp.route('/api/withdrawals', methods=['GET'])
@login_required
def get_withdrawals():
    # 获取查询参数
    status = request.args.get('status')
    user_id = request.args.get('user_id')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    # 构建查询
    query = Withdrawal.query
    
    if status:
        query = query.filter(Withdrawal.status == status)
    if user_id:
        query = query.filter(Withdrawal.user_id == user_id)
    if start_date:
        query = query.filter(Withdrawal.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        query = query.filter(Withdrawal.created_at < datetime.strptime(end_date, '%Y-%m-%d'))
    
    # 按创建时间倒序排序
    withdrawals = query.order_by(Withdrawal.created_at.desc()).all()
    return jsonify([w.to_dict() for w in withdrawals])

@bp.route('/api/withdrawals/<int:id>/<string:action>', methods=['POST'])
@login_required
def process_withdrawal(id, action):
    """处理提现申请
    Args:
        id: 提现记录ID
        action: approve/reject
    """
    try:
        withdrawal = db.session.get(Withdrawal, id)
        if not withdrawal:
            return jsonify({'message': '提现记录不存在'}), 404
        
        if withdrawal.status != 'pending':
            return jsonify({'message': '只能处理待处理的提现申请'}), 400
        
        data = request.get_json()
        remark = data.get('remark', '')
        
        # 获取用户信息
        user = User.query.filter_by(
            telegram_id=withdrawal.user_id,
            bot_username=withdrawal.bot_username
        ).first()
        
        if not user:
            return jsonify({'message': '用户不存在'}), 404
        
        if action == 'approve':
            # 通过提现申请
            withdrawal.status = 'approved'
            withdrawal.remark = remark
            
            # 发送通知给用户
            from bot.bot_manager import bot_manager
            bot = bot_manager.get_bot(withdrawal.bot_username)
            if bot:
                msg = f"✅ 提现申请已通过\n\n"
                msg += f"金额：${withdrawal.amount:.2f}\n"
                msg += f"地址：{withdrawal.address}\n"
                msg += f"备注：{remark}\n"
                msg += f"处理时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                try:
                    bot.bot.send_message(withdrawal.user_id, msg)
                    bot_manager.stop_bot(withdrawal.bot_username)
                except Exception as e:
                    logger.info(f"发送提现通知失败: {str(e)}")
            else:
                logger.info(f"机器人 {withdrawal.bot_username} 不存在或未启动")
            
        elif action == 'reject':
            # 驳回提现申请
            withdrawal.status = 'rejected'
            withdrawal.remark = remark
            
            # 返还用户余额
            user.balance += withdrawal.amount
            
            # 添加余额变动记录
            balance_log = BalanceLog(
                username=user.username,
                telegram_id=user.telegram_id,
                bot_username=withdrawal.bot_username,
                type='increase',
                amount=withdrawal.amount,
                balance=user.balance,
                description=f'提现驳回返还: {withdrawal.amount} USDT'
            )
            db.session.add(balance_log)
            
            # 发送通知给用户
            from bot.bot_manager import bot_manager
            bot = bot_manager.get_bot(withdrawal.bot_username)
            if bot:
                msg = f"❌ 提现申请已驳回\n\n"
                msg += f"金额：${withdrawal.amount:.2f}\n"
                msg += f"地址：{withdrawal.address}\n"
                msg += f"原因：{remark}\n"
                msg += f"处理时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                msg += "💰 余额已返还到您的账户"
                try:
                    bot.bot.send_message(withdrawal.user_id, msg)
                    bot_manager.stop_bot(withdrawal.bot_username)
                except Exception as e:
                    logger.info(f"发送提现通知失败: {str(e)}")
            else:
                logger.info(f"机器人 {withdrawal.bot_username} 不存在或未启动")
        
        db.session.commit()
        return jsonify({'message': '处理成功'})
        
    except Exception as e:
        logger.info(f"处理提现申请出错: {str(e)}")
        if hasattr(e, '__traceback__'):
            import traceback
            logger.info(traceback.format_exc())
        db.session.rollback()
        return jsonify({'message': '处理失败'}), 500 