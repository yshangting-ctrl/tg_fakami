from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from models.balance_log import BalanceLog
from extensions import db
from datetime import datetime

bp = Blueprint('balance_log', __name__)

@bp.route('/balance_logs')
@login_required
def balance_logs():
    return render_template('balance_logs.html')

@bp.route('/api/balance_logs', methods=['GET'])
@login_required
def get_balance_logs():
    # 获取查询参数
    username = request.args.get('username')
    telegram_id = request.args.get('telegram_id')
    type = request.args.get('type')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    # 构建查询
    query = BalanceLog.query
    
    if username:
        query = query.filter(BalanceLog.username.like(f'%{username}%'))
    if telegram_id:
        query = query.filter(BalanceLog.telegram_id == telegram_id)
    if type:
        query = query.filter(BalanceLog.type == type)
    if start_date:
        query = query.filter(BalanceLog.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        query = query.filter(BalanceLog.created_at < datetime.strptime(end_date, '%Y-%m-%d'))
    
    # 按创建时间倒序排序
    logs = query.order_by(BalanceLog.created_at.desc()).all()
    return jsonify([log.to_dict() for log in logs]) 