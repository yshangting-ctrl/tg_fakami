from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from models.category import Category
from extensions import db

bp = Blueprint('category', __name__)

@bp.route('/categories')
@login_required
def categories():
    return render_template('categories.html')

@bp.route('/api/categories', methods=['GET'])
@login_required
def get_categories():
    categories = Category.query.order_by(Category.sort_index.asc()).all()
    return jsonify([category.to_dict() for category in categories])

@bp.route('/api/categories', methods=['POST'])
@login_required
def create_category():
    data = request.json
    category = Category(
        name=data['name'],
        description=data.get('description', ''),
        sort_index=data.get('sort_index', 0)
    )
    
    # 添加上级分类关联
    parent_ids = data.get('parent_categories', [])
    for parent_id in parent_ids:
        if parent_id:
            parent = Category.query.get(parent_id)
            if parent:
                category.parents.append(parent)
    
    try:
        db.session.add(category)
        db.session.commit()
        return jsonify({'message': '分类创建成功', 'id': category.id})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'分类创建失败: {str(e)}'}), 500

@bp.route('/api/categories/<int:id>', methods=['PUT'])
@login_required
def update_category(id):
    category = Category.query.get_or_404(id)
    data = request.json
    
    category.name = data['name']
    category.description = data.get('description', '')
    category.sort_index = data.get('sort_index', 0)
    
    # 更新上级分类关联
    category.parents = []
    parent_ids = data.get('parent_categories', [])
    for parent_id in parent_ids:
        if parent_id:
            parent = Category.query.get(parent_id)
            if parent:
                category.parents.append(parent)
    
    try:
        db.session.commit()
        return jsonify({'message': '分类更新成功'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'分类更新失败: {str(e)}'}), 500

@bp.route('/api/categories/<int:id>', methods=['DELETE'])
@login_required
def delete_category(id):
    category = Category.query.get_or_404(id)
    try:
        db.session.delete(category)
        db.session.commit()
        return jsonify({'message': '分类删除成功'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'分类删除失败: {str(e)}'}), 500 