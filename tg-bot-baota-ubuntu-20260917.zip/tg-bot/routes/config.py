from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from models.config import BotConfig
from extensions import db
from logging import getLogger
logger = getLogger(__name__)

bp = Blueprint('config', __name__)

@bp.route('/machines')
@login_required
def machines():
    return render_template('machines.html')

@bp.route('/api/bot_configs', methods=['GET'])
@login_required
def get_bot_configs():
    configs = BotConfig.query.order_by(BotConfig.created_at.desc()).all()
    return jsonify([config.to_dict() for config in configs])

@bp.route('/api/bot_configs/<int:id>', methods=['GET'])
@login_required
def get_bot_config(id):
    config = BotConfig.query.get_or_404(id)
    return jsonify(config.to_dict())

@bp.route('/api/bot_configs', methods=['POST'])
@login_required
def create_bot_config():
    data = request.json
    config = BotConfig(
        bot_username=data['bot_username'],
        bot_token=data['bot_token'],
        recharge_address=data['recharge_address'],
        admin_usernames=data['admin_usernames'],
        epay_pid=data['epay_pid'],
        usdt_rate=data['usdt_rate'],
        epay_key=data['epay_key'],
        okpay_id=data.get('okpay_id'),
        okpay_key=data.get('okpay_key'),
        fll_id=data.get('fll_id'),
        fll_key=data.get('fll_key'),
        backend_url=data['backend_url'],
        announcement=data.get('announcement', ''),
        is_active=data.get('is_active', True),
        allow_clone=data.get('allow_clone', True)
    )
    
    try:
        db.session.add(config)
        db.session.commit()
        return jsonify({'message': '配置创建成功', 'id': config.id})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'配置创建失败: {str(e)}'}), 500

@bp.route('/api/bot_configs/<int:id>', methods=['PUT'])
@login_required
def update_bot_config(id):
    config = BotConfig.query.get_or_404(id)
    data = request.json

    logger.info(data.get('allow_clone', True))
    
    config.bot_username = data['bot_username']
    config.bot_token = data['bot_token']
    config.recharge_address = data['recharge_address']
    config.admin_usernames = data['admin_usernames']
    config.epay_pid = data['epay_pid']
    config.epay_key = data['epay_key']
    config.backend_url = data['backend_url']
    config.usdt_rate = data['usdt_rate']
    config.okpay_id = data.get('okpay_id')
    config.okpay_key = data.get('okpay_key')
    config.fll_id = data.get('fll_id')
    config.fll_key = data.get('fll_key')
    config.announcement = data.get('announcement', '')
    config.is_active = data.get('is_active', True)
    config.allow_clone = data.get('allow_clone', True)
    
    try:
        db.session.commit()
        return jsonify({'message': '配置更新成功'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'配置更新失败: {str(e)}'}), 500

@bp.route('/api/bot_configs/<int:id>', methods=['DELETE'])
@login_required
def delete_bot_config(id):
    config = BotConfig.query.get_or_404(id)
    try:
        db.session.delete(config)
        db.session.commit()
        return jsonify({'message': '配置删除成功'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'配置删除失败: {str(e)}'}), 500

@bp.route('/api/bot_configs/<int:id>/toggle', methods=['POST'])
@login_required
def toggle_bot_config(id):
    config = BotConfig.query.get_or_404(id)
    config.is_active = not config.is_active
    try:
        db.session.commit()
        return jsonify({'message': f'机器人已{"启用" if config.is_active else "禁用"}'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'状态更新失败: {str(e)}'}), 500 