from flask import Blueprint, render_template, jsonify, request, current_app
from flask_login import login_required, current_user
from models.user import User
from models.config import BotConfig
from extensions import db
from bot.broadcast_service import BroadcastService
import json
from logging import getLogger
logger = getLogger(__name__)

bp = Blueprint('broadcast', __name__)
broadcast_service = BroadcastService()

@bp.route('/broadcast')
@login_required
def broadcast():
    """群发页面"""
    return render_template('broadcast.html')

@bp.route('/api/broadcast/bots')
@login_required
def get_bots():
    """获取机器人列表"""
    try:
        # 获取所有机器人配置
        bots = BotConfig.query.filter_by(is_active=True).order_by(BotConfig.created_at.desc()).all()
        
        return jsonify({
            'success': True,
            'bots': [{'id': bot.id, 'bot_username': bot.bot_username} for bot in bots]
        })
        
    except Exception as e:
        logger.info(f"[Broadcast] 获取机器人列表失败: {str(e)}")
        return jsonify({
            'success': False,
            'message': '获取机器人列表失败'
        }), 500

@bp.route('/api/broadcast/users')
@login_required
def get_users():
    """获取用户列表"""
    try:
        # 获取分页参数
        page = request.args.get('page', 1, type=int)
        page_size = request.args.get('page_size', 10, type=int)
        
        # 获取查询参数
        bots_param = request.args.get('bots')
        if bots_param:
            try:
                selected_bots = json.loads(bots_param)
            except:
                selected_bots = []
        else:
            selected_bots = [current_user.bot_username]

        # 构建查询
        query = User.query

        # 如果指定了机器人，按机器人筛选
        if selected_bots:
            query = query.filter(User.bot_username.in_(selected_bots))
        
        # 过滤掉 admin 用户
        query = query.filter(User.username != 'admin')

        # 获取总数
        total = query.count()

        # 获取分页数据
        users = query.order_by(User.bot_username, User.created_at.desc())\
            .offset((page - 1) * page_size)\
            .limit(page_size)\
            .all()
        
        return jsonify({
            'success': True,
            'users': [user.to_dict() for user in users],
            'total': total,
            'page': page,
            'page_size': page_size
        })
        
    except Exception as e:
        logger.info(f"[Broadcast] 获取用户列表失败: {str(e)}")
        return jsonify({
            'success': False,
            'message': '获取用户列表失败'
        }), 500

@bp.route('/api/broadcast/status')
@login_required
def get_status():
    """获取群发状态"""
    try:
        status = broadcast_service.get_status()
        return jsonify({
            'success': True,
            **status
        })
        
    except Exception as e:
        logger.info(f"[Broadcast] 获取群发状态失败: {str(e)}")
        return jsonify({
            'success': False,
            'message': '获取群发状态失败'
        }), 500

@bp.route('/api/broadcast/start', methods=['POST'])
@login_required
def start_broadcast():
    """开始群发"""
    try:
        data = request.get_json()
        content = data.get('content')
        pin_message = data.get('pin_message')
        broadcast_tasks = data.get('broadcast_tasks', [])
        
        if not content or not broadcast_tasks:
            return jsonify({
                'success': False,
                'message': '参数错误'
            }), 400
        
        # 验证所有任务的用户ID
        for task in broadcast_tasks:
            if not task.get('bot_username') or not task.get('user_ids'):
                return jsonify({
                    'success': False,
                    'message': '任务参数错误'
                }), 400
        
        # 启动群发任务
        success, message = broadcast_service.start_broadcast(
            content=content,
            broadcast_tasks=broadcast_tasks,
            pin_message=pin_message
        )
        
        return jsonify({
            'success': success,
            'message': message
        })
        
    except Exception as e:
        logger.info(f"[Broadcast] 启动群发失败: {str(e)}")
        return jsonify({
            'success': False,
            'message': '启动群发失败'
        }), 500

@bp.route('/api/broadcast/stop', methods=['POST'])
@login_required
def stop_broadcast():
    """停止群发"""
    try:
        success, message = broadcast_service.stop_broadcast()
        return jsonify({
            'success': success,
            'message': message
        })
        
    except Exception as e:
        logger.info(f"[Broadcast] 停止群发失败: {str(e)}")
        return jsonify({
            'success': False,
            'message': '停止群发失败'
        }), 500 