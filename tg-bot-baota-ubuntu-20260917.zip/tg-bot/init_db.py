from app import create_app
from extensions import db
# 导入所有模型类
from models.user import User
from models.config import BotConfig
from models.order import Order
from models.product import Product
from models.category import Category
from models.withdrawal import Withdrawal
from models.advertisement import Advertisement
from logging import getLogger
logger = getLogger(__name__)

def init_db():
    """初始化数据库"""
    app = create_app()
    with app.app_context():
        # 创建所有表
        db.create_all()
        logger.info("数据库表创建成功")

        # 检查是否需要创建初始机器人配置
        root_bot = BotConfig.query.filter_by(parent_bot_username=None).first()
        if not root_bot:
            # 创建源头机器人配置
            root_bot = BotConfig(
                bot_username='@admin',  # 使用与管理员相同的机器人用户名
                bot_token='YOUR_BOT_TOKEN',  # 需要替换为实际的Token
                recharge_address='YOUR_RECHARGE_ADDRESS',  # 需要替换为实际的充值地址
                admin_usernames='admin',  # 管理员用户名
                parent_bot_username=None,  # 源头机器人没有上级
                root_bot_username='@admin',  # 自己就是源头
                commission_rate=0.0,  # 默认佣金比例
                allow_clone=True,  # 允许克隆
                epay_pid='YOUR_EPAY_PID',  # 需要替换为实际的商户ID
                usdt_rate=7.3,  # 默认USDT兑换比例
                epay_key='YOUR_EPAY_KEY',  # 需要替换为实际的商户密钥
                backend_url="",
                announcement='欢迎使用机器人',  # 默认公告
                is_active=True  # 启用状态
            )
            db.session.add(root_bot)
            db.session.commit()
            logger.info("源头机器人配置创建成功")
        else:
            logger.info("源头机器人配置已存在")

if __name__ == '__main__':
    init_db() 