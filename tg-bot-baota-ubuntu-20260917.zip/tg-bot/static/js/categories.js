// 分类管理的API请求
const CategoryAPI = {
    // 获取所有分类
    getAll: async () => {
        const response = await fetch('/api/categories');
        if (!response.ok) throw new Error('获取分类列表失败');
        return response.json();
    },

    // 创建分类
    create: async (data) => {
        const response = await fetch('/api/categories', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('创建分类失败');
        return response.json();
    },

    // 更新分类
    update: async (id, data) => {
        const response = await fetch(`/api/categories/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('更新分类失败');
        return response.json();
    },

    // 删除分类
    delete: async (id) => {
        const response = await fetch(`/api/categories/${id}`, {
            method: 'DELETE'
        });
        if (!response.ok) throw new Error('删除分类失败');
        return response.json();
    }
};

// 分类管理的UI操作
const CategoryUI = {
    // 初始化表格数据
    initTable: async () => {
        try {
            const categories = await CategoryAPI.getAll();
            const tbody = document.querySelector('table tbody');
            if (categories.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center">暂无数据</td></tr>';
                return;
            }

            tbody.innerHTML = categories.map(category => `
                <tr>
                    <td>${category.id}</td>
                    <td>${category.sort_index}</td>
                    <td>${category.name}</td>
                    <td>${category.description || '-'}</td>
                    <td>${category.parents.map(p => p.name).join(', ') || '-'}</td>
                    <td>${category.created_at}</td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="CategoryUI.editCategory(${category.id})">
                            <i class="bx bx-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="CategoryUI.deleteCategory(${category.id})">
                            <i class="bx bx-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        } catch (error) {
            alert(error.message);
        }
    },

    // 更新分类选择器选项
    updateCategorySelects: async () => {
        try {
            const categories = await CategoryAPI.getAll();
            const selects = document.querySelectorAll('select[name="parent_categories[]"]');
            const options = categories.map(category => 
                `<option value="${category.id}">${category.name}</option>`
            ).join('');

            selects.forEach(select => {
                select.innerHTML = '<option value="">选择上级分类</option>' + options;
            });
        } catch (error) {
            alert(error.message);
        }
    },

    // 保存分类
    saveCategory: async () => {
        try {
            const form = document.getElementById('categoryForm');
            const formData = new FormData(form);
            const data = {
                name: formData.get('name'),
                description: formData.get('description'),
                sort_index: parseInt(formData.get('sort_index')),
                parent_categories: Array.from(formData.getAll('parent_categories[]'))
                    .filter(id => id !== '')
                    .map(id => parseInt(id))
            };

            await CategoryAPI.create(data);
            $('#addCategoryModal').modal('hide');
            form.reset();
            await CategoryUI.initTable();
            await CategoryUI.updateCategorySelects();
            alert('分类创建成功');
        } catch (error) {
            alert(error.message);
        }
    },

    // 编辑分类
    editCategory: async (id) => {
        try {
            const categories = await CategoryAPI.getAll();
            const category = categories.find(c => c.id === id);
            if (!category) throw new Error('分类不存在');

            const form = document.getElementById('editCategoryForm');
            form.querySelector('input[name="id"]').value = category.id;
            form.querySelector('input[name="name"]').value = category.name;
            form.querySelector('input[name="sort_index"]').value = category.sort_index;
            form.querySelector('textarea[name="description"]').value = category.description || '';

            // 设置已选的上级分类
            const parentContainer = form.querySelector('.parent-categories');
            parentContainer.innerHTML = category.parents.map((parent, index) => `
                <div class="d-flex mb-2 align-items-center parent-category-item">
                    <select class="form-select me-2" name="parent_categories[]">
                        <option value="">选择上级分类</option>
                        ${categories.map(c => `
                            <option value="${c.id}" ${c.id === parent.id ? 'selected' : ''}>
                                ${c.name}
                            </option>
                        `).join('')}
                    </select>
                    ${index === 0 ? `
                        <button type="button" class="btn btn-outline-primary btn-sm add-parent" title="添加另一个上级分类">
                            <i class="bx bx-plus"></i>
                        </button>
                    ` : `
                        <button type="button" class="btn btn-outline-danger btn-sm remove-parent" title="移除此上级分类">
                            <i class="bx bx-minus"></i>
                        </button>
                    `}
                </div>
            `).join('') || `
                <div class="d-flex mb-2 align-items-center parent-category-item">
                    <select class="form-select me-2" name="parent_categories[]">
                        <option value="">选择上级分类</option>
                        ${categories.map(c => `
                            <option value="${c.id}">${c.name}</option>
                        `).join('')}
                    </select>
                    <button type="button" class="btn btn-outline-primary btn-sm add-parent" title="添加另一个上级分类">
                        <i class="bx bx-plus"></i>
                    </button>
                </div>
            `;

            // 重新绑定添加/删除按钮事件
            CategoryUI.bindParentButtons();
            $('#editCategoryModal').modal('show');
        } catch (error) {
            alert(error.message);
        }
    },

    // 更新分类
    updateCategory: async () => {
        try {
            const form = document.getElementById('editCategoryForm');
            const formData = new FormData(form);
            const data = {
                name: formData.get('name'),
                description: formData.get('description'),
                sort_index: parseInt(formData.get('sort_index')),
                parent_categories: Array.from(formData.getAll('parent_categories[]'))
                    .filter(id => id !== '')
                    .map(id => parseInt(id))
            };

            await CategoryAPI.update(formData.get('id'), data);
            $('#editCategoryModal').modal('hide');
            form.reset();
            await CategoryUI.initTable();
            await CategoryUI.updateCategorySelects();
            alert('分类更新成功');
        } catch (error) {
            alert(error.message);
        }
    },

    // 删除分类
    deleteCategory: async (id) => {
        if (!confirm('确定要删除这个分类吗？')) return;
        
        try {
            await CategoryAPI.delete(id);
            await CategoryUI.initTable();
            await CategoryUI.updateCategorySelects();
            alert('分类删除成功');
        } catch (error) {
            alert(error.message);
        }
    },

    // 绑定上级分类添加/删除按钮事件
    bindParentButtons: () => {
        document.querySelectorAll('.add-parent').forEach(btn => {
            btn.onclick = function() {
                const template = `
                    <div class="d-flex mb-2 align-items-center parent-category-item">
                        <select class="form-select me-2" name="parent_categories[]">
                            <option value="">选择上级分类</option>
                        </select>
                        <button type="button" class="btn btn-outline-danger btn-sm remove-parent" title="移除此上级分类">
                            <i class="bx bx-minus"></i>
                        </button>
                    </div>
                `;
                const parentContainer = this.closest('.parent-categories');
                const newItem = document.createElement('div');
                newItem.innerHTML = template;
                parentContainer.appendChild(newItem.firstElementChild);

                // 更新新添加的选择器选项
                CategoryUI.updateCategorySelects();
                
                // 为新添加的移除按钮添加事件监听
                newItem.querySelector('.remove-parent').onclick = function() {
                    this.closest('.parent-category-item').remove();
                };
            };
        });

        document.querySelectorAll('.remove-parent').forEach(btn => {
            btn.onclick = function() {
                this.closest('.parent-category-item').remove();
            };
        });
    }
};

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', async () => {
    await CategoryUI.initTable();
    await CategoryUI.updateCategorySelects();
    CategoryUI.bindParentButtons();

    // 重置表单事件
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('hidden.bs.modal', function() {
            this.querySelector('form').reset();
        });
    });
}); 