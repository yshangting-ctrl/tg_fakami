from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()

import os
import sqlite3
import threading
import time
from datetime import datetime

def backup_database_periodically(app):
    def backup_task():
        with app.app_context():
            backup_dir = os.path.join(app.instance_path, 'backups')
            if not os.path.exists(backup_dir):
                os.makedirs(backup_dir)
            if db.engine.url.get_backend_name() != 'sqlite':
                return
            db_path = os.path.abspath(db.engine.url.database)
            while True:
                today_str = datetime.now().strftime('%Y-%m-%d')
                backup_filename = f"mall_backup_{today_str}.db"
                backup_path = os.path.join(backup_dir, backup_filename)
                if not os.path.exists(backup_path):
                    try:
                        with sqlite3.connect(db_path) as source:
                            with sqlite3.connect(backup_path) as destination:
                                source.backup(destination)
                    except Exception as e:
                        pass
                backups = sorted([
                    f for f in os.listdir(backup_dir)
                    if f.startswith("mall_backup_") and f.endswith(".db")
                ])
                while backups:
                    first_backup = os.path.join(backup_dir, backups[0])
                    if os.path.getsize(first_backup) > 100 * 1024 * 1024:
                        try:
                            os.remove(first_backup)
                            backups.pop(0)
                        except Exception as e:
                            break
                    else:
                        break
                while len(backups) > 10:
                    try:
                        os.remove(os.path.join(backup_dir, backups[0]))
                        backups.pop(0)
                    except Exception as e:
                        break
                now = datetime.now()
                from datetime import timedelta
                tomorrow = datetime(now.year, now.month, now.day) + timedelta(days=1)
                sleep_seconds = (tomorrow - now).total_seconds()
                if not os.path.exists(db_path):
                    time.sleep(60)
                else:
                    time.sleep(max(sleep_seconds, 60))  # 最少睡60秒，防止异常

    t = threading.Thread(target=backup_task, daemon=True)
    t.start()

def init_extensions(app, start_backup=True):
    db.init_app(app)
    login_manager.init_app(app)
    if start_backup:
        backup_database_periodically(app)
    login_manager.login_view = 'auth.login'  # 更新为新的登录视图路径 
