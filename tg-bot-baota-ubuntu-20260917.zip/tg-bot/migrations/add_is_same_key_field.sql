-- 添加is_same_key字段到key表
ALTER TABLE key ADD COLUMN is_same_key BOOLEAN DEFAULT FALSE; 