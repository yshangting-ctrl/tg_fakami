-- 创建订单-卡密关联表
CREATE TABLE IF NOT EXISTS order_keys (
    order_id VARCHAR(50) NOT NULL,
    key_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id, key_id),
    FOREIGN KEY (order_id) REFERENCES `order` (id) ON DELETE CASCADE,
    FOREIGN KEY (key_id) REFERENCES `key` (id) ON DELETE CASCADE
); 