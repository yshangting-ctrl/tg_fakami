-- 添加易支付后端地址字段
ALTER TABLE bot_config ADD COLUMN backend_url VARCHAR(255) DEFAULT 'http://pay.xxx.com' NOT NULL; 