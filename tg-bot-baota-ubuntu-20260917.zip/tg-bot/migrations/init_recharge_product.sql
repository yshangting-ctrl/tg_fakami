-- 检查充值商品是否已存在
INSERT OR IGNORE INTO product (
    id,
    name,
    price,
    description,
    sort_index,
    category_id,
    storage_path,
    total_keys,
    used_keys,
    is_active,
    is_dedup,
    created_at,
    updated_at
) VALUES (
    1,  -- 固定ID为1
    '余额充值',
    0,  -- 价格为0，实际价格在订单中设置
    'USDT充值',
    0,
    1,  -- 使用默认分类ID
    '/recharge',  -- 虚拟存储路径
    999999,  -- 设置一个很大的数作为总数
    0,  -- 已使用数量
    1,  -- 启用状态
    0,  -- 不需要去重
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP
); 