-- 添加USDT比例字段
ALTER TABLE bot_config ADD COLUMN usdt_rate FLOAT DEFAULT 7.0; 