-- 添加佣金比例和源头机器人用户名字段
ALTER TABLE bot_config ADD COLUMN IF NOT EXISTS commission_rate FLOAT DEFAULT 0.0 COMMENT '佣金比例';
ALTER TABLE bot_config ADD COLUMN IF NOT EXISTS root_bot_username VARCHAR(100) COMMENT '源头机器人用户名'; 