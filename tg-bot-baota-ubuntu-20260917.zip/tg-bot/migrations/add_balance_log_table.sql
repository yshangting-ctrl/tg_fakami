-- 创建余额变动记录表
CREATE TABLE IF NOT EXISTS balance_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(80) NOT NULL,
    telegram_id VARCHAR(50) NOT NULL,
    bot_username VARCHAR(80) NOT NULL,
    type VARCHAR(20) NOT NULL,
    amount FLOAT NOT NULL,
    balance FLOAT NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (telegram_id, bot_username) REFERENCES user(telegram_id, bot_username)
);

-- 创建索引
CREATE INDEX idx_balance_log_user ON balance_log(telegram_id, bot_username);
CREATE INDEX idx_balance_log_created_at ON balance_log(created_at); 