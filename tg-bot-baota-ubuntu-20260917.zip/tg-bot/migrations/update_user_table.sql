-- 创建临时表
CREATE TABLE user_temp (
    id INTEGER PRIMARY KEY AUTOINCREMENT,  -- 系统用户ID (自增)
    bot_username VARCHAR(80) NOT NULL,  -- 机器人用户名
    telegram_id VARCHAR(50) NOT NULL,  -- Telegram用户ID
    username VARCHAR(80) NOT NULL,  -- 用户名
    password_hash VARCHAR(128) NOT NULL,  -- 密码哈希
    nickname VARCHAR(80),  -- 昵称
    balance FLOAT DEFAULT 0.0,  -- 余额
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,  -- 创建时间
    last_active_at DATETIME DEFAULT CURRENT_TIMESTAMP  -- 最后活动时间
);

-- 复制数据到临时表
INSERT INTO user_temp (
    bot_username,
    telegram_id,
    username,
    password_hash,
    nickname,
    balance,
    created_at,
    last_active_at
)
SELECT 
    bot_username,
    id as telegram_id,  -- 原id作为telegram_id
    username,
    password_hash,
    nickname,
    balance,
    created_at,
    last_active_at
FROM user;

-- 删除原表
DROP TABLE user;

-- 重命名临时表
ALTER TABLE user_temp RENAME TO user;

-- 创建索引
CREATE INDEX idx_user_telegram_bot ON user(telegram_id, bot_username);
CREATE INDEX idx_user_username_bot ON user(username, bot_username); 