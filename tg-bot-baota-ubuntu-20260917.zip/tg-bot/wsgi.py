import atexit
import os

from app import create_app, start_bot_system, stop_bot_system


app = create_app()

if os.environ.get('ENABLE_BOT_SYSTEM', '1') == '1':
    start_bot_system()
    atexit.register(stop_bot_system)

