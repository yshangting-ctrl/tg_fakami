#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

on_error() {
    local exit_code=$?
    echo "Deployment failed at line $1 (exit $exit_code)." >&2
    echo "Run for diagnostics: bash $ROOT_DIR/deploy/doctor.sh" >&2
    exit "$exit_code"
}
trap 'on_error $LINENO' ERR

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    echo "Run as root: bash deploy/setup.sh" >&2
    exit 1
fi

if [[ "$ROOT_DIR" != "/www/wwwroot/tg-bot" ]]; then
    echo "The project must be extracted to /www/wwwroot/tg-bot" >&2
    echo "Current path: $ROOT_DIR" >&2
    exit 1
fi

cd "$ROOT_DIR"
bash deploy/install.sh
bash deploy/install-systemd.sh

status_code="$(curl -sS -o /dev/null -w '%{http_code}' \
    http://127.0.0.1:5002/login)"
if [[ "$status_code" != "200" ]]; then
    echo "Local application check failed: HTTP $status_code" >&2
    exit 1
fi

echo
echo "Deployment completed successfully."
echo "Service: active"
echo "Local URL: http://127.0.0.1:5002/login (HTTP 200)"
echo "Next: create the BaoTa site and reverse proxy to 127.0.0.1:5002."
