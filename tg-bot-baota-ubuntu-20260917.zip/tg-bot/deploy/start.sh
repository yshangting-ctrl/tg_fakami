#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
umask 077

if [[ ! -f .env ]]; then
    echo "Missing $ROOT_DIR/.env; copy .env.production.example and configure it." >&2
    exit 1
fi

set -a
# shellcheck disable=SC1091
source .env
set +a

PYTHON_BIN="${PYTHON_BIN:-$ROOT_DIR/.venv/bin/python}"
GUNICORN_BIN="${GUNICORN_BIN:-$ROOT_DIR/.venv/bin/gunicorn}"

if [[ ! -x "$PYTHON_BIN" || ! -x "$GUNICORN_BIN" ]]; then
    echo "Missing production virtualenv. Install requirements-production.txt first." >&2
    exit 1
fi

"$PYTHON_BIN" deploy/preflight.py
exec "$GUNICORN_BIN" --config deploy/gunicorn.conf.py wsgi:app

