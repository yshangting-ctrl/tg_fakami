import os


bind = os.environ.get('GUNICORN_BIND', '127.0.0.1:5002')

# SQLite, the backup scheduler, and Telegram polling require one worker.
workers = 1
worker_class = 'gthread'
threads = int(os.environ.get('GUNICORN_THREADS', '4'))
timeout = int(os.environ.get('GUNICORN_TIMEOUT', '120'))
graceful_timeout = 30
keepalive = 5
preload_app = False

accesslog = '-'
errorlog = '-'
capture_output = True
loglevel = os.environ.get('GUNICORN_LOG_LEVEL', 'info')

