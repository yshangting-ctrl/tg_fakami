#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVICE_NAME="tg-bot.service"
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME"
RUN_USER="${RUN_USER:-www}"

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    echo "Run this script as root: bash deploy/install-systemd.sh" >&2
    exit 1
fi

if [[ "$ROOT_DIR" != "/www/wwwroot/tg-bot" ]]; then
    echo "Expected project path: /www/wwwroot/tg-bot" >&2
    echo "Current project path:  $ROOT_DIR" >&2
    exit 1
fi

if ! id "$RUN_USER" >/dev/null 2>&1; then
    echo "Linux user does not exist: $RUN_USER" >&2
    exit 1
fi

cd "$ROOT_DIR"

if [[ ! -x .venv/bin/python || ! -x .venv/bin/gunicorn || ! -f .env ]]; then
    echo "Installation is incomplete. Run: bash deploy/install.sh" >&2
    exit 1
fi

mkdir -p instance/backups logs images static/temp static/uploads/keys
chmod 755 "$ROOT_DIR" deploy
chown "$RUN_USER:$RUN_USER" .env
chown -R "$RUN_USER:$RUN_USER" \
    .venv instance logs images static/temp static/uploads
chmod 600 .env
chmod 755 deploy/start.sh deploy/setup.sh deploy/doctor.sh
chmod 700 deploy/install.sh deploy/install-systemd.sh

runuser -u "$RUN_USER" -- "$ROOT_DIR/.venv/bin/python" \
    "$ROOT_DIR/deploy/preflight.py"

install -o root -g root -m 0644 deploy/tg-bot.service "$SERVICE_FILE"
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

sleep 3
if ! systemctl is-active --quiet "$SERVICE_NAME"; then
    systemctl --no-pager --full status "$SERVICE_NAME" || true
    journalctl -u "$SERVICE_NAME" -n 100 --no-pager || true
    exit 1
fi

systemctl --no-pager --full status "$SERVICE_NAME"
echo "Service started. Test: curl http://127.0.0.1:5002/login"
