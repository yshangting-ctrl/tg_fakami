#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
umask 077

find_python_311() {
    local requested="${PYTHON_BIN:-}"
    local candidate resolved
    local -a candidates=()

    if [[ -n "$requested" ]]; then
        candidates+=("$requested")
    fi
    candidates+=(python3.11)

    # BaoTa has used both directory layouts across Python Manager releases.
    shopt -s nullglob
    candidates+=(/www/server/python_manager/versions/3.11*/bin/python3.11)
    candidates+=(/www/server/python_manager/versions/3.11*/bin/python3)
    candidates+=(/www/server/pyporject_evn/versions/3.11*/bin/python3.11)
    candidates+=(/www/server/pyporject_evn/versions/3.11*/bin/python3)
    shopt -u nullglob

    for candidate in "${candidates[@]}"; do
        if [[ "$candidate" == */* ]]; then
            resolved="$candidate"
        elif ! resolved="$(command -v "$candidate" 2>/dev/null)"; then
            continue
        fi

        if [[ -x "$resolved" ]] && "$resolved" -c \
            'import sys; raise SystemExit(sys.version_info[:2] != (3, 11))' 2>/dev/null; then
            printf '%s\n' "$resolved"
            return 0
        fi
    done

    return 1
}

if ! PYTHON_BIN="$(find_python_311)"; then
    echo "Python 3.11 executable was not found." >&2
    echo "Install Python 3.11 in BaoTa, or run:" >&2
    echo "PYTHON_BIN=/full/path/to/python3.11 bash deploy/install.sh" >&2
    exit 1
fi

echo "Using Python: $PYTHON_BIN"

if [[ "${EUID:-$(id -u)}" -eq 0 && "$PYTHON_BIN" == /www/server/* ]]; then
    PYTHON_REAL="$(readlink -f "$PYTHON_BIN")"
    PYTHON_ROOT="$(dirname "$(dirname "$PYTHON_REAL")")"

    # BaoTa may install a shared interpreter below directories without
    # traversal permission for www. Project runtimes are expected to use it.
    chmod o+x /www /www/server
    current="/www/server"
    relative="${PYTHON_ROOT#/www/server/}"
    IFS='/' read -r -a path_parts <<< "$relative"
    for part in "${path_parts[@]}"; do
        current="$current/$part"
        chmod a+rx "$current"
    done
    chmod -R a+rX "$PYTHON_ROOT"
fi

if [[ ! -x .venv/bin/python ]]; then
    # Copies avoid BaoTa interpreter symlink permission failures for the www user.
    "$PYTHON_BIN" -m venv --copies .venv
elif ! .venv/bin/python -c \
    'import sys; raise SystemExit(sys.version_info[:2] != (3, 11))'; then
    echo "Existing .venv is not Python 3.11. Remove it and run this installer again." >&2
    exit 1
fi

.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements-production.txt

if [[ ! -f .env ]]; then
    cp .env.production.example .env
    ADMIN_PASSWORD="$(.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(24))')"
    FLASK_SECRET_KEY="$(.venv/bin/python -c 'import secrets; print(secrets.token_hex(32))')"
    sed -i "s/CHANGE_ME_LONG_RANDOM_PASSWORD/$ADMIN_PASSWORD/" .env
    sed -i "s/CHANGE_ME_64_HEX_CHARACTERS/$FLASK_SECRET_KEY/" .env
    chmod 600 .env
    echo "Created .env with random credentials. Read ADMIN_USERNAME and ADMIN_PASSWORD there."
else
    echo "Existing .env preserved."
fi

mkdir -p instance/backups logs images static/temp static/uploads/keys
chmod 755 "$ROOT_DIR" deploy
chmod 755 deploy/start.sh deploy/setup.sh deploy/doctor.sh
chmod 700 deploy/install.sh deploy/install-systemd.sh

if [[ "${EUID:-$(id -u)}" -eq 0 ]] && id www >/dev/null 2>&1; then
    chown www:www .env
    chown -R www:www .venv instance logs images static/temp static/uploads
fi

.venv/bin/python deploy/preflight.py

echo "Installation complete. Recommended next command: bash deploy/install-systemd.sh"
