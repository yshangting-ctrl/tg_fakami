import os
import sys
from pathlib import Path

from dotenv import load_dotenv


ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / '.env')

errors = []

admin_password = os.environ.get('ADMIN_PASSWORD', '')
secret_key = os.environ.get('FLASK_SECRET_KEY', '')
database_url = os.environ.get('DATABASE_URL', 'sqlite:///mall.db')

if len(admin_password) < 16 or 'CHANGE_ME' in admin_password:
    errors.append('ADMIN_PASSWORD must be a non-placeholder value of at least 16 characters')
if len(secret_key) < 32 or 'CHANGE_ME' in secret_key:
    errors.append('FLASK_SECRET_KEY must be a non-placeholder value of at least 32 characters')
if not database_url.startswith('sqlite:///'):
    errors.append('This deployment profile currently supports DATABASE_URL=sqlite:///... only')

if errors:
    for error in errors:
        print(f'ERROR: {error}', file=sys.stderr)
    raise SystemExit(1)

for directory in (
    ROOT / 'instance',
    ROOT / 'instance' / 'backups',
    ROOT / 'logs',
    ROOT / 'images',
    ROOT / 'static' / 'temp',
    ROOT / 'static' / 'uploads',
    ROOT / 'static' / 'uploads' / 'keys',
):
    directory.mkdir(parents=True, exist_ok=True)

if os.environ.get('ENABLE_PAYMENT_CALLBACKS', '0') == '1':
    print('WARNING: payment callbacks are enabled; provider signature verification is required')

print('Preflight check passed')

