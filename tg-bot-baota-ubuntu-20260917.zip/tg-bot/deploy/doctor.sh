#!/usr/bin/env bash
set -u

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

section() {
    printf '\n===== %s =====\n' "$1"
}

section "Project files"
printf 'Project path: %s\n' "$ROOT_DIR"
for path in \
    "$ROOT_DIR/app.py" \
    "$ROOT_DIR/.env" \
    "$ROOT_DIR/.venv/bin/python" \
    "$ROOT_DIR/.venv/bin/gunicorn" \
    /etc/systemd/system/tg-bot.service; do
    if [[ -e "$path" ]]; then
        printf 'OK      %s\n' "$path"
    else
        printf 'MISSING %s\n' "$path"
    fi
done

section "Service"
systemctl is-enabled tg-bot 2>&1 || true
systemctl is-active tg-bot 2>&1 || true
systemctl --no-pager --full status tg-bot 2>&1 || true

section "Port 5002"
ss -lntp 2>&1 | grep ':5002' || echo 'NOT LISTENING'

section "Local GET /login"
curl -sS -o /dev/null -w 'HTTP %{http_code}\n' \
    http://127.0.0.1:5002/login 2>&1 || true

section "Recent service log"
journalctl -u tg-bot -n 80 --no-pager 2>&1 || true

section "Recent application log"
if [[ -f "$ROOT_DIR/logs/app.log" ]]; then
    tail -n 80 "$ROOT_DIR/logs/app.log"
else
    echo 'No application log file'
fi

section "Nginx"
if [[ -x /www/server/nginx/sbin/nginx ]]; then
    /www/server/nginx/sbin/nginx -t 2>&1 || true
elif command -v nginx >/dev/null 2>&1; then
    nginx -t 2>&1 || true
else
    echo 'Nginx executable not found'
fi

section "Nginx listeners"
ss -lntp 2>&1 | grep -E ':(80|443)[[:space:]]' || echo 'PORT 80/443 NOT LISTENING'

section "Reverse proxy entries"
grep -R -n --include='*.conf' \
    'proxy_pass[[:space:]]\+http://127\.0\.0\.1:5002' \
    /www/server/panel/vhost/nginx 2>/dev/null || echo 'PROXY ENTRY NOT FOUND'

section "Non-secret settings"
if [[ -f "$ROOT_DIR/.env" ]]; then
    grep -E '^(GUNICORN_BIND|ENABLE_BOT_SYSTEM|ENABLE_PAYMENT_CALLBACKS|TRUST_PROXY_HEADERS|SESSION_COOKIE_SECURE)=' \
        "$ROOT_DIR/.env" || true
fi

echo
echo 'Diagnostics complete. This report does not print passwords or tokens.'
