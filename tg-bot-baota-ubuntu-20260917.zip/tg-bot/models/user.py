from extensions import db
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True, comment='系统用户ID')
    bot_username = db.Column(db.String(80), nullable=False, comment='机器人用户名')
    telegram_id = db.Column(db.String(50), nullable=False, comment='Telegram用户ID')
    username = db.Column(db.String(80), nullable=False, comment='用户名')
    password_hash = db.Column(db.String(128), nullable=False)
    nickname = db.Column(db.String(80), comment='昵称')
    balance = db.Column(db.Float, default=0.0, comment='余额（USDT）')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, comment='注册时间')
    last_active_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment='最后活动时间')

    # 添加唯一索引
    __table_args__ = (
        db.UniqueConstraint('telegram_id', 'bot_username', name='uix_user_telegram_bot'),
    )

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    @password.setter
    def password(self, password):
        """
        设置密码。兼容明文和哈希格式。
        如果传入的 password 已经是哈希（以pbkdf2:开头），则直接存储；
        否则自动加密。
        """
        if password and isinstance(password, str) and password.startswith('pbkdf2:'):
            # 已经是哈希格式，直接存储
            self.password_hash = password
        else:
            # 明文，自动加密
            self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        """
        校验密码。兼容明文和哈希存储。
        """
        # 先尝试用哈希校验
        if check_password_hash(self.password_hash, password):
            return True
        # 如果存储的是明文（极少数老数据），直接比对
        if self.password_hash == password:
            return True
        return False

    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'telegram_id': self.telegram_id,
            'username': self.username,
            'nickname': self.nickname,
            'bot_username': self.bot_username,
            'balance': self.balance,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'last_active_at': self.last_active_at.strftime('%Y-%m-%d %H:%M:%S')
        }

    def update_balance(self, amount):
        """更新余额
        Args:
            amount: 变动金额（USDT），正数为增加，负数为减少
        """
        self.balance += amount
        return self.balance