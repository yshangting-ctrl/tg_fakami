from extensions import db
from datetime import datetime

class Key(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False, comment='密钥内容')
    file_path = db.Column(db.String(255), nullable=False, comment='密钥文件路径')
    file_name = db.Column(db.String(255), nullable=False, comment='密钥文件名')
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    is_used = db.Column(db.Boolean, default=False, comment='是否已使用')
    used_at = db.Column(db.DateTime, comment='使用时间')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 关联商品
    product = db.relationship('Product', backref=db.backref('keys', lazy=True))

    def to_dict(self):
        return {
            'id': self.id,
            'content': self.content,
            'file_name': self.file_name,
            'product_id': self.product_id,
            'is_used': self.is_used,
            'used_at': self.used_at.strftime('%Y-%m-%d %H:%M:%S') if self.used_at else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        } 