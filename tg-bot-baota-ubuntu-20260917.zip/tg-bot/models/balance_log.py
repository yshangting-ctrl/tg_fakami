from extensions import db
from datetime import datetime

class BalanceLog(db.Model):
    """余额变动记录表"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False, comment='用户名')
    telegram_id = db.Column(db.String(50), nullable=False, comment='Telegram用户ID')
    bot_username = db.Column(db.String(80), nullable=False, comment='机器人用户名')
    type = db.Column(db.String(20), nullable=False, comment='变动类型：increase/decrease')
    amount = db.Column(db.Float, nullable=False, comment='变动金额')
    balance = db.Column(db.Float, nullable=False, comment='变动后余额')
    description = db.Column(db.Text, comment='变动说明')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, comment='变动时间')

    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'username': self.username,
            'telegram_id': self.telegram_id,
            'bot_username': self.bot_username,
            'type': self.type,
            'amount': self.amount,
            'balance': self.balance,
            'description': self.description,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        } 