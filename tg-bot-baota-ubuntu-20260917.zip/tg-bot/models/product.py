from extensions import db
from datetime import datetime

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, comment='商品名称')
    price = db.Column(db.Float, nullable=False, comment='商品价格（USDT）')
    description = db.Column(db.Text, comment='商品描述')
    sort_index = db.Column(db.Integer, default=0, comment='排序索引')
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    storage_path = db.Column(db.String(255), nullable=False, comment='密钥文件存储路径')
    total_keys = db.Column(db.Integer, default=0, comment='总密钥数量')
    used_keys = db.Column(db.Integer, default=0, comment='已使用密钥数量')
    is_same_key = db.Column(db.Boolean, default=False, comment='是否为同一密钥')
    is_active = db.Column(db.Boolean, default=True, comment='是否启用')
    is_dedup = db.Column(db.Boolean, default=True, comment='是否去重')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 关联分类
    category = db.relationship('Category', backref=db.backref('products', lazy=True))

    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'description': self.description,
            'sort_index': self.sort_index,
            'category_id': self.category_id,
            'storage_path': self.storage_path,
            'total_keys': self.total_keys,
            'used_keys': self.used_keys,
            'is_active': self.is_active,
            "is_same_key": self.is_same_key,
            'is_dedup': self.is_dedup,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
            'category_name': self.category.name if self.category else None
        } 