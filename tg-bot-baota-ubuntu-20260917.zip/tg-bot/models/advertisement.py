from extensions import db
from datetime import datetime

class Advertisement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False, comment='用户名')
    description = db.Column(db.Text, comment='广告简介')
    expire_at = db.Column(db.DateTime, nullable=False, comment='过期时间')
    is_active = db.Column(db.Boolean, default=True, comment='是否启用')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'description': self.description,
            'expire_at': self.expire_at.strftime('%Y-%m-%d %H:%M:%S'),
            'is_active': self.is_active,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        } 