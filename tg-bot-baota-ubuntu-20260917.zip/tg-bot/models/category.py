from extensions import db
from datetime import datetime

# 分类与上级分类的关联表
category_parents = db.Table('category_parents',
    db.Column('category_id', db.Integer, db.ForeignKey('category.id'), primary_key=True),
    db.Column('parent_id', db.Integer, db.ForeignKey('category.id'), primary_key=True)
)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    sort_index = db.Column(db.Integer, default=0)  # 添加排序索引字段
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 多对多关系：一个分类可以有多个上级分类
    parents = db.relationship('Category',
        secondary=category_parents,
        primaryjoin=(category_parents.c.category_id == id),
        secondaryjoin=(category_parents.c.parent_id == id),
        backref=db.backref('children', lazy='dynamic'),
        lazy='dynamic'
    )

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'sort_index': self.sort_index,
            'parents': [{'id': p.id, 'name': p.name} for p in self.parents],
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        } 