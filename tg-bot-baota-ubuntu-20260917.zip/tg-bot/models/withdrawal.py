from extensions import db
from datetime import datetime, timedelta

class Withdrawal(db.Model):
    """提现记录模型"""
    id = db.Column(db.Integer, primary_key=True)
    # 这里将user_id关联到User表的telegram_id字段
    user_id = db.Column(db.String(50), db.ForeignKey('user.telegram_id'), nullable=False, comment='提现用户Telegram ID')
    bot_username = db.Column(db.String(80), nullable=False, comment='发起提现的机器人用户名')
    amount = db.Column(db.Float, nullable=False, comment='提现金额')
    address = db.Column(db.String(255), nullable=False, comment='提现地址')
    status = db.Column(db.String(20), nullable=False, default='pending', comment='状态：pending/approved/rejected')
    remark = db.Column(db.Text, comment='备注（通过/驳回原因）')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, comment='创建时间')
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment='更新时间')

    # 关联关系，user_id关联User.telegram_id
    user = db.relationship('User', primaryjoin='Withdrawal.user_id==User.telegram_id', backref=db.backref('withdrawals', lazy=True))

    def to_dict(self):
        """转换为字典"""
        def to_beijing_time(utc_time):
            if utc_time is None:
                return None
            beijing_time = utc_time + timedelta(hours=8)
            return beijing_time.strftime('%Y-%m-%d %H:%M:%S')
            
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_nickname': self.user.username if self.user else None,
            'bot_username': self.bot_username,
            'amount': self.amount,
            'address': self.address,
            'status': self.status,
            'remark': self.remark,
            'created_at': to_beijing_time(self.created_at),
            'updated_at': to_beijing_time(self.updated_at)
        } 