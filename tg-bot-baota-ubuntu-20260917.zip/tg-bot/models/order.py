from extensions import db
from datetime import datetime, timedelta

# 订单-卡密关联表
order_keys = db.Table('order_keys',
    db.Column('order_id', db.String(50), db.ForeignKey('order.id'), primary_key=True),
    db.Column('key_id', db.Integer, db.ForeignKey('key.id'), primary_key=True),
    db.Column('created_at', db.DateTime, default=datetime.utcnow)
)

class Order(db.Model):
    """订单模型
    
    用于存储和管理订单信息，包括订单基本信息、价格信息、支付信息等。
    订单状态流转：pending -> paid -> completed，或 pending -> cancelled/failed
    
    字段说明：
    - 基本信息：
        id: 订单号，格式为 ORD + 时间戳 + 6位随机字符
        user_id: 下单用户ID
        product_id: 购买的商品ID
        bot_username: 处理订单的机器人用户名
        
    - 价格信息：
        unit_price: 商品单价（USDT）
        quantity: 购买数量
        total_amount: 订单总金额（单价 × 数量，USDT）
        
    - 支付信息：
        payment_type: 支付类型，可选值：USDT/BALANCE
        payment_address: 支付地址，USDT时为钱包地址
        payment_amount: 实际支付金额（USDT）
        payment_time: 支付完成时间
        
    - 状态信息：
        status: 订单状态，可选值：
            - pending: 待支付（初始状态）
            - paid: 已支付（支付完成）
            - completed: 已完成（订单结束）
            - cancelled: 已取消（手动取消）
            - failed: 失败（支付失败）
            
    - 其他信息：
        remark: 订单备注信息
        created_at: 订单创建时间
        updated_at: 订单最后更新时间
        
    - 关联关系：
        user: 关联用户模型，一对多关系（一个用户可以有多个订单）
        product: 关联商品模型，一对多关系（一个商品可以有多个订单）
    """
    
    # 基本信息
    id = db.Column(db.String(50), primary_key=True, comment='订单号，格式：ORD + 时间戳 + 6位随机字符')
    user_id = db.Column(db.String(50), db.ForeignKey('user.telegram_id'), nullable=False, comment='下单用户ID')
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=True, comment='购买的商品ID，充值订单为空')
    bot_username = db.Column(db.String(80), nullable=False, comment='处理订单的机器人用户名')
    
    # 价格信息
    unit_price = db.Column(db.Float, nullable=False, comment='商品单价（USDT）')
    quantity = db.Column(db.Integer, nullable=False, comment='购买数量')
    total_amount = db.Column(db.Float, nullable=False, comment='订单总金额（USDT）')
    
    # 支付信息
    payment_address = db.Column(db.String(255), comment='支付地址，USDT时为钱包地址')
    payment_amount = db.Column(db.Float, comment='实际支付金额（USDT）')
    payment_type = db.Column(db.String(20), nullable=False, comment='支付类型：USDT/BALANCE')
    payment_time = db.Column(db.DateTime, comment='支付完成时间')
    payment_no = db.Column(db.String(50), comment='支付编号')  # 新增支付编号字段
    
    # 订单状态
    status = db.Column(db.String(20), nullable=False, default='pending', comment='订单状态：pending/paid/completed/cancelled/failed')
    
    # 其他信息
    remark = db.Column(db.Text, comment='订单备注信息')
    remark1 = db.Column(db.Text, comment='备注字段1')  # 新增备注字段1
    remark2 = db.Column(db.Text, comment='备注字段2')  # 新增备注字段2
    remark3 = db.Column(db.Text, comment='备注字段3')  # 新增备注字段3
    created_at = db.Column(db.DateTime, default=datetime.utcnow, comment='订单创建时间')
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment='订单最后更新时间')
    
    # 关联关系
    user = db.relationship('User', 
                          foreign_keys=[user_id],
                          primaryjoin="and_(Order.user_id==User.telegram_id, Order.bot_username==User.bot_username)",
                          backref=db.backref('orders', lazy=True))
    product = db.relationship('Product', backref=db.backref('orders', lazy=True))
    keys = db.relationship('Key', secondary='order_keys',
                          backref=db.backref('orders', lazy=True))

    def to_dict(self):
        """转换为字典"""
        is_recharge = self.remark1 == 'recharge'
        
        # 时区转换：UTC -> 北京时间
        def to_beijing_time(utc_time):
            if utc_time is None:
                return None
            beijing_time = utc_time + timedelta(hours=8)
            return beijing_time.strftime('%Y-%m-%d %H:%M:%S')
        
        return {
            'id': self.id,
            'user_id': self.user_id,
            'product_id': self.product_id,
            'bot_username': self.bot_username,
            'unit_price': self.unit_price,
            'quantity': self.quantity,
            'total_amount': self.total_amount,
            'payment_type': self.payment_type,
            'payment_address': self.payment_address,
            'payment_amount': self.payment_amount,
            'payment_time': to_beijing_time(self.payment_time),
            'status': self.status,
            'remark': self.remark,
            'remark1': self.remark1,
            'remark2': self.remark2,
            'remark3': self.remark3,
            'created_at': to_beijing_time(self.created_at),
            'updated_at': to_beijing_time(self.updated_at),
            # 用户信息
            'user_nickname': self.user.nickname if self.user else None,
            'user_username': self.user.username if self.user else None,
            # 商品信息
            'product_name': '余额充值' if is_recharge else (self.product.name if self.product else None),
            'product_price': self.unit_price if is_recharge else (self.product.price if self.product else None),
            'is_recharge': is_recharge,
            # 卡密信息
            'keys': [{
                'id': key.id,
                'file_name': key.file_name,
                'used_at': to_beijing_time(key.used_at)
            } for key in self.keys] if self.keys else []
        } 