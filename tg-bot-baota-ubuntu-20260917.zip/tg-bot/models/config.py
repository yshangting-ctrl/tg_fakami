from extensions import db
from datetime import datetime

class BotConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bot_username = db.Column(db.String(100), nullable=False, comment='机器人用户名')
    bot_token = db.Column(db.String(100), nullable=False, comment='机器人token')
    recharge_address = db.Column(db.String(255), nullable=False, comment='充值地址')
    admin_usernames = db.Column(db.Text, nullable=False, comment='管理员用户名，多个用逗号分割')
    parent_bot_username = db.Column(db.String(100), comment='上级机器人用户名')
    root_bot_username = db.Column(db.String(100), comment='源头机器人用户名')  # 新增源头机器人字段
    commission_rate = db.Column(db.Float, default=0.0, comment='佣金比例')  # 新增佣金比例字段
    allow_clone = db.Column(db.Boolean, default=False, comment='是否允许克隆')  # 新增字段
    epay_pid = db.Column(db.String(50), nullable=False, comment='易支付商户ID')
    epay_key = db.Column(db.String(100), nullable=False, comment='易支付商户密钥')
    okpay_id = db.Column(db.String(50), comment='OkayPay商户ID')
    okpay_key = db.Column(db.String(100), comment='OkayPay商户密钥')
    fll_id = db.Column(db.String(50), comment='福利来商户ID')
    fll_key = db.Column(db.String(100), comment='福利来商户密钥')
    usdt_rate = db.Column(db.Float, default=7.3, comment='USDT兑换比例')  # 新增USDT兑换比例字段
    backend_url = db.Column(db.String(255), nullable=False, comment='易支付后端地址')
    announcement = db.Column(db.Text, comment='机器人公告')
    is_active = db.Column(db.Boolean, default=True, comment='是否启用')
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # 如果是新记录，自动设置上级机器人用户名
        if not self.id and not self.parent_bot_username:
            # 获取最后一个机器人配置作为上级
            last_bot = BotConfig.query.order_by(BotConfig.id.desc()).first()
            if last_bot:
                self.parent_bot_username = last_bot.bot_username

    def to_dict(self):
        return {
            'id': self.id,
            'bot_username': self.bot_username,
            'bot_token': self.bot_token,
            'recharge_address': self.recharge_address,
            'admin_usernames': self.admin_usernames,
            'parent_bot_username': self.parent_bot_username,
            'root_bot_username': self.root_bot_username,
            'commission_rate': self.commission_rate,
            'allow_clone': self.allow_clone,
            'epay_pid': self.epay_pid,
            'epay_key': self.epay_key,
            'okpay_id': self.okpay_id or '',  # 新增字段，确保返回空字符串而不是 None
            'okpay_key': self.okpay_key or '',  # 新增字段
            'fll_id': self.fll_id or '',  # 新增字段
            'fll_key': self.fll_key or '',  # 新增字段
            'usdt_rate': self.usdt_rate,
            'backend_url': self.backend_url,
            'announcement': self.announcement,
            'is_active': self.is_active,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        } 